<?php


abstract class MoOAuthClientBasicEnum
{
    private static $constCacheArray = NULL;
    public static function getConstants()
    {
        if (!(self::$constCacheArray == NULL)) {
            goto HH;
        }
        self::$constCacheArray = [];
        HH:
        $x9 = get_called_class();
        if (array_key_exists($x9, self::$constCacheArray)) {
            goto sR;
        }
        $Tv = new ReflectionClass($x9);
        self::$constCacheArray[$x9] = $Tv->getConstants();
        sR:
        return self::$constCacheArray[$x9];
    }
    public static function isValidName($Mk, $Ox = false)
    {
        $QP = self::getConstants();
        if (!$Ox) {
            goto aR;
        }
        return array_key_exists($Mk, $QP);
        aR:
        $St = array_map("\163\x74\162\164\157\154\x6f\x77\x65\162", array_keys($QP));
        return in_array(strtolower($Mk), $St);
    }
    public static function isValidValue($C0, $Ox = true)
    {
        $WS = array_values(self::getConstants());
        return in_array($C0, $WS, $Ox);
    }
}
