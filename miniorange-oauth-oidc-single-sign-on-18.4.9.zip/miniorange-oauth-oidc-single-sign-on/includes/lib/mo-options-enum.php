<?php


include "MoOAuthClientBasicEnum.php";
class mo_oauth_client_options_plugin_constants extends MoOAuthClientBasicEnum
{
    const CMS_Name = "\127\x50";
    const Application_Name = "\127\120\x20\155\151\156\x69\x4f\x72\x61\x6e\x67\x65\40\117\101\165\164\150\x20\x53\123\x4f\x20\x50\x6c\x75\x67\x69\x6e";
    const Application_type = "\117\x41\x55\124\x48";
    const Version = "\61\70\56\x34\x2e\x39";
    const HOSTNAME = "\x68\164\x74\x70\163\72\x2f\x2f\x6c\x6f\147\x69\156\x2e\170\145\x63\165\x72\151\146\171\56\143\x6f\155";
    const LICENSE_TYPE = "\x57\x50\137\117\x41\x55\124\110\x5f\103\114\111\105\x4e\x54\137\123\x54\x41\x4e\x44\x41\x52\x44\x5f\120\114\x55\x47\111\x4e";
    const LICENSE_PLAN_NAME = "\x77\x70\137\157\141\165\x74\150\x5f\143\x6c\151\x65\156\x74\137\163\x74\x61\156\x64\x61\162\144\137\x70\154\x61\156";
}
