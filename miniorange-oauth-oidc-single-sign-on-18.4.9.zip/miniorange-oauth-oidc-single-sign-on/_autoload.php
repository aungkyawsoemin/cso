<?php


if (defined("\101\x42\123\x50\x41\x54\x48")) {
    goto Qr;
}
exit;
Qr:
define("\115\x4f\103\x5f\104\111\x52", plugin_dir_path(__FILE__));
define("\x4d\x4f\x43\137\125\122\x4c", plugin_dir_url(__FILE__));
define("\115\x4f\137\x55\111\104", "\104\106\x38\x56\x4b\112\117\65\x46\x44\x48\132\x41\122\102\122\65\132\x44\123\x32\126\x35\x4a\66\66\125\62\116\x44\122");
define("\126\x45\122\x53\111\117\116", "\x6d\157\137\x73\x74\x61\x6e\144\x61\162\144\137\x76\x65\x72\163\151\157\x6e");
mo_oauth_include_file(MOC_DIR . "\57\143\x6c\141\x73\163\x65\x73\x2f\x63\157\155\x6d\x6f\156");
mo_oauth_include_file(MOC_DIR . "\x2f\x63\154\x61\x73\163\x65\163\57\x46\x72\145\145");
mo_oauth_include_file(MOC_DIR . "\57\x63\154\141\163\x73\145\163\x2f\x53\164\141\156\x64\x61\x72\144");
mo_oauth_include_file(MOC_DIR . "\57\143\154\141\x73\x73\145\x73\57\x50\x72\145\x6d\151\165\x6d");
mo_oauth_include_file(MOC_DIR . "\x2f\x63\x6c\x61\163\x73\145\163\57\x45\x6e\x74\145\x72\x70\162\x69\x73\145");
function mo_oauth_get_dir_contents($dO, &$fU = array())
{
    foreach (new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dO, RecursiveDirectoryIterator::KEY_AS_PATHNAME), RecursiveIteratorIterator::CHILD_FIRST) as $y4 => $Is) {
        if (!($Is->isFile() && $Is->isReadable())) {
            goto cZ;
        }
        $fU[$y4] = realpath($Is->getPathname());
        cZ:
        Lt:
    }
    vZ:
    return $fU;
}
function mo_oauth_get_sorted_files($dO)
{
    $Ec = mo_oauth_get_dir_contents($dO);
    $N2 = array();
    $aG = array();
    foreach ($Ec as $y4 => $mh) {
        if (!(strpos($mh, "\56\160\x68\x70") !== false)) {
            goto Tc;
        }
        if (strpos($mh, "\x49\x6e\164\x65\x72\x66\141\x63\145") !== false) {
            goto hN;
        }
        $aG[$y4] = $mh;
        goto K9;
        hN:
        $N2[$y4] = $mh;
        K9:
        Tc:
        oy:
    }
    k2:
    return array("\151\156\x74\145\162\146\141\x63\x65\x73" => $N2, "\x63\x6c\141\x73\163\145\x73" => $aG);
}
function mo_oauth_include_file($dO)
{
    if (is_dir($dO)) {
        goto Tg;
    }
    return;
    Tg:
    $dO = mo_oauth_sane_dir_path($dO);
    $Nj = realpath($dO);
    if (!(false !== $Nj && !is_dir($dO))) {
        goto cc;
    }
    return;
    cc:
    $E0 = mo_oauth_get_sorted_files($dO);
    mo_oauth_require_all($E0["\151\x6e\164\145\x72\x66\x61\x63\x65\163"]);
    mo_oauth_require_all($E0["\x63\x6c\141\x73\163\x65\x73"]);
}
function mo_oauth_require_all($Ec)
{
    foreach ($Ec as $y4 => $mh) {
        require_once $mh;
        dH:
    }
    dk:
}
function mo_oauth_is_valid_file($TD)
{
    return '' !== $TD && "\x2e" !== $TD && "\56\x2e" !== $TD;
}
function mo_oauth_get_valid_html($nK = array())
{
    $XT = array("\x73\164\162\157\x6e\147" => array(), "\x65\x6d" => array(), "\x62" => array(), "\151" => array(), "\141" => array("\x68\162\x65\146" => array(), "\164\x61\162\147\145\164" => array()));
    if (empty($nK)) {
        goto JF;
    }
    return array_merge($nK, $XT);
    JF:
    return $XT;
}
function mo_oauth_get_version_number()
{
    $oh = get_file_data(MOC_DIR . "\x2f\x6d\157\x5f\157\141\x75\164\x68\137\x73\x65\x74\x74\x69\156\147\163\56\160\x68\x70", ["\x56\x65\x72\163\151\x6f\156"], "\160\154\x75\147\151\156");
    $kH = isset($oh[0]) ? $oh[0] : '';
    return $kH;
}
function mo_oauth_sane_dir_path($dO)
{
    return str_replace("\x2f", DIRECTORY_SEPARATOR, $dO);
}
if (!function_exists("\x6d\157\137\x6f\141\x75\x74\x68\x5f\151\x73\137\x72\145\x73\x74")) {
    function mo_oauth_is_rest()
    {
        $Zn = rest_get_url_prefix();
        if (!(defined("\122\x45\x53\x54\137\122\105\121\x55\x45\123\124") && REST_REQUEST || isset($_GET["\x72\x65\163\164\137\162\x6f\165\164\145"]) && strpos(trim($_GET["\162\x65\x73\164\x5f\x72\x6f\165\164\x65"], "\134\x2f"), $Zn, 0) === 0)) {
            goto nE;
        }
        return true;
        nE:
        global $m0;
        if (!($m0 === null)) {
            goto hD;
        }
        $m0 = new WP_Rewrite();
        hD:
        $tX = wp_parse_url(trailingslashit(rest_url()));
        $bJ = wp_parse_url(add_query_arg(array()));
        return strpos($bJ["\x70\x61\164\x68"], $tX["\160\x61\x74\150"], 0) === 0;
    }
}
