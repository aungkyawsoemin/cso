<?php


if (defined("\127\120\x49\x4e\103")) {
    goto N2;
}
die;
N2:
