<?php


namespace MoOauthClient\Standard;

use MoOauthClient\LoginHandler as FreeLoginHandler;
use MoOauthClient\Config;
use MoOauthClient\StorageManager;
use MoOauthClient\MO_Oauth_Debug;
class LoginHandler extends FreeLoginHandler
{
    public $config;
    public function handle_group_test_conf($ET = array(), $Cf = array(), $k_ = '', $qX = false, $pK = false)
    {
        global $Uc;
        $this->render_test_config_output($ET, false);
        if (!(!isset($Cf["\x67\x72\157\165\160\x64\145\x74\x61\151\154\163\x75\162\x6c"]) || '' === $Cf["\147\162\x6f\x75\160\x64\145\164\x61\151\154\x73\165\162\154"])) {
            goto ZC;
        }
        return;
        ZC:
        $aM = [];
        $IX = $Cf["\x67\x72\157\x75\x70\144\x65\164\141\x69\154\163\x75\x72\x6c"];
        if (!(strpos($IX, "\141\160\151\56\x63\154\x65\166\145\162\56\143\x6f\155") != false && isset($ET["\x64\x61\164\x61"]["\151\144"]))) {
            goto Xy;
        }
        $IX = str_replace("\x75\x73\x65\x72\x69\x64", $ET["\x64\x61\164\x61"]["\151\144"], $IX);
        Xy:
        MO_Oauth_Debug::mo_oauth_log("\x47\162\x6f\165\x70\40\x44\145\x74\141\x69\x6c\163\40\x55\x52\114\72\x20" . $IX);
        if (!('' === $k_)) {
            goto pK;
        }
        if (has_filter("\155\x6f\137\x6f\141\165\164\150\137\143\x66\x61\x5f\x67\162\x6f\165\160\137\x64\145\164\141\151\x6c\x73")) {
            goto BC;
        }
        MO_Oauth_Debug::mo_oauth_log("\x41\143\x63\x65\x73\x73\40\x54\x6f\153\x65\x6e\40\105\x6d\160\164\x79");
        return;
        BC:
        pK:
        if (!('' !== $IX)) {
            goto Xd;
        }
        if (has_filter("\155\157\137\157\141\x75\164\x68\x5f\x63\x66\x61\x5f\147\x72\157\x75\x70\137\x64\x65\164\x61\151\154\x73")) {
            goto uf;
        }
        if (has_filter("\x6d\x6f\137\157\x61\165\164\x68\x5f\147\x72\157\x75\x70\137\144\145\x74\x61\x69\x6c\x73")) {
            goto RA;
        }
        if (has_filter("\155\x6f\137\x6f\141\165\x74\x68\137\162\x61\x76\x65\x6e\137\147\x72\157\165\x70\x5f\x64\145\164\x61\x69\x6c\x73")) {
            goto BD;
        }
        $aM = $this->oauth_handler->get_resource_owner($IX, $k_);
        goto S9;
        BD:
        $aM = apply_filters("\x6d\157\137\157\141\165\x74\150\x5f\x72\141\x76\145\156\137\147\162\x6f\165\x70\137\144\145\164\x61\x69\x6c\x73", $ET["\145\x6d\141\151\154"], $IX, $k_, $Cf, $qX);
        S9:
        goto ny;
        RA:
        $aM = apply_filters("\x6d\157\137\157\x61\x75\164\x68\137\x67\x72\x6f\x75\x70\x5f\144\145\164\141\x69\x6c\163", $IX, $k_, $Cf, $qX);
        ny:
        goto wz;
        uf:
        MO_Oauth_Debug::mo_oauth_log("\106\x65\x74\143\150\151\156\147\x20\x43\x46\101\40\107\x72\x6f\165\x70\56\x2e");
        $aM = apply_filters("\155\x6f\137\x6f\x61\x75\164\x68\137\x63\146\141\x5f\x67\162\157\x75\x70\x5f\144\145\164\141\x69\x6c\163", $ET, $IX, $k_, $Cf, $qX);
        wz:
        $lc = $Uc->mo_oauth_client_get_option("\x6d\157\x5f\x6f\141\165\164\150\x5f\141\164\164\162\137\156\141\x6d\x65\137\154\x69\x73\x74" . $Cf["\x61\160\160\x49\144"]);
        $EU = [];
        $bj = $this->dropdownattrmapping('', $aM, $EU);
        $lc = (array) $lc + $bj;
        $Uc->mo_oauth_client_update_option("\155\x6f\137\157\141\165\164\x68\137\141\x74\164\x72\137\156\x61\155\145\x5f\x6c\x69\x73\164" . $Cf["\141\160\x70\111\x64"], $lc);
        if (!($pK && '' !== $pK)) {
            goto SJ;
        }
        if (!(is_array($aM) && !empty($aM))) {
            goto bM;
        }
        $this->render_test_config_output($aM, true);
        bM:
        return;
        SJ:
        Xd:
    }
    public function handle_group_user_info($ET, $Cf, $k_)
    {
        if (!(!isset($Cf["\147\x72\157\165\x70\144\145\164\141\x69\x6c\x73\165\x72\x6c"]) || '' === $Cf["\x67\x72\157\x75\160\144\x65\164\141\x69\x6c\163\x75\162\x6c"])) {
            goto Qx;
        }
        return $ET;
        Qx:
        $IX = $Cf["\x67\162\157\x75\160\144\x65\x74\x61\x69\154\163\165\162\154"];
        if (!(strpos($IX, "\x61\x70\x69\56\143\154\145\166\145\x72\x2e\x63\x6f\155") != false && isset($ET["\144\141\x74\141"]["\x69\144"]))) {
            goto Zy;
        }
        $IX = str_replace("\x75\x73\145\162\x69\144", $ET["\x64\x61\x74\141"]["\151\x64"], $IX);
        Zy:
        if (!('' === $k_)) {
            goto kC;
        }
        return $ET;
        kC:
        $aM = array();
        if (!('' !== $IX)) {
            goto bj;
        }
        if (has_filter("\x6d\157\x5f\157\x61\x75\164\150\137\143\x66\141\x5f\x67\162\157\165\x70\x5f\x64\x65\164\x61\151\x6c\163")) {
            goto r8;
        }
        if (has_filter("\155\x6f\x5f\157\141\x75\164\x68\137\147\x72\x6f\165\160\137\x64\145\x74\141\x69\x6c\x73")) {
            goto pA;
        }
        if (has_filter("\155\x6f\137\157\x61\x75\x74\x68\x5f\162\x61\166\x65\156\137\147\x72\157\x75\x70\137\144\x65\164\141\151\x6c\163")) {
            goto eW;
        }
        $aM = $this->oauth_handler->get_resource_owner($IX, $k_);
        goto JT;
        eW:
        $aM = apply_filters("\155\157\137\157\x61\165\164\150\137\162\x61\166\145\x6e\137\147\162\157\165\x70\x5f\144\145\x74\141\151\x6c\163", $ET["\145\155\x61\x69\154"], $IX, $k_, $Cf, $qX);
        JT:
        goto Ml;
        pA:
        $aM = apply_filters("\x6d\x6f\137\157\141\x75\x74\x68\137\x67\162\x6f\165\x70\137\x64\x65\164\141\x69\x6c\163", $IX, $k_, $Cf);
        Ml:
        goto Oa;
        r8:
        MO_Oauth_Debug::mo_oauth_log("\x46\145\x74\x63\150\x69\156\x67\40\103\106\101\x20\107\162\157\165\x70\56\x2e");
        $aM = apply_filters("\155\157\137\x6f\141\165\x74\150\x5f\143\x66\141\137\x67\x72\157\x75\x70\x5f\144\145\x74\141\x69\x6c\163", $ET, $IX, $k_, $Cf, $qX);
        Oa:
        bj:
        MO_Oauth_Debug::mo_oauth_log("\x47\x72\x6f\165\x70\x20\104\x65\164\x61\x69\x6c\163\x20\75\76\x20");
        MO_Oauth_Debug::mo_oauth_log($aM);
        if (!(is_array($aM) && count($aM) > 0)) {
            goto nY;
        }
        $ET = array_merge_recursive($ET, $aM);
        nY:
        MO_Oauth_Debug::mo_oauth_log("\122\x65\x73\x6f\165\162\143\145\x20\117\167\x6e\x65\x72\x20\x41\146\164\x65\162\40\155\x65\x72\147\151\x6e\x67\40\x77\x69\164\150\x20\x47\162\157\x75\160\x20\144\145\164\x69\x61\154\163\40\x3d\x3e\40");
        MO_Oauth_Debug::mo_oauth_log($ET);
        return $ET;
    }
    public function mo_oauth_client_map_default_role($KK, $Cf)
    {
        $di = new \WP_User($KK);
        if (!(isset($Cf["\x65\156\141\x62\154\145\137\162\157\x6c\145\137\x6d\141\x70\160\151\156\x67"]) && !boolval($Cf["\145\156\x61\x62\x6c\x65\137\162\157\x6c\145\x5f\x6d\x61\x70\160\x69\156\147"]))) {
            goto r_;
        }
        $di->set_role('');
        return;
        r_:
        if (!(isset($Cf["\x5f\155\141\160\160\151\x6e\147\137\x76\141\154\165\145\137\144\145\146\x61\x75\154\164"]) && '' !== $Cf["\137\155\141\x70\160\x69\x6e\x67\137\x76\x61\x6c\165\145\137\x64\x65\x66\141\165\x6c\x74"])) {
            goto Nz;
        }
        $di->set_role($Cf["\137\155\x61\x70\160\151\156\x67\x5f\x76\x61\154\x75\145\x5f\x64\x65\146\141\165\x6c\x74"]);
        Nz:
    }
    public function handle_sso($M9, $Cf, $ET, $Q7, $dK, $xU = false)
    {
        global $Uc;
        $zQ = new StorageManager($Q7);
        do_action("\x6d\x6f\137\x6f\141\165\x74\150\x5f\154\x69\x6e\x6b\137\144\151\x73\143\157\162\x64\x5f\x61\143\x63\x6f\x75\x6e\164", $zQ, $ET);
        $Kz = isset($Cf["\165\x73\145\162\x6e\x61\155\145\137\x61\x74\164\x72"]) ? $Cf["\165\x73\145\x72\x6e\x61\x6d\x65\x5f\141\164\x74\x72"] : '';
        $X9 = isset($Cf["\x65\x6d\141\x69\154\x5f\141\164\x74\x72"]) ? $Cf["\145\155\x61\151\154\x5f\x61\x74\164\162"] : '';
        $UI = isset($Cf["\x66\151\162\x73\x74\x6e\x61\155\145\x5f\x61\164\x74\x72"]) ? $Cf["\146\151\162\163\164\x6e\x61\155\x65\137\141\164\164\162"] : '';
        $yY = isset($Cf["\154\x61\x73\164\156\x61\155\x65\137\x61\x74\x74\x72"]) ? $Cf["\x6c\x61\163\x74\156\141\x6d\145\x5f\x61\x74\x74\x72"] : '';
        $k1 = isset($Cf["\x64\x69\163\160\x6c\141\x79\137\x61\x74\x74\x72"]) ? $Cf["\x64\x69\x73\160\x6c\x61\171\137\141\x74\164\x72"] : '';
        $w5 = $Uc->getnestedattribute($ET, $Kz);
        $gK = $Uc->getnestedattribute($ET, $X9);
        $at = $Uc->getnestedattribute($ET, $UI);
        $Bl = $Uc->getnestedattribute($ET, $yY);
        $jT = $w5;
        $this->config = $Uc->mo_oauth_client_get_option("\155\x6f\137\x6f\x61\x75\164\150\137\x63\x6c\x69\145\x6e\164\x5f\x63\157\156\x66\x69\x67");
        $this->config = !$this->config || empty($this->config) ? array() : $this->config->get_current_config();
        $jD = isset($this->config["\x61\x63\164\151\x76\141\x74\145\137\x75\x73\x65\162\x5f\141\156\x61\154\x79\x74\151\143\163"]) ? $this->config["\x61\x63\164\151\x76\141\x74\x65\137\x75\x73\x65\162\x5f\141\156\141\x6c\171\164\x69\x63\163"] : 0;
        $current_user = wp_get_current_user();
        if (!($current_user->ID !== 0)) {
            goto sQ;
        }
        do_action("\x6d\157\137\157\141\x75\164\150\137\144\x69\163\143\157\162\144\x5f\x66\x6c\157\167\137\x68\141\156\144\154\x65", $current_user, $dK, $ET);
        do_action("\x6d\x6f\x5f\x6f\141\165\164\x68\x5f\x6c\x6f\x67\x67\145\x64\137\x69\156\x5f\165\163\145\162\x5f\x74\x61\147\x5f\165\160\144\x61\164\x65", $current_user, $dK, $ET);
        $MI = get_option("\155\157\x5f\x64\162\155\137\x73\x79\x6e\143\x5f\162\x65\x64\x69\162\x65\x63\x74");
        if (!(isset($MI) && $MI)) {
            goto Pf;
        }
        wp_redirect($MI);
        exit;
        Pf:
        sQ:
        if (empty($k1)) {
            goto em;
        }
        switch ($k1) {
            case "\106\x4e\x41\115\x45":
                $jT = $at;
                goto wj;
            case "\x4c\x4e\x41\x4d\x45":
                $jT = $Bl;
                goto wj;
            case "\x55\x53\105\x52\116\101\x4d\x45":
                $jT = $w5;
                goto wj;
            case "\106\116\x41\115\105\x5f\x4c\116\101\x4d\x45":
                $jT = $at . "\x20" . $Bl;
                goto wj;
            case "\114\116\x41\115\x45\x5f\x46\x4e\101\x4d\x45":
                $jT = $Bl . "\x20" . $at;
            default:
                goto wj;
        }
        l1:
        wj:
        em:
        if (!empty($w5)) {
            goto q_;
        }
        MO_Oauth_Debug::mo_oauth_log("\x55\163\x65\162\156\141\155\145\x20\72\40" . $w5);
        $this->check_status(array("\155\163\x67" => "\125\163\x65\x72\156\x61\x6d\x65\40\156\x6f\164\40\x72\x65\143\145\151\166\x65\x64\56\40\103\x68\x65\x63\x6b\x20\x79\x6f\165\x72\x20\x3c\163\x74\x72\x6f\156\x67\x3e\101\164\x74\x72\x69\142\165\x74\145\x20\115\x61\160\160\x69\156\x67\74\x2f\x73\164\x72\157\x6e\x67\76\40\x63\157\156\146\x69\147\x75\x72\141\164\x69\x6f\x6e\x2e", "\x63\x6f\144\x65" => "\x55\116\x41\115\x45", "\163\164\x61\x74\x75\x73" => false, "\x61\160\x70\x6c\x69\143\x61\x74\x69\x6f\x6e" => $M9, "\x65\155\141\x69\154" => '', "\165\x73\145\162\156\x61\x6d\x65" => ''), $jD);
        q_:
        if (!(!empty($gK) && false === strpos($gK, "\x40"))) {
            goto O_;
        }
        $this->check_status(array("\x6d\x73\x67" => "\115\141\160\x70\145\x64\x20\x45\x6d\141\x69\x6c\40\141\164\x74\x72\x69\x62\165\164\145\40\x64\157\145\x73\x20\156\x6f\164\40\143\157\x6e\x74\x61\x69\156\40\x76\x61\154\151\144\40\145\155\x61\x69\x6c\x2e", "\143\157\144\145" => "\105\115\x41\111\114", "\x73\164\141\x74\x75\163" => false, "\x61\160\160\x6c\x69\x63\141\164\x69\x6f\x6e" => $M9, "\x63\x6c\x69\x65\x6e\x74\x5f\151\x70" => $Uc->get_client_ip(), "\145\155\141\151\x6c" => $gK, "\165\163\145\x72\x6e\x61\x6d\x65" => $w5), $jD);
        O_:
        if (!is_multisite()) {
            goto C4;
        }
        $blog_id = $zQ->get_value("\x62\x6c\157\x67\x5f\151\144");
        switch_to_blog($blog_id);
        do_action("\x6d\x6f\x5f\x6f\141\x75\x74\x68\137\x63\x6c\151\145\x6e\164\137\x63\157\156\143\157\x72\144\137\162\145\163\x74\x72\151\x63\164\x5f\154\157\147\151\x6e", $Cf, $ET, $blog_id);
        C4:
        do_action("\x6d\157\x5f\157\141\x75\x74\x68\137\162\x65\163\x74\162\151\x63\x74\137\x65\x6d\x61\151\154\x73", $gK, $this->config);
        if (!has_filter("\155\157\137\x6f\x61\165\x74\150\x5f\x6d\x6f\x64\151\146\171\x5f\165\163\x65\x72\156\x61\155\x65\137\x61\x74\164\x72")) {
            goto OU;
        }
        $w5 = apply_filters("\x6d\x6f\x5f\157\141\x75\x74\x68\x5f\x6d\x6f\x64\151\146\171\x5f\165\x73\145\162\156\x61\x6d\145\137\x61\164\x74\162", $ET);
        OU:
        $user = get_user_by("\x6c\157\147\151\x6e", $w5);
        $CQ = isset($Cf["\141\154\x6c\x6f\167\x5f\x64\165\x70\x6c\x69\x63\141\164\x65\137\x65\155\x61\x69\154\163"]) ? true : false;
        if ($user) {
            goto Qm;
        }
        if (!(!$CQ || $CQ && !$Cf["\141\x6c\154\157\x77\137\144\x75\160\154\151\x63\x61\164\x65\x5f\145\x6d\x61\x69\x6c\163"])) {
            goto WZ;
        }
        $user = get_user_by("\x65\x6d\141\x69\154", $gK);
        WZ:
        Qm:
        $KK = $user ? $user->ID : 0;
        $s8 = 0 === $KK;
        if (!has_filter("\155\x6f\137\x6f\x61\165\164\150\137\147\x65\x74\137\x75\163\145\x72\x5f\142\171\137\145\155\141\151\x6c")) {
            goto wr;
        }
        $user = apply_filters("\x6d\x6f\x5f\157\141\x75\x74\x68\x5f\x67\x65\164\x5f\165\x73\x65\162\137\x62\171\137\x65\155\141\x69\154", $w5, $gK);
        wr:
        if (!has_filter("\x6d\x6f\137\x6f\x61\x75\164\x68\x5f\x63\x68\x65\x63\x6b\x5f\x75\x73\145\162\x5f\142\171\x5f\x65\155\141\x69\154")) {
            goto rn;
        }
        $s8 = apply_filters("\155\x6f\137\157\141\x75\x74\150\137\x63\x68\x65\143\x6b\137\165\x73\145\162\x5f\x62\x79\137\145\x6d\141\151\x6c", $w5, $gK);
        rn:
        $KK = $user ? $user->ID : 0;
        if (!(isset($Cf["\141\x75\164\x6f\143\162\x65\x61\164\145\165\163\145\x72\163"]) && 1 !== intval($Cf["\x61\x75\164\157\143\162\x65\x61\x74\145\x75\x73\145\x72\163"]))) {
            goto Gw;
        }
        $blog_id = 1;
        $Vl = apply_filters("\155\x6f\x5f\x6f\141\165\164\x68\x5f\x63\x6c\151\145\x6e\x74\x5f\x64\151\x73\x61\x62\154\145\137\x61\165\x74\x6f\137\143\x72\145\141\164\x65\137\x75\x73\x65\162\163\137\146\157\162\137\163\160\145\143\x69\146\151\143\137\151\x64\160", $KK, $blog_id, $this->config, $Cf);
        $this->config = $Vl[0];
        $Cf = $Vl[1];
        Gw:
        if (!(!(isset($this->config["\141\x75\x74\x6f\x5f\162\145\x67\151\x73\x74\x65\162"]) && 1 === intval($this->config["\x61\165\x74\157\x5f\x72\145\147\151\x73\164\145\162"])) && $s8)) {
            goto Sz;
        }
        $this->check_status(array("\155\163\x67" => "\x52\x65\147\x69\x73\164\162\x61\164\x69\157\x6e\40\x69\x73\40\144\151\x73\141\x62\x6c\x65\144\x20\x66\157\162\x20\x74\150\151\163\x20\x73\151\164\145\56\40\120\x6c\145\x61\x73\x65\40\143\x6f\x6e\x74\141\x63\x74\40\x79\x6f\x75\x72\x20\x61\144\x6d\x69\156\x69\x73\x74\162\141\x74\157\x72", "\x63\157\x64\145" => "\x52\x45\x47\x49\x53\124\x52\101\124\111\x4f\x4e\x5f\104\x49\123\x41\102\x4c\x45\104", "\x73\x74\x61\x74\165\163" => false, "\x61\160\x70\154\151\143\141\x74\151\157\156" => $M9, "\143\154\x69\x65\156\164\137\151\x70" => $Uc->get_client_ip(), "\145\x6d\x61\x69\x6c" => $gK, "\165\163\x65\162\x6e\x61\x6d\x65" => $w5), $jD);
        Sz:
        if (!$s8) {
            goto c4;
        }
        $GO = 10;
        $cv = false;
        $HK = false;
        $K9 = apply_filters("\x6d\x6f\137\157\141\165\x74\x68\x5f\x70\141\163\x73\167\x6f\162\144\x5f\160\x6f\154\151\x63\x79\137\155\141\156\x61\147\145\x72", $GO);
        if (!is_array($K9)) {
            goto nm;
        }
        $GO = intval($K9["\160\x61\x73\x73\167\157\162\x64\x5f\x6c\145\156\147\x74\x68"]);
        $cv = $K9["\x73\160\145\143\151\x61\x6c\x5f\x63\x68\141\x72\x61\143\x74\x65\x72\163"];
        $HK = $K9["\145\x78\164\162\x61\137\x73\160\x65\x63\x69\x61\154\x5f\143\150\141\x72\x61\143\x74\x65\162\163"];
        nm:
        $d2 = wp_generate_password($GO, $cv, $HK);
        $XU = get_user_by("\x65\x6d\141\x69\154", $gK);
        if (!$XU) {
            goto aU;
        }
        add_filter("\x70\x72\145\137\x75\x73\x65\x72\137\145\x6d\x61\x69\x6c", array($this, "\x73\x6b\x69\160\137\x65\155\x61\x69\x6c\137\145\170\x69\163\164"), 30);
        aU:
        $w5 = apply_filters("\155\157\x5f\x6f\141\x75\164\x68\x5f\147\145\x74\137\x75\163\x65\x72\x6e\x61\155\x65\x5f\167\151\x74\x68\x5f\160\x6f\163\164\146\x69\170\x5f\x61\144\x64\x65\144", $w5, $gK);
        $KK = wp_create_user($w5, $d2, $gK);
        if (!is_wp_error($KK)) {
            goto fo;
        }
        MO_Oauth_Debug::mo_oauth_log("\105\162\162\157\162\x20\x63\162\145\141\x74\x69\156\147\x20\127\x50\40\165\163\145\x72");
        goto K2;
        fo:
        MO_Oauth_Debug::mo_oauth_log("\x4e\145\167\x20\165\163\x65\162\40\x63\x72\145\x61\164\x65\144\x20\x3d\x3e");
        MO_Oauth_Debug::mo_oauth_log("\125\163\x65\x72\40\x49\104\x20\75\76\x20" . $KK);
        K2:
        $r8 = array("\111\x44" => $KK, "\165\x73\145\x72\137\145\x6d\x61\151\x6c" => $gK, "\x75\163\145\x72\137\154\x6f\x67\x69\156" => $w5, "\165\163\x65\162\137\x6e\x69\143\x65\156\141\x6d\x65" => $w5);
        do_action("\x75\163\145\x72\137\162\x65\147\x69\163\x74\x65\162", $KK, $r8);
        c4:
        if (!($s8 || (!isset($this->config["\153\145\x65\160\137\x65\170\151\x73\x74\x69\156\147\137\165\x73\145\x72\x73"]) || 1 !== intval($this->config["\153\x65\145\160\137\145\x78\151\163\x74\x69\156\147\x5f\165\163\x65\x72\x73"])))) {
            goto A8;
        }
        if (!is_wp_error($KK)) {
            goto bD;
        }
        if (!get_user_by("\x6c\157\147\151\156", $w5)) {
            goto l8;
        }
        $KK = get_user_by("\x6c\157\147\151\x6e", $w5)->ID;
        l8:
        bD:
        $ad = array("\111\x44" => $KK, "\x66\151\x72\163\x74\x5f\156\x61\x6d\x65" => $at, "\154\141\163\164\x5f\156\x61\155\145" => $Bl, "\144\x69\x73\160\x6c\x61\x79\x5f\156\x61\x6d\145" => $jT, "\165\x73\145\162\137\x6c\157\147\x69\156" => $w5, "\x75\163\x65\x72\x5f\156\x69\x63\145\x6e\x61\x6d\x65" => $w5);
        if (isset($this->config["\x6b\145\x65\x70\x5f\x65\170\151\x73\164\151\156\147\x5f\145\x6d\x61\151\154\137\x61\164\x74\162"]) && 1 === intval($this->config["\x6b\145\x65\160\x5f\145\170\x69\x73\x74\151\156\x67\x5f\x65\x6d\141\151\x6c\x5f\141\164\x74\162"])) {
            goto vs;
        }
        $ad["\x75\163\145\x72\137\x65\155\141\x69\154"] = $gK;
        wp_update_user($ad);
        MO_Oauth_Debug::mo_oauth_log("\101\x74\x74\x72\151\142\165\164\x65\40\115\x61\160\160\151\x6e\147\40\x44\x6f\156\x65");
        goto aH;
        vs:
        wp_update_user($ad);
        MO_Oauth_Debug::mo_oauth_log("\x41\x74\164\x72\x69\142\165\164\x65\x20\115\x61\x70\160\x69\156\147\40\x44\157\156\145");
        aH:
        if (!isset($ET["\163\x75\142"])) {
            goto op;
        }
        update_user_meta($KK, "\155\157\137\x62\141\143\153\143\x68\141\156\156\145\x6c\137\141\164\164\x72\137\163\x75\x62", $ET["\163\x75\x62"]);
        op:
        if (!isset($ET["\x73\x69\x64"])) {
            goto i3;
        }
        update_user_meta($KK, "\155\157\137\142\141\x63\153\x63\150\x61\x6e\156\145\x6c\137\141\x74\x74\162\x5f\163\151\x64", $ET["\163\151\x64"]);
        i3:
        update_user_meta($KK, "\x6d\x6f\137\x6f\141\165\164\150\137\142\165\144\144\x79\x70\x72\x65\x73\163\137\141\x74\x74\x72\x69\142\165\x74\x65\163", $ET);
        MO_Oauth_Debug::mo_oauth_log("\x42\x75\x64\144\171\120\162\x65\x73\163\40\141\x74\x74\x72\x69\x62\x75\164\x65\x73\x20\x75\160\144\141\x74\145\144\x20\163\165\x63\x63\x65\163\163\x66\165\x6c\x6c\171");
        A8:
        $user = get_user_by("\x49\104", $KK);
        MO_Oauth_Debug::mo_oauth_log("\125\163\x65\162\40\x46\x6f\165\x6e\x64");
        MO_Oauth_Debug::mo_oauth_log("\125\x73\x65\x72\40\111\x44\40\x3d\x3e\40" . $KK);
        $rM = $Uc->is_multisite_plan();
        if (!is_multisite()) {
            goto I1;
        }
        MO_Oauth_Debug::mo_oauth_log("\115\165\x6c\x74\x69\163\x69\x74\x65\x20\x50\154\x61\x6e");
        $dU = $Uc->mo_oauth_client_get_option("\x6d\157\x5f\157\141\x75\164\x68\x5f\x63\63\126\x69\143\62\x6c\60\132\x58\116\x7a\132\x57\170\x6c\x59\x33\x52\154\x5a\101");
        $AU = array();
        if (!isset($dU)) {
            goto NN;
        }
        $AU = json_decode($Uc->mooauthdecrypt($dU), true);
        NN:
        $ce = false;
        if (!(is_array($AU) && in_array($blog_id, $AU))) {
            goto Ui;
        }
        $ce = true;
        Ui:
        $YB = intval($Uc->mo_oauth_client_get_option("\156\x6f\x4f\146\123\165\x62\x53\151\x74\x65\x73"));
        $JM = get_sites(["\156\165\x6d\142\x65\x72" => 1000]);
        if (!(is_multisite() && $rM && ($rM && !$ce && $YB < 1000))) {
            goto Vu;
        }
        $eC = "\x59\x6f\x75\40\x68\x61\166\145\x20\156\157\164\x20\x75\x70\x67\162\x61\144\x65\144\40\x74\157\40\164\150\145\40\143\x6f\x72\x72\x65\143\x74\40\x6c\151\143\x65\156\163\145\x20\160\154\x61\x6e\x2e\x20\105\151\x74\150\x65\x72\40\x79\x6f\165\x20\150\x61\166\145\40\x70\165\162\143\x68\x61\x73\145\144\x20\x66\x6f\x72\40\151\x6e\x63\157\x72\x72\x65\x63\x74\x20\156\157\x2e\x20\x6f\x66\40\163\151\x74\x65\163\40\x6f\x72\x20\x79\x6f\x75\x20\x68\x61\x76\x65\x20\x63\162\145\141\164\145\x64\x20\x61\x20\x6e\x65\x77\x20\x73\165\142\163\151\x74\x65\x2e\40\x43\157\156\x74\141\x63\164\40\x74\x6f\40\171\x6f\165\x72\x20\141\x64\x6d\x69\x6e\x69\163\x74\x72\141\x74\157\x72\40\164\x6f\40\x75\160\x67\x72\x61\x64\x65\40\x79\157\165\162\x20\x73\x75\142\163\151\164\x65\56";
        MO_Oauth_Debug::mo_oauth_log($eC);
        $Uc->handle_error($eC);
        wp_die($eC);
        Vu:
        I1:
        if ($user) {
            goto w5;
        }
        return;
        w5:
        $QT = '';
        if (isset($this->config["\x61\x66\164\145\162\x5f\154\157\147\151\x6e\137\x75\x72\154"]) && '' !== $this->config["\x61\x66\x74\145\162\137\154\157\x67\151\156\137\165\162\x6c"]) {
            goto wa;
        }
        $b0 = $zQ->get_value("\x72\x65\144\x69\x72\x65\x63\x74\x5f\165\162\x69");
        $H2 = parse_url($b0);
        if (!(isset($H2["\x70\x61\164\150"]) && strpos($H2["\160\141\x74\150"], "\167\160\55\x6c\157\x67\x69\x6e\x2e\160\150\160") !== false)) {
            goto Gc;
        }
        $b0 = site_url();
        Gc:
        if (!isset($H2["\x71\x75\145\162\x79"])) {
            goto dZ;
        }
        parse_str($H2["\161\165\x65\x72\x79"], $Oe);
        if (!isset($Oe["\x72\145\144\151\162\145\143\x74\x5f\x74\157"])) {
            goto ps;
        }
        $b0 = $Oe["\x72\145\144\151\162\x65\x63\x74\137\x74\157"];
        ps:
        dZ:
        $QT = rawurldecode($b0 && '' !== $b0 ? $b0 : site_url());
        $QT = apply_filters("\155\x6f\x5f\x6f\141\x75\164\150\137\144\151\x73\137\x75\160\144\x61\164\x65\137\141\x63\164\165\141\154\137\x6c\x69\x6e\x6b", $QT, $w5);
        goto SP;
        wa:
        $QT = $this->config["\141\x66\164\x65\162\x5f\154\x6f\x67\151\x6e\137\x75\162\x6c"];
        SP:
        if (!($Uc->get_versi() === 1)) {
            goto lo;
        }
        if (isset($Cf["\145\156\141\x62\154\x65\137\x72\x6f\154\x65\137\155\141\160\160\x69\x6e\x67"])) {
            goto ce;
        }
        $Cf["\x65\156\x61\x62\154\145\137\x72\x6f\154\145\137\x6d\141\x70\x70\x69\156\x67"] = true;
        if (!(isset($Cf["\x63\154\151\145\156\x74\x5f\143\162\145\144\x73\137\x65\x6e\143\x72\160\171\x74\145\144"]) && boolval($Cf["\x63\154\x69\145\x6e\164\x5f\x63\162\145\x64\163\x5f\145\156\x63\162\x70\171\x74\x65\144"]))) {
            goto Tk;
        }
        $Cf["\x63\x6c\151\x65\156\164\137\x69\x64"] = $Uc->mooauthencrypt($Cf["\143\154\151\x65\x6e\164\x5f\x69\x64"]);
        $Cf["\143\154\151\145\156\x74\137\x73\x65\x63\x72\x65\x74"] = $Uc->mooauthencrypt($Cf["\143\x6c\151\145\x6e\164\x5f\x73\145\x63\162\145\x74"]);
        Tk:
        $Uc->set_app_by_name($nK["\x61\x70\x70\x5f\x6e\x61\x6d\x65"], $Cf);
        ce:
        if (!(!user_can($KK, "\141\144\155\x69\156\x69\x73\x74\162\141\164\157\x72") && $s8 || !isset($Cf["\153\x65\x65\x70\x5f\x65\x78\151\163\164\151\156\147\137\165\x73\145\162\x5f\162\157\154\x65\x73"]) || 1 !== intval($Cf["\x6b\145\x65\160\137\145\170\x69\x73\x74\151\x6e\147\137\x75\163\145\162\x5f\x72\x6f\x6c\x65\163"]))) {
            goto t1;
        }
        $this->mo_oauth_client_map_default_role($KK, $Cf);
        MO_Oauth_Debug::mo_oauth_log("\122\x6f\x6c\x65\40\115\x61\x70\160\151\156\x67\x20\104\x6f\156\145");
        t1:
        lo:
        do_action("\x6d\157\137\157\141\x75\x74\150\137\x63\154\x69\x65\x6e\x74\137\x6d\x61\x70\137\x72\x6f\x6c\145\x73", array("\165\163\x65\x72\137\x69\x64" => $KK, "\141\x70\x70\x5f\x63\x6f\x6e\x66\151\147" => $Cf, "\156\x65\167\x5f\x75\x73\x65\x72" => $s8, "\162\145\163\x6f\x75\162\x63\145\137\x6f\x77\x6e\x65\x72" => $ET, "\x61\160\160\x5f\156\x61\155\x65" => $M9, "\x63\x6f\156\x66\x69\147" => $this->config));
        MO_Oauth_Debug::mo_oauth_log("\122\x6f\154\x65\x20\x4d\x61\x70\160\151\156\147\x20\x44\157\x6e\145");
        do_action("\155\x6f\137\157\141\165\164\150\137\154\157\147\x67\145\144\137\x69\x6e\137\x75\163\x65\x72\137\164\157\x6b\x65\x6e", $user, $dK);
        do_action("\155\x6f\x5f\x6f\141\165\x74\150\137\x61\144\x64\x5f\144\151\163\x5f\x75\x73\145\162\x5f\x73\x65\162\x76\145\162", $KK, $dK, $ET);
        $this->check_status(array("\155\x73\147" => "\114\x6f\147\x69\156\40\x53\x75\x63\x63\x65\x73\163\x66\165\154\41", "\143\157\x64\x65" => "\114\x4f\x47\x49\116\x5f\123\x55\103\x43\x45\x53\x53", "\163\164\141\164\x75\163" => true, "\141\160\x70\x6c\x69\143\x61\164\151\157\x6e" => $M9, "\143\154\x69\x65\x6e\x74\137\151\x70" => $Uc->get_client_ip(), "\x6e\x61\x76\x69\147\141\x74\x69\157\x6e\x75\162\x6c" => $QT, "\145\155\x61\151\154" => $gK, "\x75\163\x65\162\x6e\x61\x6d\x65" => $w5), $jD);
        if (!$xU) {
            goto vh;
        }
        return $user;
        vh:
        do_action("\155\157\x5f\x6f\x61\165\164\x68\x5f\x73\145\x74\137\x6c\157\x67\x69\x6e\x5f\x63\x6f\x6f\x6b\151\x65");
        do_action("\155\157\x5f\157\141\165\164\x68\x5f\x67\145\164\137\x75\163\145\162\137\141\x74\164\162\163", $user, $ET);
        update_user_meta($user->ID, "\x6d\x6f\x5f\x6f\x61\x75\164\150\137\143\154\151\145\x6e\164\137\154\141\x73\164\137\151\x64\137\164\157\153\x65\x6e", isset($dK["\x69\144\137\x74\157\153\145\156"]) ? $dK["\151\144\x5f\x74\157\x6b\145\x6e"] : $dK["\x61\143\143\x65\x73\163\x5f\x74\x6f\153\x65\x6e"]);
        wp_set_current_user($user->ID);
        $TC = false;
        $TC = apply_filters("\155\x6f\x5f\162\145\155\x65\155\x62\x65\x72\137\x6d\145", $TC);
        wp_set_auth_cookie($user->ID, $TC);
        if (!isset($ET["\162\x6f\x6c\x65\163"])) {
            goto KE;
        }
        apply_filters("\x6d\157\x5f\157\x61\x75\x74\150\137\165\160\x64\141\x74\x65\137\x62\142\x70\x5f\162\157\154\x65", $user->ID, $ET["\x72\157\154\145\x73"]);
        KE:
        if (!has_action("\155\157\x5f\x68\141\143\x6b\x5f\154\157\147\151\x6e\x5f\163\x65\163\163\x69\x6f\156\x5f\x72\x65\x64\x69\x72\145\x63\164")) {
            goto zt;
        }
        $ut = $Uc->gen_rand_str();
        $I3 = $Uc->gen_rand_str();
        $K9 = array("\165\163\145\162\x5f\x69\x64" => $user->ID, "\x75\x73\145\x72\137\160\141\x73\x73\x77\x6f\x72\144" => $I3);
        set_transient($ut, $K9);
        do_action("\x6d\x6f\137\150\141\143\153\137\154\157\147\x69\156\137\163\x65\163\x73\x69\x6f\156\x5f\162\145\x64\x69\x72\145\143\164", $user, $I3, $ut, $b0);
        zt:
        do_action("\167\x70\x5f\x6c\157\147\151\156", $user->user_login, $user);
        setcookie("\155\157\137\157\x61\x75\x74\x68\137\154\x6f\x67\x69\x6e\137\x61\160\160\x5f\163\145\x73\x73\151\157\x6e", $M9, null, "\x2f", null, true, true);
        do_action("\x6d\157\x5f\157\x61\165\x74\150\x5f\x67\145\x74\137\x74\x6f\x6b\145\156\x5f\x66\157\162\137\x68\145\141\x64\x6c\145\163\163", $user, $dK, $QT);
        $LA = $zQ->get_value("\162\x65\x73\x74\x72\151\x63\x74\x72\x65\144\151\162\x65\143\164") !== false;
        $yy = $zQ->get_value("\x70\x6f\160\165\x70") === "\x69\147\x6e\157\162\145";
        if (isset($this->config["\x70\157\160\x75\160\137\154\x6f\x67\151\x6e"]) && 1 === intval($this->config["\160\157\x70\165\160\x5f\154\x6f\147\x69\x6e"]) && !$yy && !boolval($LA)) {
            goto wN;
        }
        do_action("\155\x6f\137\x6f\x61\165\x74\x68\137\162\x65\x64\151\x72\145\x63\x74\137\157\141\165\164\150\137\165\x73\145\x72\x73", $user, $QT);
        header("\114\x6f\x63\141\x74\x69\157\156\x3a\40" . $QT);
        goto dj;
        wN:
        echo "\74\163\143\162\x69\x70\164\76\x77\x69\156\x64\157\x77\56\157\x70\x65\156\x65\x72\56\110\141\x6e\144\x6c\145\120\157\x70\165\160\122\x65\x73\165\x6c\x74\50\x22" . $QT . "\x22\51\73\x77\151\156\x64\x6f\x77\56\143\x6c\157\x73\145\x28\x29\73\x3c\x2f\x73\x63\162\151\x70\x74\x3e";
        dj:
        exit;
    }
    public function check_status($nK, $jD)
    {
        global $Uc;
        if (isset($nK["\x73\x74\x61\x74\165\x73"])) {
            goto mE;
        }
        MO_Oauth_Debug::mo_oauth_log("\x53\x6f\x6d\145\164\x68\x69\x6e\x67\x20\167\145\x6e\x74\40\x77\x72\x6f\x6e\x67\x2e\40\120\154\x65\x61\x73\145\40\164\162\171\x20\x4c\157\x67\x67\151\x6e\x67\x20\x69\156\x20\x61\x67\x61\151\x6e\56");
        $Uc->handle_error("\123\x6f\155\145\164\x68\x69\156\147\x20\167\145\156\164\40\x77\x72\157\x6e\x67\x2e\40\120\x6c\145\x61\163\145\40\164\162\x79\40\x4c\x6f\147\x67\x69\x6e\x67\40\151\156\x20\x61\x67\141\x69\156\x2e");
        wp_die(wp_kses("\x53\157\x6d\x65\x74\x68\x69\x6e\147\40\x77\x65\x6e\x74\40\x77\162\157\x6e\147\56\40\120\154\145\x61\163\x65\x20\x74\162\171\40\114\157\147\x67\151\156\147\x20\151\156\x20\141\147\x61\151\156\x2e", \mo_oauth_get_valid_html()));
        mE:
        if (!(isset($nK["\163\x74\x61\x74\165\x73"]) && true === $nK["\x73\164\x61\x74\165\163"] && (isset($nK["\143\x6f\144\145"]) && "\x4c\x4f\x47\x49\x4e\137\x53\x55\103\103\x45\123\123" === $nK["\x63\x6f\x64\x65"]))) {
            goto u7;
        }
        return true;
        u7:
        if (!(true !== $nK["\163\164\141\x74\x75\x73"])) {
            goto Yz;
        }
        $jk = isset($nK["\x6d\x73\147"]) && !empty($nK["\x6d\163\x67"]) ? $nK["\155\x73\x67"] : "\x53\157\155\145\x74\150\151\x6e\147\40\167\145\x6e\164\40\x77\162\157\x6e\x67\x2e\x20\120\154\145\x61\x73\145\40\x74\x72\x79\40\x4c\x6f\147\x67\x69\x6e\147\40\x69\x6e\40\x61\x67\141\151\156\56";
        MO_Oauth_Debug::mo_oauth_log($jk);
        $Uc->handle_error($jk);
        wp_die(wp_kses($jk, \mo_oauth_get_valid_html()));
        exit;
        Yz:
    }
    public function skip_email_exist($sm)
    {
        define("\127\120\137\x49\115\x50\117\x52\124\111\116\x47", "\x53\113\x49\120\137\x45\x4d\x41\111\x4c\x5f\x45\x58\x49\123\x54");
        return $sm;
    }
}
