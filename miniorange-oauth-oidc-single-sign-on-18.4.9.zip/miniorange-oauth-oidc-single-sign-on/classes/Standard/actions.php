<?php


use MoOauthClient\MO_Oauth_Debug;
function mo_oauth_client_auto_redirect_external_after_wp_logout($KK)
{
    MO_Oauth_Debug::mo_oauth_log("\111\156\163\x69\x64\x65\40\x77\x70\x20\154\157\147\x6f\x75\x74");
    global $Uc;
    $K9 = $Uc->get_plugin_config();
    if (!(!empty($K9->get_config("\x61\x66\164\145\x72\137\x6c\157\x67\157\165\x74\137\x75\x72\x6c")) && (isset($_COOKIE["\x6d\157\x5f\157\x61\x75\164\150\x5f\x6c\x6f\x67\151\x6e\137\141\160\x70\x5f\163\145\163\x73\151\157\x6e"]) && $_COOKIE["\155\157\137\x6f\141\x75\x74\x68\x5f\x6c\157\x67\151\x6e\x5f\141\160\160\137\163\x65\x73\x73\x69\x6f\156"] != "\156\x6f\x6e\145"))) {
        goto xW;
    }
    $user = get_userdata($KK);
    $hN = $K9->get_config("\141\146\164\145\x72\137\154\157\x67\x6f\x75\x74\x5f\x75\x72\154");
    MO_Oauth_Debug::mo_oauth_log("\165\163\145\162\40\x3d\x3d\x3e\x20");
    MO_Oauth_Debug::mo_oauth_log($KK);
    $Ne = get_user_meta($KK, "\155\157\137\x6f\141\x75\164\150\x5f\143\x6c\x69\145\156\x74\137\154\141\x73\164\x5f\x69\144\137\x74\157\153\145\156", true);
    MO_Oauth_Debug::mo_oauth_log("\x69\144\40\164\x6f\153\x65\x6e\x20\75\75\x3e\40");
    MO_Oauth_Debug::mo_oauth_log($Ne);
    $hN = str_replace("\43\x23\x69\x64\137\164\x6f\153\145\x6e\43\x23", $Ne, $hN);
    $hN = str_replace("\x23\x23\x6d\x6f\137\160\157\x73\164\137\154\157\x67\157\x75\164\137\x75\162\x69\x23\43", site_url(), $hN);
    do_action("\155\157\x5f\x6f\141\165\164\150\x5f\162\x65\x64\151\162\x65\143\x74\x5f\x6f\141\165\x74\150\x5f\x75\x73\x65\162\x73", $user, $hN);
    wp_redirect($hN);
    exit;
    xW:
    setcookie("\155\x6f\137\157\141\x75\164\x68\x5f\x6c\157\147\x69\x6e\x5f\x61\x70\x70\x5f\163\x65\163\163\151\157\156", "\x6e\157\156\x65");
}
function mo_oauth_client_auto_redirect_external_after_logout($b0, $uY, $user)
{
    $Uc = new \MoOauthClient\Standard\MOUtils();
    $K9 = $Uc->get_plugin_config();
    if (!(!empty($K9->get_config("\141\x66\164\x65\162\x5f\x6c\157\x67\157\165\164\137\x75\162\x6c")) && (isset($_COOKIE["\x6d\x6f\x5f\157\141\165\x74\x68\137\x6c\x6f\x67\x69\156\137\141\160\160\x5f\x73\145\163\x73\x69\x6f\x6e"]) && $_COOKIE["\155\x6f\x5f\x6f\x61\165\x74\x68\x5f\x6c\157\x67\151\x6e\x5f\x61\160\160\137\163\x65\163\x73\x69\157\x6e"] != "\156\157\x6e\x65"))) {
        goto vV;
    }
    $hN = $K9->get_config("\x61\146\164\145\x72\137\154\157\x67\x6f\165\164\137\x75\162\x6c");
    $KK = $user->ID;
    $Ne = get_user_meta($KK, "\155\157\137\x6f\141\x75\164\x68\x5f\143\154\x69\x65\x6e\x74\137\x6c\x61\x73\164\137\x69\x64\137\x74\x6f\x6b\x65\x6e", true);
    $hN = str_replace("\x23\43\x69\144\x5f\164\157\x6b\x65\156\x23\x23", $Ne, $hN);
    $hN = str_replace("\x23\43\155\x6f\x5f\x70\x6f\163\x74\x5f\154\x6f\147\157\165\x74\x5f\x75\162\x69\43\43", site_url(), $hN);
    do_action("\155\157\137\x6f\x61\165\x74\x68\137\x72\x65\x64\x69\162\x65\143\x74\137\x6f\141\165\x74\150\137\x75\x73\145\x72\163", $user, $hN);
    wp_redirect($hN);
    exit;
    vV:
    setcookie("\x6d\157\137\157\141\165\164\x68\137\154\157\147\x69\x6e\137\x61\x70\160\x5f\163\145\163\163\151\157\156", "\156\157\156\x65");
    return $b0;
}
add_filter("\x77\160\x5f\x6c\x6f\147\157\165\164", "\x6d\157\137\x6f\141\x75\x74\x68\137\143\x6c\x69\145\x6e\x74\x5f\141\165\x74\x6f\x5f\x72\145\x64\151\x72\x65\143\164\x5f\x65\170\164\145\x72\x6e\x61\x6c\x5f\x61\146\x74\x65\162\x5f\x77\x70\x5f\x6c\157\147\157\165\164", 10, 1);
add_filter("\154\157\147\157\165\x74\x5f\162\145\144\151\x72\x65\143\164", "\155\x6f\137\x6f\x61\165\x74\150\137\143\154\x69\145\156\x74\137\141\x75\164\157\137\162\x65\x64\x69\162\x65\x63\164\137\145\x78\x74\145\x72\x6e\141\x6c\x5f\141\x66\164\145\162\x5f\154\157\147\157\165\x74", 10, 3);
