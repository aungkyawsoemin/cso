<?php


namespace MoOauthClient\Standard;

use MoOauthClient\Free\FreeSettings;
use MoOauthClient\Free\CustomizationSettings;
use MoOauthClient\Standard\AppSettings;
use MoOauthClient\Standard\SignInSettingsSettings;
use MoOauthClient\Standard\Customer;
use MoOauthClient\App;
use MoOauthClient\Config;
use MoOauthClient\Widget\MOUtils;
class StandardSettings
{
    private $free_settings;
    public function __construct()
    {
        add_filter("\143\x72\x6f\x6e\137\x73\x63\x68\x65\x64\x75\154\x65\163", array($this, "\155\157\x5f\x6f\x61\x75\x74\150\x5f\163\x63\x68\x65\x64\x75\154\x65"));
        if (wp_next_scheduled("\155\157\137\x6f\x61\x75\x74\x68\137\163\x63\x68\145\144\165\154\145")) {
            goto UP;
        }
        wp_schedule_event(time(), "\x65\166\x65\162\x79\x5f\x6e\x5f\155\151\x6e\165\164\145\163", "\x6d\x6f\x5f\x6f\141\165\164\150\x5f\163\x63\150\x65\144\165\154\145");
        UP:
        add_action("\x6d\157\137\x6f\141\x75\x74\150\137\163\x63\150\145\x64\x75\154\x65", array($this, "\x65\166\145\162\171\x5f\x73\x65\x76\145\x6e\x5f\144\141\x79\163\x5f\145\166\x65\156\x74\x5f\146\165\x6e\143"));
        $this->free_settings = new FreeSettings();
        add_action("\141\144\x6d\x69\x6e\137\151\156\x69\164", array($this, "\155\157\x5f\x6f\x61\165\x74\x68\137\143\x6c\x69\145\x6e\164\137\163\164\x61\x6e\x64\x61\x72\144\x5f\x73\145\x74\164\151\156\x67\x73"));
        add_action("\144\x6f\x5f\155\x61\151\156\x5f\163\145\x74\164\151\x6e\x67\163\x5f\151\x6e\164\145\162\156\141\x6c", array($this, "\x64\157\x5f\x69\x6e\x74\x65\x72\x6e\x61\x6c\x5f\x73\x65\164\164\x69\x6e\147\163"), 1, 10);
    }
    public function mo_oauth_schedule($gm)
    {
        $gm["\x65\x76\x65\x72\171\x5f\156\x5f\155\x69\x6e\165\x74\x65\163"] = array("\x69\x6e\164\x65\162\166\x61\154" => 60 * 60 * 24 * 7, "\144\151\163\x70\x6c\x61\171" => __("\x45\x76\x65\162\171\40\x6e\40\115\151\x6e\x75\x74\145\163", "\x74\145\170\164\144\157\x6d\x61\151\x6e"));
        return $gm;
    }
    public function every_seven_days_event_func()
    {
        global $Uc;
        $Fr = new Customer();
        $ki = $Fr->check_customer_ln();
        $ki = json_decode($ki, true);
        $this->mo_oauth_initiate_expiration($ki);
    }
    public function mo_oauth_initiate_expiration($ki)
    {
        global $Uc;
        $Wi = "\x64\151\x73\x61\142\154\145\144";
        $J5 = new SignInSettingsSettings();
        $K9 = $J5->get_config_option();
        if (!isset($ki["\x6c\x69\143\145\156\x73\145\105\170\x70\x69\x72\x79"])) {
            goto jy;
        }
        $A3 = $ki["\154\x69\x63\x65\x6e\163\145\x45\x78\160\151\162\x79"];
        $Qr = false;
        $MG = date("\131\x2d\155\x2d\144\40\x48\x3a\151\x3a\163");
        $A3 <= $MG ? $Qr = "\145\156\x61\142\154\x65\x64" : ($Qr = "\144\x69\x73\x61\142\154\145\x64");
        $K9->add_config("\155\x6f\137\144\x74\145\137\163\164\141\x74\x65", $Uc->mooauthencrypt($Qr));
        $K9->add_config("\x6d\x6f\137\x64\164\145\x5f\144\x61\x74\x61", $Uc->mooauthencrypt($A3));
        $J5->save_config_option($K9);
        jy:
    }
    public function mo_oauth_client_standard_settings()
    {
        $Mw = new CustomizationSettings();
        $J5 = new SignInSettingsSettings();
        $da = new AppSettings();
        $Mw->save_customization_settings();
        $da->save_app_settings();
        $J5->mo_oauth_save_settings();
    }
    public function do_internal_settings($post)
    {
        global $Uc;
        if (!(isset($_POST["\155\x6f\x5f\157\141\165\164\150\137\x63\x6c\151\x65\156\x74\137\x76\x65\x72\x69\x66\x79\x5f\x6c\151\143\145\156\163\x65\x5f\x6e\157\x6e\x63\145"]) && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST["\155\157\x5f\x6f\141\165\164\150\137\143\x6c\x69\145\x6e\164\137\x76\145\x72\x69\146\171\137\154\x69\143\x65\x6e\x73\145\137\x6e\157\x6e\143\x65"])), "\x6d\157\137\x6f\x61\165\164\x68\x5f\x63\154\151\x65\156\164\x5f\166\145\x72\x69\146\x79\137\154\151\x63\x65\x6e\163\145") && isset($post[\MoOAuthConstants::OPTION]) && "\155\157\x5f\x6f\x61\x75\164\150\137\x63\x6c\151\145\x6e\164\137\x76\145\162\x69\x66\x79\x5f\x6c\x69\x63\x65\156\163\145" === $post[\MoOAuthConstants::OPTION])) {
            goto ED;
        }
        if (!(!isset($post["\x6d\x6f\137\x6f\x61\165\164\150\137\143\154\151\145\x6e\164\x5f\x6c\151\x63\145\156\163\x65\x5f\x6b\145\x79"]) || empty($post["\x6d\157\137\x6f\141\x75\x74\150\x5f\x63\154\151\x65\156\164\137\x6c\x69\143\145\x6e\163\x65\137\x6b\145\x79"]))) {
            goto G_;
        }
        $Uc->mo_oauth_client_update_option(\MoOAuthConstants::PANEL_MESSAGE_OPTION, "\x50\x6c\x65\x61\x73\145\40\145\x6e\164\145\x72\40\x76\x61\x6c\151\144\40\x6c\x69\x63\145\x6e\163\145\x20\x6b\x65\171\x2e");
        $this->mo_oauth_show_error_message();
        return;
        G_:
        $bw = trim($post["\x6d\x6f\137\x6f\141\x75\164\x68\x5f\143\x6c\151\145\156\164\x5f\x6c\x69\x63\145\x6e\x73\x65\137\x6b\x65\x79"]);
        $Fr = new Customer();
        $ki = json_decode($Fr->check_customer_ln(), true);
        $rM = false;
        if (!(isset($ki["\x69\163\115\165\x6c\x74\151\x53\151\164\145\x50\x6c\x75\147\x69\x6e\x52\145\x71\x75\145\163\164\x65\144"]) && boolval($ki["\151\163\115\x75\154\164\x69\x53\x69\x74\145\x50\x6c\165\147\151\156\122\x65\x71\x75\145\163\164\145\144"]) && is_multisite())) {
            goto AL;
        }
        $rM = boolval($ki["\151\x73\115\165\x6c\164\x69\123\x69\164\145\x50\154\x75\x67\x69\x6e\x52\x65\161\165\145\163\164\x65\x64"]);
        $Uc->mo_oauth_client_update_option("\x6d\x6f\x5f\157\141\x75\164\x68\x5f\x69\x73\115\165\154\164\x69\x53\151\x74\145\120\x6c\x75\x67\151\x6e\x52\x65\x71\165\145\x73\164\145\144", $rM);
        $Uc->mo_oauth_client_update_option("\x6e\157\x4f\146\x53\x75\x62\123\151\164\x65\x73", intval($ki["\156\157\117\146\123\165\142\123\151\164\x65\x73"]));
        AL:
        $j9 = 0;
        if (!is_multisite()) {
            goto PJ;
        }
        if (!function_exists("\x67\x65\x74\x5f\163\151\x74\145\163")) {
            goto e2;
        }
        $j9 = count(get_sites(["\156\165\x6d\142\x65\x72" => 1000])) - 1;
        e2:
        PJ:
        if (!(is_multisite() && $rM && ($rM && (!array_key_exists("\x6e\157\117\x66\123\165\142\123\151\x74\x65\163", $ki) && $Uc->is_multisite_versi())))) {
            goto fE;
        }
        $uC = $Uc->mo_oauth_client_get_option("\x68\x6f\x73\164\137\x6e\141\155\145");
        $uC .= "\x2f\155\x6f\x61\163\57\154\x6f\x67\x69\156\77\162\x65\144\x69\x72\x65\x63\164\125\x72\154\75";
        $uC .= $Uc->mo_oauth_client_get_option("\150\x6f\x73\164\137\x6e\141\x6d\x65");
        $uC .= "\x2f\x6d\157\x61\163\57\151\156\x69\x74\x69\x61\x6c\151\x7a\x65\160\x61\x79\155\x65\x6e\164\x3f\x72\145\161\165\145\x73\164\x4f\162\x69\x67\151\x6e\75";
        $uC .= "\167\x70\137\157\141\x75\x74\150\x5f\143\154\151\x65\156\164\x5f" . strtolower($Uc->get_versi_str()) . "\137\160\154\141\x6e";
        $Uc->mo_oauth_client_update_option(\MoOAuthConstants::PANEL_MESSAGE_OPTION, "\x59\x6f\x75\x20\150\x61\166\145\40\156\x6f\164\40\x75\x70\147\x72\141\144\x65\x64\x20\x74\x6f\40\x74\x68\145\x20\143\157\x72\162\x65\x63\164\x20\x6c\151\143\x65\156\163\x65\40\x70\154\141\156\56\x20\x45\x69\x74\150\x65\162\x20\171\x6f\x75\40\150\x61\x76\145\x20\160\165\x72\x63\150\x61\x73\145\144\40\146\x6f\162\x20\x69\x6e\143\157\162\x72\145\x63\x74\x20\x6e\x6f\56\x20\x6f\146\x20\x73\x69\x74\x65\x73\x20\x6f\x72\x20\171\x6f\165\40\x68\141\x76\x65\x20\156\x6f\x74\x20\163\x65\x6c\x65\143\x74\x65\x64\40\x6d\x75\x6c\x74\151\163\x69\x74\145\40\157\160\164\x69\x6f\x6e\x20\167\150\x69\x6c\145\40\x70\165\x72\x63\x68\141\163\151\156\147\56\x20\x3c\x61\x20\164\x61\162\x67\x65\x74\x3d\x22\x5f\x62\x6c\x61\156\x6b\42\x20\150\x72\x65\146\x3d\42" . $uC . "\42\x20\76\103\x6c\x69\x63\153\40\150\x65\162\145\x3c\57\x61\76\x20\x74\x6f\40\165\x70\x67\162\x61\x64\145\x20\x74\x6f\40\160\162\145\155\151\165\x6d\40\166\145\162\x73\151\x6f\156\56");
        $Uc->mo_oauth_show_error_message();
        return;
        fE:
        if (strcasecmp($ki["\163\x74\141\164\165\x73"], "\x53\x55\103\103\x45\x53\123") === 0) {
            goto Bx;
        }
        $Uc->mo_oauth_client_update_option(\MoOAuthConstants::PANEL_MESSAGE_OPTION, "\x59\x6f\x75\x20\150\x61\x76\145\x6e\x27\164\40\165\x70\147\162\141\144\145\144\40\164\157\x20\164\150\151\x73\40\160\154\141\156\40\x79\x65\164\x2e");
        $Uc->mo_oauth_show_error_message();
        goto kg;
        Bx:
        $Id = $ki;
        $ki = json_decode($Fr->XfskodsfhHJ($bw), true);
        if (isset($ki)) {
            goto uX;
        }
        $Uc->mo_oauth_client_update_option(\MoOAuthConstants::PANEL_MESSAGE_OPTION, "\120\x6c\145\x61\x73\x65\x20\x63\150\x65\x63\x6b\40\151\146\x20\x79\157\165\40\150\x61\x76\x65\40\145\156\x74\145\162\145\144\40\141\x20\166\141\x6c\151\x64\x20\x6c\x69\x63\x65\156\x73\x65\40\153\145\x79");
        $Uc->mo_oauth_show_error_message();
        goto xA;
        uX:
        if (strcasecmp($ki["\163\164\x61\x74\x75\x73"], "\123\125\x43\x43\105\123\x53") === 0) {
            goto jf;
        }
        if (strcasecmp($ki["\163\164\141\x74\165\163"], "\x46\101\111\114\105\x44") === 0) {
            goto hw;
        }
        $Uc->mo_oauth_client_update_option(\MoOAuthConstants::PANEL_MESSAGE_OPTION, "\101\x6e\x20\145\x72\162\x6f\162\x20\x6f\143\x63\165\x72\145\x64\x20\x77\x68\151\154\145\x20\160\x72\157\143\x65\163\x73\x69\x6e\x67\40\171\157\165\x72\x20\x72\145\x71\x75\x65\163\x74\56\x20\x50\x6c\x65\x61\x73\145\x20\x54\162\x79\x20\x61\147\x61\x69\x6e\56");
        $Uc->mo_oauth_show_error_message();
        goto Y5;
        jf:
        $Uc->mo_oauth_client_update_option("\155\x6f\137\x6f\141\x75\x74\150\137\x6c\153", $Uc->mooauthencrypt($bw));
        $Uc->mo_oauth_client_update_option("\x6d\157\137\157\141\x75\164\150\x5f\x6c\166", $Uc->mooauthencrypt("\x74\x72\x75\145"));
        $this->mo_oauth_initiate_expiration($Id);
        $KJ = $Uc->get_app_list();
        if (!(!empty($KJ) && is_array($KJ))) {
            goto fG;
        }
        foreach ($KJ as $og => $dm) {
            if (is_array($dm) && !empty($dm)) {
                goto Fy;
            }
            if (boolval($dm->get_app_config("\x63\154\x69\145\x6e\164\137\143\x72\145\x64\163\x5f\145\156\143\162\x70\x79\x74\x65\x64"))) {
                goto Ky;
            }
            $FO = $dm->get_app_config("\143\154\151\145\156\164\137\x69\x64");
            !empty($FO) ? $dm->update_app_config("\143\x6c\151\x65\156\x74\x5f\151\x64", $Uc->mooauthencrypt($FO)) : '';
            $fd = $dm->get_app_config("\x63\x6c\151\x65\156\x74\137\x73\x65\143\x72\145\x74");
            !empty($fd) ? $dm->update_app_config("\143\x6c\151\145\x6e\164\137\163\x65\x63\x72\145\164", $Uc->mooauthencrypt($fd)) : '';
            $dm->update_app_config("\x63\x6c\x69\x65\156\164\x5f\x63\162\145\144\163\137\x65\156\x63\162\160\x79\x74\145\144", true);
            Ky:
            $bO[$og] = $dm;
            goto BH;
            Fy:
            if (!(!isset($dm["\x63\154\151\x65\x6e\x74\x5f\151\144"]) || empty($dm["\143\154\x69\145\x6e\164\137\x69\x64"]))) {
                goto hx;
            }
            $dm["\143\154\151\145\x6e\x74\137\x69\x64"] = isset($dm["\x63\x6c\x69\145\156\164\x69\x64"]) ? $dm["\143\154\151\145\156\x74\x69\x64"] : '';
            hx:
            if (!(!isset($dm["\143\154\x69\145\x6e\x74\x5f\x73\145\143\x72\x65\164"]) || empty($dm["\143\154\x69\x65\x6e\x74\137\163\145\x63\x72\145\x74"]))) {
                goto lF;
            }
            $dm["\x63\154\x69\x65\156\164\x5f\163\145\143\162\145\164"] = isset($dm["\143\x6c\151\x65\156\x74\163\145\143\162\145\164"]) ? $dm["\x63\154\151\x65\x6e\164\163\145\x63\x72\145\x74"] : '';
            lF:
            unset($dm["\x63\154\x69\x65\x6e\164\151\144"]);
            unset($dm["\x63\x6c\x69\145\156\164\163\x65\x63\x72\145\x74"]);
            if (!(!isset($dm["\143\154\x69\x65\x6e\x74\137\143\162\145\x64\163\137\x65\x6e\x63\162\160\x79\164\145\x64"]) || !boolval($dm["\143\154\x69\x65\x6e\x74\137\x63\162\x65\x64\x73\x5f\x65\156\x63\x72\x70\x79\x74\145\144"]))) {
                goto kP;
            }
            isset($dm["\x63\154\x69\145\x6e\164\x5f\151\x64"]) ? $dm["\143\x6c\151\x65\x6e\x74\x5f\151\144"] = $Uc->mooauthencrypt($dm["\x63\154\151\145\156\x74\x5f\x69\x64"]) : '';
            isset($dm["\143\x6c\151\145\156\164\x5f\x73\145\x63\x72\145\164"]) ? $dm["\143\x6c\x69\145\156\164\137\x73\x65\x63\162\x65\x74"] = $Uc->mooauthencrypt($dm["\x63\154\151\145\x6e\x74\137\163\145\143\x72\145\164"]) : '';
            $dm["\143\x6c\151\145\156\164\137\x63\162\145\x64\163\137\x65\x6e\x63\x72\160\x79\x74\145\x64"] = true;
            kP:
            $Ts = new App();
            $Ts->migrate_app($dm, $og);
            $bO[$og] = $Ts;
            BH:
            JW:
        }
        Qf:
        fG:
        !empty($KJ) ? $Uc->mo_oauth_client_update_option("\155\x6f\137\157\141\x75\x74\x68\x5f\141\160\160\163\137\154\x69\x73\164", $bO) : '';
        $Uc->mo_oauth_client_update_option(\MoOAuthConstants::PANEL_MESSAGE_OPTION, "\x59\x6f\165\x72\x20\154\x69\143\x65\156\x73\x65\x20\151\x73\x20\166\x65\162\x69\x66\151\x65\144\x2e\40\x59\x6f\x75\40\143\x61\156\40\x6e\157\x77\x20\x73\145\x74\x75\x70\40\164\150\145\x20\160\154\165\x67\x69\156\56");
        $Uc->mo_oauth_show_success_message();
        goto Y5;
        hw:
        if (strcasecmp($ki["\x6d\x65\163\163\x61\147\145"], "\103\157\144\x65\x20\x68\141\163\x20\x45\170\x70\x69\162\145\x64") === 0) {
            goto Ia;
        }
        $Uc->mo_oauth_client_update_option(\MoOAuthConstants::PANEL_MESSAGE_OPTION, "\131\x6f\165\x20\x68\141\166\145\40\145\x6e\x74\x65\x72\145\144\x20\x61\x6e\40\x69\x6e\166\141\x6c\151\144\40\154\x69\x63\145\156\x73\145\40\153\x65\x79\56\x20\x50\154\x65\x61\163\x65\x20\x65\156\164\x65\x72\40\x61\40\166\x61\x6c\x69\x64\x20\x6c\151\143\x65\x6e\x73\145\x20\153\145\171\x2e");
        $Uc->mo_oauth_show_error_message();
        goto Wb;
        Ia:
        $Uc->mo_oauth_client_update_option(\MoOAuthConstants::PANEL_MESSAGE_OPTION, "\114\x69\143\x65\x6e\x73\145\x20\153\145\x79\x20\171\157\x75\40\150\x61\166\x65\40\145\x6e\164\x65\x72\x65\x64\40\x68\x61\163\x20\141\154\162\x65\x61\x64\171\x20\x62\145\145\x6e\x20\165\x73\145\x64\x2e\40\120\x6c\145\141\163\x65\40\x65\156\164\145\x72\40\141\40\x6b\x65\x79\x20\x77\150\151\143\150\40\150\x61\163\x20\x6e\157\x74\40\x62\145\145\156\x20\x75\x73\145\144\x20\142\x65\146\x6f\x72\145\40\x6f\156\40\x61\x6e\171\40\157\164\150\x65\x72\40\x69\x6e\163\x74\x61\156\143\145\40\x6f\162\x20\151\x66\40\x79\157\165\40\150\141\166\x65\40\145\x78\x61\x75\163\164\145\144\x20\x61\154\x6c\40\171\157\165\x72\40\x6b\x65\171\x73\x20\164\150\145\156\40\142\x75\171\x20\x6d\157\162\145\x2e");
        $Uc->mo_oauth_show_error_message();
        Wb:
        Y5:
        xA:
        kg:
        ED:
    }
}
