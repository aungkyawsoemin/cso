<?php


namespace MoOauthClient\Standard;

use MoOauthClient\Customer as NormalCustomer;
class Customer extends NormalCustomer
{
    public $email;
    public $phone;
    private $default_customer_key = "\61\x36\x35\x35\65";
    private $default_api_key = "\x66\106\144\x32\130\x63\166\124\107\104\145\155\x5a\166\x62\x77\x31\142\143\x55\x65\x73\116\x4a\127\x45\x71\113\142\142\125\x71";
    public function check_customer_ln()
    {
        global $Uc;
        $yN = $Uc->mo_oauth_client_get_option("\150\157\x73\x74\x5f\x6e\141\x6d\145") . "\x2f\x6d\x6f\x61\163\57\162\145\x73\x74\x2f\143\165\x73\x74\157\155\x65\x72\x2f\x6c\151\x63\145\156\163\145";
        $sZ = $Uc->mo_oauth_client_get_option("\155\x6f\137\157\141\165\164\150\x5f\x61\144\155\151\156\x5f\x63\165\x73\x74\x6f\155\x65\162\137\x6b\145\x79");
        $Xx = $Uc->mo_oauth_client_get_option("\155\157\x5f\x6f\x61\165\164\x68\x5f\141\x64\x6d\151\156\137\x61\160\151\x5f\153\x65\171");
        $w5 = $Uc->mo_oauth_client_get_option("\155\x6f\x5f\157\141\165\x74\x68\x5f\x61\x64\155\x69\156\137\145\155\x61\x69\x6c");
        $oZ = $Uc->mo_oauth_client_get_option("\x6d\x6f\x5f\x6f\141\165\x74\150\137\141\x64\155\x69\x6e\137\x70\x68\x6f\x6e\145");
        $Bs = self::get_timestamp();
        $tO = $sZ . $Bs . $Xx;
        $ib = hash("\x73\150\141\x35\61\x32", $tO);
        $ac = "\x43\x75\163\x74\157\155\145\162\x2d\113\145\x79\x3a\x20" . $sZ;
        $Tn = "\x54\x69\155\x65\x73\x74\x61\155\160\x3a\40" . $Bs;
        $LM = "\x41\165\164\150\157\x72\151\172\141\x74\151\x6f\x6e\x3a\x20" . $ib;
        $hf = '';
        $hf = array("\143\x75\x73\164\x6f\155\x65\162\x49\x64" => $sZ, "\x61\160\160\154\151\143\x61\164\x69\157\x6e\x4e\141\155\x65" => "\x77\160\x5f\157\141\x75\164\150\x5f\x63\x6c\x69\x65\156\x74\137" . \strtolower($Uc->get_versi_str()) . "\137\x70\x6c\x61\156");
        $xh = wp_json_encode($hf);
        $zd = array("\x43\x6f\156\164\x65\156\x74\55\124\x79\x70\145" => "\141\160\160\154\151\x63\x61\x74\x69\157\x6e\x2f\152\163\157\156");
        $zd["\103\x75\x73\164\x6f\155\x65\x72\x2d\x4b\145\x79"] = $sZ;
        $zd["\124\x69\155\x65\163\164\x61\x6d\x70"] = $Bs;
        $zd["\101\165\164\150\157\x72\x69\x7a\x61\x74\151\157\156"] = $ib;
        $nK = array("\155\145\164\x68\157\144" => "\120\x4f\123\124", "\142\x6f\144\171" => $xh, "\164\x69\155\x65\x6f\x75\x74" => "\x31\x35", "\x72\x65\x64\x69\162\x65\x63\164\151\157\156" => "\x35", "\x68\164\x74\x70\x76\x65\162\163\x69\x6f\x6e" => "\x31\56\x30", "\142\x6c\x6f\x63\153\151\x6e\x67" => true, "\150\145\141\144\x65\162\163" => $zd);
        $mj = wp_remote_post($yN, $nK);
        if (!is_wp_error($mj)) {
            goto Vn;
        }
        $y2 = $mj->get_error_message();
        echo "\x53\157\155\x65\x74\x68\151\156\147\40\167\145\x6e\164\x20\167\x72\x6f\156\x67\x3a\x20{$y2}";
        exit;
        Vn:
        return wp_remote_retrieve_body($mj);
    }
    public function XfskodsfhHJ($bw)
    {
        global $Uc;
        $yN = $Uc->mo_oauth_client_get_option("\150\x6f\x73\164\x5f\156\x61\155\145") . "\x2f\155\157\x61\x73\x2f\x61\160\151\x2f\142\141\143\153\x75\x70\x63\157\x64\x65\x2f\166\145\162\x69\146\171";
        $sZ = $Uc->mo_oauth_client_get_option("\155\x6f\x5f\x6f\141\165\164\150\x5f\141\x64\155\151\x6e\137\x63\x75\x73\x74\157\155\145\x72\137\x6b\145\171");
        $Xx = $Uc->mo_oauth_client_get_option("\155\x6f\137\x6f\x61\x75\164\x68\137\x61\x64\x6d\x69\x6e\137\x61\160\151\137\x6b\145\x79");
        $w5 = $Uc->mo_oauth_client_get_option("\x6d\x6f\x5f\157\x61\165\x74\150\x5f\141\x64\x6d\x69\x6e\137\145\155\x61\x69\154");
        $oZ = $Uc->mo_oauth_client_get_option("\x6d\x6f\137\x6f\x61\165\x74\x68\x5f\141\144\155\x69\x6e\x5f\x70\150\157\x6e\145");
        $Bs = self::get_timestamp();
        $tO = $sZ . $Bs . $Xx;
        $ib = hash("\163\150\141\x35\61\62", $tO);
        $ac = "\103\165\163\164\157\x6d\145\x72\x2d\113\x65\171\x3a\40" . $sZ;
        $Tn = "\124\151\x6d\x65\x73\164\x61\155\160\x3a\40" . $Bs;
        $LM = "\x41\x75\164\x68\x6f\x72\x69\x7a\141\x74\x69\157\156\x3a\x20" . $ib;
        $hf = '';
        $hf = array("\x63\157\x64\x65" => $bw, "\143\165\x73\x74\x6f\155\x65\x72\113\x65\x79" => $sZ, "\x61\144\144\x69\164\151\157\156\x61\154\106\151\x65\154\144\163" => array("\x66\151\145\x6c\144\x31" => site_url()));
        $xh = wp_json_encode($hf);
        $zd = array("\x43\157\x6e\x74\x65\x6e\164\x2d\x54\171\x70\x65" => "\x61\160\x70\154\151\x63\x61\164\151\157\x6e\x2f\152\163\x6f\156");
        $zd["\x43\x75\163\164\157\x6d\145\x72\55\113\x65\x79"] = $sZ;
        $zd["\124\151\x6d\x65\x73\164\x61\x6d\160"] = $Bs;
        $zd["\x41\x75\164\150\x6f\162\151\172\141\x74\151\157\156"] = $ib;
        $nK = array("\155\x65\164\150\x6f\144" => "\x50\x4f\x53\124", "\142\x6f\x64\x79" => $xh, "\x74\151\155\145\157\165\x74" => "\61\x35", "\162\x65\x64\151\162\x65\143\x74\x69\x6f\x6e" => "\65", "\x68\x74\x74\x70\166\x65\162\x73\x69\x6f\x6e" => "\x31\56\60", "\142\154\x6f\143\x6b\151\x6e\147" => true, "\150\x65\141\144\145\162\163" => $zd);
        $mj = wp_remote_post($yN, $nK);
        if (!is_wp_error($mj)) {
            goto M8;
        }
        $y2 = $mj->get_error_message();
        echo "\123\x6f\x6d\145\x74\x68\151\156\147\40\x77\x65\x6e\164\x20\167\x72\157\156\x67\72\40{$y2}";
        exit;
        M8:
        return wp_remote_retrieve_body($mj);
    }
}
