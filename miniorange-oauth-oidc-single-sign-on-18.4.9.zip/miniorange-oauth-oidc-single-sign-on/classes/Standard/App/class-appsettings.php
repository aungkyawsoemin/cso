<?php


namespace MoOauthClient\Standard;

use MoOauthClient\App;
use MoOauthClient\Free\AppSettings as FreeAppSettings;
class AppSettings extends FreeAppSettings
{
    public function __construct()
    {
        parent::__construct();
        add_action("\x6d\x6f\x5f\x6f\x61\x75\164\150\137\x63\154\x69\x65\x6e\164\x5f\163\x61\x76\x65\x5f\141\x70\x70\x5f\163\x65\x74\164\x69\x6e\147\163\x5f\x69\x6e\x74\145\162\x6e\141\x6c", array($this, "\163\141\x76\145\137\162\x6f\x6c\145\x5f\155\x61\x70\x70\x69\156\x67"));
    }
    public function change_app_settings($post, $An)
    {
        $An = parent::change_app_settings($post, $An);
        $An["\144\151\163\x70\154\x61\x79\x61\160\x70\156\141\155\145"] = isset($post["\x6d\x6f\x5f\157\141\165\164\x68\137\x64\151\163\x70\154\x61\171\137\141\160\x70\137\156\x61\x6d\145"]) ? trim(stripslashes($post["\155\157\x5f\157\141\x75\x74\150\137\144\151\163\x70\x6c\141\171\x5f\x61\160\160\x5f\156\141\155\x65"])) : '';
        return $An;
    }
    public function change_attribute_mapping($post, $An)
    {
        $An = parent::change_attribute_mapping($post, $An);
        $An["\145\155\141\151\x6c\x5f\141\x74\x74\x72"] = isset($post["\x6d\157\x5f\x6f\x61\x75\164\x68\x5f\x65\155\x61\x69\154\137\141\x74\x74\162"]) ? stripslashes($post["\155\157\137\157\x61\165\164\150\137\145\x6d\141\x69\154\x5f\141\x74\x74\x72"]) : '';
        $An["\146\x69\162\163\x74\156\141\155\x65\137\x61\164\x74\162"] = isset($post["\x6d\x6f\x5f\x6f\x61\x75\164\x68\137\x66\151\162\x73\x74\156\141\155\145\137\141\x74\164\162"]) ? trim(stripslashes($post["\155\x6f\137\x6f\141\x75\164\150\x5f\x66\x69\162\163\x74\x6e\x61\x6d\145\137\141\x74\164\x72"])) : '';
        $An["\154\x61\163\164\x6e\x61\155\x65\x5f\141\x74\164\x72"] = isset($post["\x6d\x6f\x5f\157\141\x75\164\150\137\x6c\x61\163\x74\156\x61\155\x65\137\x61\164\164\162"]) ? trim(stripslashes($post["\x6d\157\137\157\141\x75\x74\x68\137\154\141\x73\164\x6e\141\155\x65\137\141\164\x74\x72"])) : '';
        $An["\145\x6e\141\x62\154\x65\x5f\162\x6f\x6c\x65\137\x6d\x61\160\160\151\156\147"] = isset($post["\x65\x6e\x61\x62\x6c\x65\x5f\x72\x6f\x6c\x65\137\155\141\x70\160\151\x6e\147"]) ? sanitize_text_field(wp_unslash($_POST["\145\156\141\x62\154\145\x5f\162\x6f\154\145\137\155\141\x70\x70\151\x6e\147"])) : false;
        $An["\141\x6c\154\x6f\167\137\144\x75\x70\154\151\x63\141\x74\145\x5f\x65\x6d\x61\151\x6c\163"] = isset($post["\x61\154\x6c\x6f\x77\137\144\165\x70\x6c\x69\143\x61\164\x65\137\145\x6d\141\x69\x6c\x73"]) ? sanitize_text_field(wp_unslash($_POST["\x61\x6c\154\157\x77\137\x64\x75\160\154\x69\143\141\x74\145\137\x65\155\141\151\154\x73"])) : false;
        $An["\144\151\x73\x70\x6c\x61\171\x5f\141\164\x74\162"] = isset($post["\x6f\141\165\x74\150\137\143\x6c\151\x65\x6e\x74\137\141\x6d\137\144\151\163\x70\x6c\141\171\x5f\x6e\141\155\145"]) ? trim(stripslashes($post["\157\x61\165\x74\150\137\143\x6c\x69\x65\156\x74\x5f\x61\x6d\137\144\151\163\160\x6c\x61\171\137\x6e\141\155\145"])) : '';
        return $An;
    }
    public function save_role_mapping()
    {
        global $Uc;
        $K9 = $Uc->get_plugin_config()->get_current_config();
        $YV = "\x64\x69\163\141\x62\154\145\144";
        if (empty($K9["\155\x6f\x5f\144\x74\x65\x5f\x73\x74\141\164\x65"])) {
            goto GQ;
        }
        $YV = $Uc->mooauthdecrypt($K9["\155\157\137\x64\x74\x65\137\163\x74\141\x74\145"]);
        GQ:
        if (!($YV == "\x64\151\x73\x61\142\x6c\145\x64")) {
            goto Iw;
        }
        if (!(isset($_POST["\155\157\137\x6f\x61\x75\164\150\x5f\x63\154\151\145\156\x74\137\163\141\166\x65\x5f\x72\x6f\x6c\x65\137\155\141\x70\160\151\x6e\147\x5f\156\157\x6e\143\x65"]) && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST["\x6d\157\137\157\x61\165\x74\150\137\x63\154\x69\x65\x6e\x74\137\x73\x61\x76\145\x5f\162\x6f\154\145\x5f\x6d\141\x70\160\151\x6e\147\x5f\156\157\x6e\x63\x65"])), "\x6d\x6f\137\x6f\x61\165\x74\x68\137\x63\x6c\151\145\156\x74\x5f\x73\141\166\x65\137\162\157\154\x65\x5f\155\141\x70\160\151\x6e\x67") && isset($_POST[\MoOAuthConstants::OPTION]) && "\x6d\157\137\157\141\165\x74\150\137\143\x6c\x69\145\156\x74\137\163\x61\166\145\x5f\x72\157\154\x65\137\155\141\160\160\151\156\147" === $_POST[\MoOAuthConstants::OPTION])) {
            goto K7;
        }
        $og = sanitize_text_field(wp_unslash(isset($_POST[\MoOAuthConstants::POST_APP_NAME]) ? $_POST[\MoOAuthConstants::POST_APP_NAME] : ''));
        $Ts = $Uc->get_app_by_name($og);
        $Cf = $Ts->get_app_config('', false);
        $Cf["\x5f\155\x61\160\x70\x69\x6e\147\137\166\x61\154\x75\145\137\144\x65\146\141\165\154\164"] = isset($_POST["\155\141\x70\160\151\x6e\x67\137\166\x61\154\165\x65\137\x64\145\x66\141\165\x6c\164"]) ? sanitize_text_field(wp_unslash($_POST["\x6d\x61\160\x70\151\x6e\x67\x5f\x76\141\x6c\x75\x65\137\x64\145\146\x61\x75\x6c\x74"])) : false;
        $Cf["\153\145\x65\160\137\x65\x78\x69\x73\164\x69\x6e\147\x5f\x75\x73\145\162\137\162\157\154\x65\163"] = isset($_POST["\153\x65\x65\x70\137\145\170\x69\163\x74\x69\x6e\x67\137\x75\163\145\x72\x5f\x72\x6f\x6c\x65\x73"]) ? sanitize_text_field(wp_unslash($_POST["\153\145\145\160\137\x65\170\x69\163\164\x69\156\147\137\x75\x73\145\x72\137\162\x6f\154\145\163"])) : 0;
        $XN = $Uc->set_app_by_name($og, $Cf);
        K7:
        Iw:
    }
}
