<?php


namespace MoOauthClient\Standard;

use MoOauthClient\MOUtils as CommonUtils;
class MOUtils extends CommonUtils
{
    private function manage_deactivate_cache()
    {
        global $Uc;
        $sF = $Uc->mo_oauth_client_get_option("\155\157\137\x6f\x61\x75\164\x68\137\154\153");
        if (!(!$Uc->mo_oauth_is_customer_registered() || false === $sF || empty($sF))) {
            goto Id;
        }
        return;
        Id:
        $nT = $Uc->mo_oauth_client_get_option("\150\x6f\x73\x74\137\156\141\155\x65");
        $yN = $nT . "\x2f\155\x6f\141\163\57\141\160\x69\57\x62\x61\x63\x6b\165\160\x63\x6f\x64\145\57\165\160\x64\x61\164\145\x73\x74\x61\x74\165\x73";
        $sZ = $Uc->mo_oauth_client_get_option("\x6d\157\137\157\141\x75\164\150\137\x61\144\155\151\156\137\143\x75\x73\x74\157\x6d\x65\x72\x5f\x6b\145\x79");
        $Xx = $Uc->mo_oauth_client_get_option("\155\157\137\157\x61\165\164\x68\137\x61\x64\155\x69\x6e\137\x61\x70\x69\x5f\x6b\145\x79");
        $bw = $Uc->mooauthdecrypt($sF);
        $Bs = round(microtime(true) * 1000);
        $Bs = number_format($Bs, 0, '', '');
        $tO = $sZ . $Bs . $Xx;
        $ib = hash("\x73\x68\141\65\x31\62", $tO);
        $ac = "\103\165\x73\164\157\155\145\162\55\113\145\x79\72\x20" . $sZ;
        $Tn = "\x54\x69\155\x65\x73\164\141\x6d\160\x3a\40" . $Bs;
        $LM = "\101\165\164\x68\x6f\x72\151\172\x61\164\151\157\x6e\x3a\40" . $ib;
        $hf = '';
        $hf = array("\x63\157\144\145" => $bw, "\143\165\x73\x74\157\155\x65\162\x4b\145\x79" => $sZ, "\141\144\x64\151\x74\x69\157\156\x61\154\x46\151\x65\x6c\144\x73" => array("\146\x69\145\154\144\61" => site_url()));
        $xh = wp_json_encode($hf);
        $zd = array("\x43\157\156\164\x65\156\164\55\124\171\x70\145" => "\141\x70\x70\x6c\x69\x63\141\164\x69\x6f\x6e\57\152\x73\157\x6e");
        $zd["\103\x75\x73\x74\157\155\145\162\55\x4b\x65\x79"] = $sZ;
        $zd["\124\x69\x6d\145\163\x74\x61\x6d\160"] = $Bs;
        $zd["\101\x75\164\150\x6f\162\151\172\x61\x74\x69\x6f\156"] = $ib;
        $nK = array("\155\x65\164\x68\157\x64" => "\x50\117\123\x54", "\142\157\144\171" => $xh, "\164\x69\x6d\145\x6f\165\x74" => "\x31\x35", "\x72\145\144\151\x72\x65\143\x74\x69\157\156" => "\x35", "\x68\164\164\x70\x76\145\162\163\151\157\x6e" => "\x31\56\x30", "\x62\154\x6f\x63\153\x69\x6e\x67" => true, "\x68\x65\x61\144\x65\x72\163" => $zd);
        $mj = wp_remote_post($yN, $nK);
        if (!is_wp_error($mj)) {
            goto gZ;
        }
        $y2 = $mj->get_error_message();
        echo "\123\x6f\x6d\145\164\x68\151\x6e\147\x20\167\145\156\x74\x20\167\x72\x6f\x6e\147\72\x20{$y2}";
        exit;
        gZ:
        return wp_remote_retrieve_body($mj);
    }
    public function deactivate_plugin()
    {
        $this->manage_deactivate_cache();
        parent::deactivate_plugin();
        $this->mo_oauth_client_delete_option("\x6d\157\x5f\157\141\x75\x74\150\x5f\154\153");
        $this->mo_oauth_client_delete_option("\155\x6f\137\157\x61\165\x74\x68\137\x6c\166");
    }
    public function is_url($yN)
    {
        $mj = [];
        if (empty($yN)) {
            goto gI;
        }
        $mj = @get_headers($yN) ? @get_headers($yN) : [];
        gI:
        $Q1 = preg_grep("\x2f\x28\x2e\52\x29\x32\x30\x30\40\117\x4b\57", $mj);
        return (bool) (sizeof($Q1) > 0);
    }
}
