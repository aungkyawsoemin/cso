<?php


namespace MoOauthClient\Free;

class CustomizationSettings
{
    public function save_customization_settings()
    {
        global $Uc;
        $K9 = $Uc->get_plugin_config()->get_current_config();
        $YV = "\144\x69\x73\x61\x62\x6c\145\144";
        if (empty($K9["\155\157\137\x64\x74\x65\x5f\163\164\x61\164\x65"])) {
            goto We;
        }
        $YV = $Uc->mooauthdecrypt($K9["\x6d\x6f\137\144\164\145\137\x73\x74\x61\164\145"]);
        We:
        if (!($YV == "\x64\151\x73\141\x62\154\x65\x64")) {
            goto YM;
        }
        if (!(isset($_POST["\x6d\157\137\x6f\x61\x75\164\150\x5f\141\x70\160\137\x63\x75\163\164\x6f\x6d\x69\172\x61\x74\x69\x6f\156\x5f\156\157\x6e\143\145"]) && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST["\155\157\x5f\157\x61\x75\164\150\x5f\x61\160\160\137\143\165\x73\x74\157\x6d\151\172\x61\164\151\157\x6e\137\x6e\x6f\x6e\143\x65"])), "\x6d\x6f\137\x6f\141\165\x74\x68\137\141\x70\x70\137\143\x75\x73\x74\x6f\155\x69\x7a\141\x74\x69\157\x6e") && isset($_POST[\MoOAuthConstants::OPTION]) && "\155\x6f\137\157\141\165\164\150\137\x61\160\160\137\x63\x75\x73\x74\x6f\x6d\151\172\x61\x74\151\x6f\156" === $_POST[\MoOAuthConstants::OPTION])) {
            goto I6;
        }
        $Uc->mo_oauth_client_update_option("\x6d\x6f\137\157\141\165\164\150\137\151\x63\157\x6e\137\x74\150\145\x6d\x65", stripslashes($_POST["\155\x6f\137\x6f\141\x75\164\150\137\151\143\x6f\156\x5f\x74\x68\145\x6d\145"]));
        $Uc->mo_oauth_client_update_option("\x6d\x6f\x5f\x6f\x61\x75\x74\x68\137\x69\143\157\x6e\137\x73\150\141\160\x65", stripslashes($_POST["\155\157\137\157\141\x75\164\x68\137\151\143\x6f\x6e\137\163\150\141\160\145"]));
        isset($_POST["\155\157\137\157\x61\165\x74\150\137\151\x63\x6f\156\137\145\146\146\x65\x63\164\137\163\143\141\154\x65"]) ? $Uc->mo_oauth_client_update_option("\155\157\x5f\x6f\141\165\164\x68\137\x69\x63\157\156\137\145\x66\146\x65\143\x74\137\x73\x63\x61\x6c\145", stripslashes($_POST["\x6d\157\137\157\141\165\x74\x68\x5f\x69\143\x6f\156\x5f\x65\146\x66\145\143\x74\137\x73\x63\141\154\x65"])) : $Uc->mo_oauth_client_update_option("\x6d\157\137\157\141\x75\x74\x68\137\151\x63\157\156\x5f\145\x66\146\x65\x63\x74\x5f\x73\143\x61\154\145", '');
        isset($_POST["\x6d\x6f\x5f\157\x61\x75\x74\x68\137\151\x63\157\156\137\145\x66\146\x65\143\164\x5f\x73\150\141\144\x6f\167"]) ? $Uc->mo_oauth_client_update_option("\x6d\x6f\x5f\x6f\x61\x75\x74\x68\x5f\151\x63\157\156\137\x65\146\x66\145\x63\164\x5f\x73\150\141\x64\157\167", stripslashes($_POST["\x6d\157\137\x6f\x61\165\164\150\x5f\151\x63\x6f\156\137\145\146\146\x65\143\x74\137\163\150\x61\144\157\x77"])) : $Uc->mo_oauth_client_update_option("\x6d\157\137\x6f\141\x75\x74\x68\137\151\143\x6f\x6e\137\x65\146\146\x65\x63\x74\137\163\150\141\144\x6f\167", '');
        $Uc->mo_oauth_client_update_option("\x6d\x6f\x5f\x6f\x61\x75\x74\x68\137\x69\143\x6f\x6e\x5f\x77\151\x64\x74\150", stripslashes($_POST["\x6d\157\137\157\141\165\x74\150\137\x69\x63\x6f\x6e\x5f\167\151\x64\164\150"]));
        $Uc->mo_oauth_client_update_option("\155\157\x5f\x6f\141\x75\x74\150\x5f\151\x63\157\156\137\150\145\x69\x67\150\164", stripslashes($_POST["\155\x6f\x5f\157\141\165\x74\150\x5f\151\x63\x6f\x6e\x5f\150\x65\x69\x67\150\164"]));
        $Uc->mo_oauth_client_update_option("\155\157\137\x6f\x61\165\164\150\137\151\x63\157\156\x5f\x63\157\154\x6f\x72", stripslashes($_POST["\x6d\x6f\137\x6f\141\x75\x74\150\x5f\151\143\x6f\156\x5f\143\x6f\x6c\x6f\x72"]));
        $Uc->mo_oauth_client_update_option("\155\157\137\x6f\141\165\x74\x68\137\x69\x63\157\156\x5f\143\165\163\164\x6f\155\137\x63\157\154\x6f\162", stripslashes($_POST["\x6d\x6f\x5f\x6f\x61\165\164\x68\x5f\x69\x63\157\156\x5f\143\x75\x73\164\x6f\x6d\x5f\x63\x6f\x6c\x6f\x72"]));
        $Uc->mo_oauth_client_update_option("\x6d\157\137\x6f\x61\165\164\x68\137\151\x63\x6f\156\137\x73\x6d\x61\x72\x74\137\x63\x6f\x6c\x6f\162\137\x31", stripslashes($_POST["\155\157\x5f\157\141\x75\164\x68\x5f\x69\143\x6f\156\137\x73\x6d\x61\x72\x74\137\143\157\154\157\x72\137\x31"]));
        $Uc->mo_oauth_client_update_option("\155\157\x5f\x6f\141\165\164\x68\x5f\151\143\157\x6e\137\163\x6d\x61\162\x74\137\143\x6f\154\x6f\162\x5f\62", stripslashes($_POST["\155\x6f\x5f\x6f\x61\165\x74\x68\137\151\143\x6f\x6e\137\163\x6d\141\162\x74\137\143\157\154\x6f\162\137\x32"]));
        $Uc->mo_oauth_client_update_option("\x6d\x6f\x5f\157\x61\x75\x74\150\137\151\x63\x6f\156\137\x63\165\162\x76\x65", stripslashes($_POST["\x6d\157\x5f\x6f\x61\x75\x74\x68\137\151\x63\157\156\137\x63\x75\x72\x76\x65"]));
        $Uc->mo_oauth_client_update_option("\x6d\157\137\157\141\x75\x74\x68\137\x69\143\157\156\x5f\x73\x69\x7a\145", stripslashes($_POST["\155\x6f\137\157\141\165\x74\x68\x5f\151\x63\x6f\x6e\x5f\163\151\172\145"]));
        $Uc->mo_oauth_client_update_option("\155\x6f\x5f\157\x61\165\x74\150\x5f\x69\x63\157\x6e\137\155\141\162\x67\x69\156", stripslashes($_POST["\155\157\x5f\157\141\x75\164\150\137\151\143\x6f\x6e\x5f\x6d\141\162\x67\151\x6e"]));
        $bH = preg_replace("\x2f\134\156\53\57", "\12", trim($_POST["\x6d\157\137\x6f\x61\x75\x74\150\137\x69\143\157\156\x5f\143\157\156\x66\151\147\165\162\x65\x5f\x63\163\x73"]));
        $Uc->mo_oauth_client_update_option("\x6d\157\137\x6f\x61\165\x74\150\137\151\x63\x6f\156\137\x63\x6f\156\146\x69\x67\165\x72\145\x5f\x63\163\x73", $bH);
        $Uc->mo_oauth_client_update_option("\155\x6f\137\x6f\141\x75\x74\150\137\143\x75\x73\x74\157\155\x5f\x6c\x6f\x67\157\165\x74\137\164\x65\x78\164", stripslashes($_POST["\155\x6f\137\x6f\141\165\x74\x68\x5f\143\165\x73\164\x6f\155\137\154\x6f\x67\157\x75\164\137\x74\145\x78\x74"]));
        $Uc->mo_oauth_client_update_option(\MoOAuthConstants::PANEL_MESSAGE_OPTION, "\x59\157\x75\x72\40\x73\145\x74\x74\151\156\147\163\x20\x77\145\x72\145\40\x73\141\166\145\144");
        $Uc->mo_oauth_show_success_message();
        I6:
        YM:
    }
    public function set_default_customize_value()
    {
        global $Uc;
        $Uc->mo_oauth_client_update_option("\155\x6f\137\157\141\x75\164\150\x5f\151\143\157\x6e\x5f\x74\150\x65\x6d\145", "\x70\x72\145\166\x69\157\165\163");
        $Uc->mo_oauth_client_update_option("\155\x6f\137\157\141\x75\164\x68\x5f\x69\143\x6f\156\x5f\x73\x68\x61\160\145", "\x6c\x6f\x6e\147\142\x75\164\x74\157\x6e");
        $Uc->mo_oauth_client_update_option("\x6d\x6f\x5f\x6f\141\x75\164\150\137\x69\143\x6f\156\x5f\x65\x66\146\x65\143\x74\x5f\163\143\141\154\x65", '');
        $Uc->mo_oauth_client_update_option("\155\157\137\x6f\141\x75\164\x68\137\x69\143\x6f\x6e\x5f\x65\146\146\145\143\x74\137\x73\150\141\144\x6f\x77", '');
        if ($Uc->mo_oauth_client_get_option("\x6d\157\137\157\141\x75\x74\x68\137\151\143\x6f\156\137\167\151\144\x74\150")) {
            goto VT;
        }
        $Uc->mo_oauth_client_update_option("\x6d\x6f\x5f\157\141\165\164\x68\x5f\x69\143\157\x6e\x5f\167\151\144\164\150", "\63\x32\65");
        VT:
        if (!$Uc->mo_oauth_client_get_option("\155\x6f\x5f\157\141\x75\x74\150\x5f\151\143\x6f\x6e\x5f\x68\145\151\x67\x68\x74")) {
            goto nS;
        }
        $Gq = $Uc->mo_oauth_client_get_option("\x6d\157\137\x6f\141\165\164\150\x5f\x72\x65\143\164\x69\146\x79\137\x69\143\157\x6e\137\x68\145\x69\x67\150\164\137\x66\x6c\141\x67");
        if (!($Gq == false)) {
            goto Cb;
        }
        $GE = $Uc->mo_oauth_client_get_option("\155\157\137\157\141\165\x74\150\137\151\143\x6f\156\137\x68\145\x69\147\150\x74");
        $GE = (int) $GE;
        $GE = $GE * 2;
        $GE = (string) $GE;
        $Uc->mo_oauth_client_update_option("\155\x6f\137\x6f\141\165\164\x68\x5f\151\x63\157\x6e\137\x68\x65\151\147\150\x74", $GE);
        $Uc->mo_oauth_client_update_option("\x6d\157\137\157\x61\x75\x74\150\137\x72\145\x63\x74\x69\146\171\137\x69\x63\x6f\x6e\x5f\x68\x65\x69\x67\150\x74\x5f\x66\154\141\147", True);
        Cb:
        goto xS;
        nS:
        $Uc->mo_oauth_client_update_option("\155\x6f\137\157\x61\x75\164\150\137\151\143\157\x6e\137\150\x65\x69\147\x68\x74", "\63\x35");
        $Uc->mo_oauth_client_update_option("\155\157\x5f\x6f\x61\x75\x74\150\137\x72\x65\143\164\x69\146\x79\137\151\143\x6f\156\137\150\145\x69\147\x68\164\x5f\x66\154\x61\147", True);
        xS:
        $Uc->mo_oauth_client_update_option("\x6d\x6f\137\x6f\141\x75\x74\150\x5f\151\x63\157\x6e\137\x63\x6f\x6c\x6f\162", "\x23\60\x30\x30\60\x30\x30");
        $Uc->mo_oauth_client_update_option("\155\157\x5f\157\141\x75\164\x68\137\151\143\x6f\156\137\143\165\163\x74\x6f\155\137\143\x6f\154\x6f\x72", "\43\60\x30\x38\x65\x63\x32");
        $Uc->mo_oauth_client_update_option("\155\x6f\x5f\x6f\x61\x75\x74\150\x5f\151\143\x6f\x6e\137\x73\x6d\141\x72\x74\137\143\157\154\157\162\x5f\x31", "\x23\x46\106\x31\x46\x34\102");
        $Uc->mo_oauth_client_update_option("\x6d\x6f\x5f\x6f\141\x75\164\x68\137\x69\x63\x6f\x6e\x5f\x73\155\x61\x72\164\x5f\143\157\154\x6f\x72\x5f\x32", "\43\62\60\60\x38\x46\106");
        $Uc->mo_oauth_client_update_option("\x6d\x6f\137\157\141\x75\164\150\137\x69\143\157\156\x5f\x63\x75\x72\166\x65", "\x34");
        $Uc->mo_oauth_client_update_option("\x6d\157\x5f\157\141\x75\x74\150\137\x69\x63\x6f\x6e\137\x73\x69\x7a\x65", "\63\65");
        if ($Uc->mo_oauth_client_get_option("\155\x6f\137\157\141\165\164\x68\137\151\143\157\156\137\x6d\x61\162\x67\x69\156")) {
            goto Ep;
        }
        $Uc->mo_oauth_client_update_option("\155\157\x5f\x6f\x61\x75\164\x68\137\x69\143\x6f\x6e\137\x6d\x61\162\147\x69\x6e", "\64");
        Ep:
    }
    public function mo_oauth_custom_icons_intiater()
    {
        global $Uc;
        $nZ = $Uc->mo_oauth_client_get_option("\155\157\137\x6f\141\165\x74\x68\x5f\x69\143\x6f\156\x5f\x74\150\x65\155\x65");
        $q4 = $Uc->mo_oauth_client_get_option("\155\x6f\x5f\157\141\165\164\150\137\151\x63\157\x6e\137\x73\x68\x61\160\x65");
        if (!((!$nZ || empty($nZ)) && (!$q4 || empty($q4)))) {
            goto Ow;
        }
        $ne = $this->set_default_customize_value();
        Ow:
    }
}
