<?php


namespace MoOauthClient\Free;

use MoOauthClient\Settings;
use MoOauthClient\Free\CustomizationSettings;
use MoOauthClient\Free\RequestfordemoSettings;
use MoOauthClient\Free\AppSettings;
use MoOauthClient\Customer;
class FreeSettings
{
    private $common_settings;
    public function __construct()
    {
        $this->common_settings = new Settings();
        add_action("\141\144\x6d\151\x6e\x5f\151\156\x69\x74", array($this, "\155\x6f\137\x6f\141\x75\164\x68\x5f\143\x6c\151\145\156\x74\x5f\146\162\145\145\x5f\x73\145\x74\x74\x69\x6e\x67\163"));
        add_action("\x61\x64\155\x69\x6e\137\146\x6f\x6f\164\145\x72", array($this, "\x6d\x6f\x5f\157\x61\x75\x74\150\137\x63\154\x69\145\x6e\x74\137\146\x65\x65\x64\142\x61\x63\153\137\x72\145\161\x75\145\x73\x74"));
    }
    public function mo_oauth_client_free_settings()
    {
        global $Uc;
        $Mw = new CustomizationSettings();
        $DI = new RequestfordemoSettings();
        $Mw->save_customization_settings();
        $DI->save_requestdemo_settings();
        $da = new AppSettings();
        $da->save_app_settings();
        if (!(isset($_POST["\155\x6f\x5f\157\x61\165\164\150\x5f\x63\154\x69\x65\x6e\x74\x5f\146\145\x65\x64\142\x61\143\153\137\156\157\x6e\x63\145"]) && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST["\155\157\137\x6f\x61\x75\164\150\137\x63\x6c\151\145\x6e\164\x5f\x66\x65\145\144\142\x61\x63\x6b\x5f\x6e\x6f\x6e\143\145"])), "\155\x6f\137\x6f\141\x75\x74\x68\x5f\x63\154\151\x65\x6e\x74\x5f\x66\x65\145\144\x62\x61\x63\153") && isset($_POST[\MoOAuthConstants::OPTION]) && "\x6d\157\x5f\x6f\141\x75\164\150\137\143\x6c\151\145\156\164\137\146\x65\x65\144\x62\141\x63\153" === $_POST[\MoOAuthConstants::OPTION])) {
            goto DK;
        }
        $user = wp_get_current_user();
        $sb = "\x50\x6c\x75\147\151\x6e\40\x44\145\141\143\164\x69\x76\141\164\x65\144\72";
        $QM = isset($_POST["\144\x65\141\143\x74\151\166\141\164\145\x5f\x72\145\x61\x73\157\156\x5f\x72\141\x64\151\x6f"]) ? sanitize_text_field(wp_unslash($_POST["\144\x65\141\x63\x74\151\166\x61\x74\x65\137\x72\145\x61\x73\157\156\137\162\141\144\x69\157"])) : false;
        $Jx = isset($_POST["\x71\x75\145\162\171\137\x66\x65\x65\144\142\x61\143\x6b"]) ? sanitize_text_field(wp_unslash($_POST["\161\x75\145\162\171\137\x66\145\145\x64\142\x61\x63\153"])) : false;
        if ($QM) {
            goto Gq;
        }
        $Uc->mo_oauth_client_update_option(\MoOAuthConstants::PANEL_MESSAGE_OPTION, "\120\154\x65\x61\x73\x65\x20\x53\x65\154\x65\143\164\x20\x6f\x6e\145\40\157\x66\x20\x74\150\x65\40\x72\145\141\163\x6f\x6e\163\x20\54\x69\146\40\x79\x6f\165\162\40\x72\x65\141\x73\157\x6e\x20\151\x73\40\156\x6f\x74\x20\x6d\x65\x6e\164\151\x6f\x6e\145\144\40\160\154\x65\141\x73\x65\40\x73\145\154\145\143\x74\40\x4f\164\x68\x65\162\x20\122\145\x61\163\x6f\156\x73");
        $Uc->mo_oauth_show_error_message();
        Gq:
        $sb .= $QM;
        if (!isset($Jx)) {
            goto oM;
        }
        $sb .= "\72" . $Jx;
        oM:
        $gK = $Uc->mo_oauth_client_get_option("\155\157\137\x6f\x61\x75\164\150\x5f\141\144\x6d\151\156\137\145\x6d\x61\151\x6c");
        if (!($gK == '')) {
            goto aF;
        }
        $gK = $user->user_email;
        aF:
        $oZ = $Uc->mo_oauth_client_get_option("\x6d\x6f\x5f\157\x61\165\x74\150\x5f\x61\x64\x6d\151\156\137\x70\x68\157\x6e\x65");
        $ID = new Customer();
        $Rm = json_decode($ID->mo_oauth_send_email_alert($gK, $oZ, $sb), true);
        deactivate_plugins(MOC_DIR . "\x6d\x6f\137\157\x61\x75\164\150\137\163\145\x74\x74\151\x6e\x67\163\56\x70\150\160");
        $Uc->mo_oauth_client_update_option(\MoOAuthConstants::PANEL_MESSAGE_OPTION, "\x54\150\141\x6e\x6b\40\x79\157\165\40\x66\x6f\162\40\x74\150\145\x20\x66\x65\x65\x64\x62\x61\143\x6b\56");
        $Uc->mo_oauth_show_success_message();
        DK:
        if (!(isset($_POST["\155\157\x5f\157\x61\x75\x74\x68\137\143\x6c\x69\145\x6e\x74\x5f\x73\153\x69\160\137\x66\145\x65\144\142\x61\143\x6b\137\x6e\157\x6e\143\145"]) && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST["\x6d\157\x5f\x6f\x61\x75\164\x68\x5f\143\154\x69\145\156\164\137\163\153\151\x70\137\146\145\x65\144\x62\141\x63\x6b\137\156\157\156\x63\x65"])), "\x6d\157\137\157\141\165\164\150\x5f\x63\x6c\151\145\x6e\x74\137\163\153\x69\160\x5f\x66\x65\x65\x64\x62\x61\x63\153") && isset($_POST["\157\160\x74\151\157\x6e"]) && "\x6d\x6f\x5f\157\141\x75\164\150\137\x63\154\x69\145\156\x74\x5f\163\153\151\160\137\146\145\145\x64\142\x61\x63\153" === $_POST["\x6f\x70\164\151\x6f\x6e"])) {
            goto WT;
        }
        deactivate_plugins(MOC_DIR . "\x6d\x6f\x5f\x6f\141\x75\164\x68\137\x73\145\164\164\151\156\x67\x73\x2e\160\x68\160");
        $Uc->mo_oauth_client_update_option(\MoOAuthConstants::PANEL_MESSAGE_OPTION, "\120\154\x75\x67\x69\x6e\x20\x44\145\141\143\x74\x69\x76\x61\164\x65\144\56");
        $Uc->mo_oauth_show_success_message();
        WT:
    }
    public function mo_oauth_client_feedback_request()
    {
        $v9 = new \MoOauthClient\Free\Feedback();
        $v9->show_form();
    }
}
