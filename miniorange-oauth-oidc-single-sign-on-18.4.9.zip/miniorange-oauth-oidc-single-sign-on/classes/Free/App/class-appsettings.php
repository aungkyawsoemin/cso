<?php


namespace MoOauthClient\Free;

use MoOauthClient\App;
class AppSettings
{
    private $app_config;
    public function __construct()
    {
        $this->app_config = array("\143\x6c\x69\145\x6e\x74\x5f\151\144", "\x63\154\151\145\x6e\164\137\x73\x65\143\x72\x65\x74", "\163\x63\x6f\x70\145", "\162\x65\144\151\x72\x65\143\164\137\165\162\x69", "\x61\x70\x70\x5f\x74\x79\x70\x65", "\x61\x75\164\150\x6f\x72\151\x7a\x65\x75\x72\154", "\x61\143\143\x65\x73\163\x74\157\x6b\x65\156\x75\x72\x6c", "\x72\x65\163\157\165\x72\143\145\x6f\x77\x6e\x65\162\x64\x65\x74\141\151\154\163\x75\x72\x6c", "\x67\162\x6f\x75\160\x64\145\164\141\151\x6c\163\165\x72\154", "\x6a\167\153\163\137\x75\x72\151", "\x64\x69\x73\x70\x6c\141\171\x61\x70\160\x6e\x61\x6d\145", "\x61\x70\160\x49\144", "\x6d\157\137\157\x61\x75\x74\x68\x5f\x72\x65\163\160\x6f\x6e\163\x65\x5f\x74\x79\160\x65");
    }
    public function save_app_settings()
    {
        global $Uc;
        $K9 = $Uc->get_plugin_config()->get_current_config();
        $YV = "\144\151\x73\x61\142\154\x65\144";
        if (empty($K9["\155\157\137\144\164\x65\x5f\x73\164\141\x74\x65"])) {
            goto M3;
        }
        $YV = $Uc->mooauthdecrypt($K9["\155\157\x5f\x64\164\x65\137\163\x74\141\164\x65"]);
        M3:
        if (!($YV == "\x64\151\163\141\142\x6c\145\x64")) {
            goto a3;
        }
        if (!(isset($_POST["\155\x6f\137\157\x61\x75\164\150\137\141\x64\x64\x5f\141\160\x70\137\x6e\157\x6e\x63\145"]) && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST["\x6d\x6f\x5f\157\x61\x75\164\150\137\x61\x64\x64\137\x61\x70\160\x5f\156\157\x6e\143\145"])), "\x6d\x6f\137\157\141\x75\x74\150\137\x61\144\x64\137\x61\160\x70") && isset($_POST[\MoOAuthConstants::OPTION]) && "\x6d\157\137\x6f\x61\x75\164\x68\x5f\x61\144\x64\x5f\141\x70\x70" === $_POST[\MoOAuthConstants::OPTION])) {
            goto ot;
        }
        if (!($Uc->mo_oauth_check_empty_or_null($_POST["\x6d\157\137\157\x61\x75\x74\150\x5f\143\154\x69\x65\x6e\164\137\x69\x64"]) || $Uc->mo_oauth_check_empty_or_null($_POST["\x6d\x6f\137\x6f\141\x75\164\150\x5f\143\x6c\151\145\156\164\x5f\x73\145\x63\x72\x65\164"]))) {
            goto FT;
        }
        $Uc->mo_oauth_client_update_option(\MoOAuthConstants::PANEL_MESSAGE_OPTION, "\120\154\145\x61\163\145\x20\x65\156\164\x65\162\40\166\x61\154\x69\x64\40\x43\154\x69\145\156\164\x20\111\104\x20\x61\156\144\x20\103\154\151\145\156\x74\40\123\145\x63\x72\x65\164\x2e");
        $Uc->mo_oauth_show_error_message();
        return;
        FT:
        $og = isset($_POST["\155\x6f\137\157\141\x75\x74\150\x5f\x63\x75\163\164\157\x6d\x5f\141\x70\160\137\156\141\x6d\x65"]) ? sanitize_text_field(wp_unslash($_POST["\x6d\x6f\137\157\x61\165\x74\x68\137\143\x75\163\164\157\155\x5f\141\x70\160\137\156\x61\x6d\145"])) : false;
        $An = $Uc->get_app_by_name($og);
        $An = false !== $An ? $An->get_app_config() : [];
        $Yy = false !== $An;
        $KJ = $Uc->get_app_list();
        if (!(!$Yy && is_array($KJ) && count($KJ) > 0 && !$Uc->check_versi(4))) {
            goto ri;
        }
        $Uc->mo_oauth_client_update_option(\MoOAuthConstants::PANEL_MESSAGE_OPTION, "\x59\x6f\165\40\x63\x61\x6e\x20\157\156\x6c\171\x20\x61\144\x64\40\61\40\141\x70\x70\x6c\x69\x63\x61\x74\151\x6f\x6e\x20\167\x69\164\150\40\x66\162\145\x65\x20\x76\x65\162\163\x69\x6f\156\x2e\40\x55\160\147\x72\x61\144\145\x20\x74\157\40\145\156\x74\145\x72\x70\162\151\x73\x65\x20\166\145\162\163\x69\157\x6e\40\x69\x66\40\171\157\x75\x20\167\141\x6e\164\x20\164\157\x20\x61\144\x64\40\155\157\x72\x65\x20\141\x70\160\x6c\151\143\x61\164\x69\157\x6e\x73\x2e");
        $Uc->mo_oauth_show_error_message();
        return;
        ri:
        $An = !is_array($An) || empty($An) ? array() : $An;
        $An = $this->change_app_settings($_POST, $An);
        $qN = isset($_POST["\x6d\x6f\x5f\x6f\141\165\164\x68\x5f\x64\x69\163\x63\157\x76\145\162\171"]) && isset($An["\151\x73\x5f\x64\151\163\x63\x6f\166\145\x72\171\137\166\x61\154\x69\144"]) && $An["\151\x73\x5f\x64\x69\x73\143\157\166\145\162\x79\137\166\x61\x6c\151\x64"] == "\x74\162\165\145";
        if (!$qN) {
            goto e4;
        }
        $Uc->mo_oauth_client_update_option(\MoOAuthConstants::PANEL_MESSAGE_OPTION, "\x59\157\x75\162\40\163\145\164\x74\151\x6e\147\x73\x20\x61\x72\145\x20\163\x61\x76\145\144\x20\x73\165\x63\143\x65\x73\x73\146\x75\154\x6c\x79\x2e");
        $An["\x6d\x6f\137\144\151\163\x63\x6f\166\145\x72\x79\137\166\141\154\x69\144\x61\x74\151\157\x6e"] = "\166\141\154\x69\144";
        $Uc->mo_oauth_show_success_message();
        goto aL;
        e4:
        $Uc->mo_oauth_client_update_option(\MoOAuthConstants::PANEL_MESSAGE_OPTION, "\74\163\x74\x72\x6f\156\x67\76\105\162\162\x6f\162\72\x20\74\x2f\x73\164\162\157\x6e\x67\76\x20\111\156\x63\157\162\x72\x65\x63\x74\40\x44\x6f\155\141\151\x6e\x2f\124\145\x6e\x61\x6e\164\57\120\x6f\154\x69\143\x79\x2f\x52\145\141\154\155\x2e\x20\120\x6c\x65\x61\163\145\x20\143\157\156\x66\151\x67\x75\162\x65\40\x77\x69\164\150\40\x63\157\162\162\145\143\164\40\x76\141\154\165\x65\163\40\x61\x6e\x64\x20\164\x72\x79\x20\x61\x67\x61\x69\156\56");
        $An["\x6d\157\137\x64\x69\x73\x63\157\x76\145\162\x79\x5f\x76\x61\154\x69\144\141\164\151\x6f\156"] = "\x69\156\x76\x61\x6c\x69\x64";
        $Uc->mo_oauth_show_error_message();
        aL:
        $KJ[$og] = new App($An);
        $KJ[$og]->set_app_name($og);
        $KJ = apply_filters("\155\157\137\157\x61\x75\164\150\137\x63\x6c\151\x65\156\164\x5f\163\141\x76\x65\137\141\x64\144\x69\x74\x69\157\x6e\x61\x6c\x5f\146\151\x65\x6c\x64\137\x73\145\x74\164\151\156\x67\163\137\x69\x6e\x74\x65\162\156\141\154", $KJ);
        $Uc->mo_oauth_client_update_option("\155\157\137\157\141\165\x74\150\137\141\160\160\x73\x5f\154\x69\x73\164", $KJ);
        wp_redirect("\x61\144\155\x69\x6e\56\160\x68\160\x3f\160\x61\147\x65\x3d\155\x6f\137\x6f\141\x75\164\x68\x5f\163\145\164\x74\151\156\147\163\46\164\x61\142\75\x63\157\156\x66\x69\147\x26\x61\143\x74\151\x6f\x6e\75\x75\160\x64\x61\164\145\x26\141\x70\x70\x3d" . urlencode($og));
        ot:
        if (!(isset($_POST["\x6d\157\x5f\x6f\x61\165\x74\150\x5f\x61\164\x74\x72\x69\142\x75\164\145\x5f\155\141\160\160\151\x6e\147\x5f\x6e\157\x6e\x63\x65"]) && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST["\x6d\x6f\x5f\157\141\165\x74\x68\x5f\x61\x74\x74\x72\151\142\x75\164\145\137\x6d\141\160\160\x69\x6e\147\137\x6e\x6f\x6e\x63\x65"])), "\155\x6f\x5f\157\141\165\x74\x68\137\141\x74\164\162\151\142\x75\164\x65\137\155\141\160\160\x69\156\147") && isset($_POST[\MoOAuthConstants::OPTION]) && "\x6d\157\x5f\157\141\x75\164\x68\137\x61\x74\x74\162\151\142\165\x74\145\x5f\x6d\x61\160\160\151\156\x67" === $_POST[\MoOAuthConstants::OPTION])) {
            goto NL;
        }
        $og = sanitize_text_field(wp_unslash(isset($_POST[\MoOAuthConstants::POST_APP_NAME]) ? $_POST[\MoOAuthConstants::POST_APP_NAME] : ''));
        $Ts = $Uc->get_app_by_name($og);
        $Cf = $Ts->get_app_config('', false);
        $post = array_map("\145\x73\x63\137\x61\164\x74\162", $_POST);
        $Cf = $this->change_attribute_mapping($post, $Cf);
        $Cf = apply_filters("\x6d\157\x5f\x6f\141\165\x74\x68\137\143\x6c\151\145\156\x74\137\163\141\x76\x65\x5f\141\x64\144\x69\164\151\x6f\156\x61\154\x5f\x61\164\164\162\x5f\155\141\x70\x70\151\x6e\x67\137\163\145\x74\x74\x69\156\147\x73\137\x69\156\x74\145\162\156\141\154", $Cf);
        $XN = $Uc->set_app_by_name($og, $Cf);
        if (!$XN) {
            goto To;
        }
        $Uc->mo_oauth_client_update_option(\MoOAuthConstants::PANEL_MESSAGE_OPTION, "\131\157\x75\x72\40\x73\x65\x74\164\151\x6e\x67\x73\x20\141\162\145\x20\x73\141\166\x65\144\x20\x73\x75\x63\x63\x65\163\x73\x66\x75\154\154\x79\x2e");
        $Uc->mo_oauth_show_success_message();
        goto A9;
        To:
        $Uc->mo_oauth_client_update_option(\MoOAuthConstants::PANEL_MESSAGE_OPTION, "\124\150\x65\162\x65\x20\x77\141\x73\x20\x61\156\40\x65\x72\162\157\162\x20\x73\x61\x76\151\x6e\147\40\163\145\164\164\x69\x6e\147\x73\x2e");
        $Uc->mo_oauth_show_error_message();
        A9:
        wp_safe_redirect("\141\144\x6d\151\x6e\x2e\x70\x68\160\77\x70\x61\x67\145\75\155\157\x5f\x6f\x61\x75\x74\150\x5f\x73\x65\164\164\151\x6e\147\x73\x26\164\141\142\x3d\x63\157\156\146\151\147\x26\x61\x63\x74\x69\x6f\x6e\x3d\165\x70\x64\141\164\x65\x26\141\160\160\x3d" . rawurlencode($og));
        NL:
        a3:
        do_action("\155\157\x5f\x6f\141\165\x74\150\x5f\x63\154\151\x65\156\164\x5f\163\141\x76\145\137\141\160\160\137\163\x65\164\x74\x69\156\x67\163\137\151\156\164\145\162\x6e\141\x6c");
    }
    public function change_app_settings($post, $An)
    {
        global $Uc;
        $fS = '';
        $Xq = '';
        $NI = '';
        $og = sanitize_text_field(wp_unslash(isset($post[\MoOAuthConstants::POST_APP_NAME]) ? $post[\MoOAuthConstants::POST_APP_NAME] : ''));
        if ("\145\x76\x65\157\x6e\x6c\x69\156\145" === $og) {
            goto Hd;
        }
        $WD = isset($post["\x6d\x6f\x5f\x6f\141\165\x74\150\137\x64\x69\x73\143\x6f\166\145\x72\171"]) ? $post["\155\157\x5f\157\141\x75\164\x68\x5f\144\x69\x73\x63\157\166\x65\162\171"] : null;
        if (!empty($WD)) {
            goto Zx;
        }
        $fS = isset($post["\x6d\157\x5f\x6f\141\x75\164\150\x5f\x61\x75\164\x68\x6f\x72\151\172\145\x75\162\154"]) ? stripslashes($post["\x6d\157\x5f\157\141\x75\164\x68\137\141\165\164\150\157\x72\151\x7a\145\165\x72\154"]) : '';
        $Xq = isset($post["\155\x6f\137\157\141\165\x74\150\x5f\x61\x63\x63\x65\x73\x73\164\157\x6b\145\156\165\162\154"]) ? stripslashes($post["\x6d\157\137\157\x61\165\164\150\137\141\x63\x63\x65\x73\163\164\157\x6b\145\x6e\165\x72\x6c"]) : '';
        $NI = isset($post["\155\x6f\137\157\x61\x75\164\x68\x5f\x72\145\x73\157\x75\162\x63\x65\157\x77\x6e\145\162\x64\145\164\x61\x69\154\x73\x75\x72\154"]) ? stripslashes($post["\x6d\x6f\x5f\157\x61\165\x74\x68\x5f\162\145\163\157\x75\x72\x63\145\157\x77\x6e\145\x72\x64\x65\164\141\151\x6c\163\x75\x72\154"]) : '';
        goto ah;
        Zx:
        $An["\x65\170\151\x73\164\151\x6e\147\x5f\x61\160\160\x5f\x66\154\x6f\167"] = true;
        if (isset($post["\155\157\137\x6f\x61\165\x74\150\137\x70\x72\157\166\x69\144\x65\x72\x5f\x64\157\x6d\141\x69\156"])) {
            goto zJ;
        }
        if (!isset($post["\x6d\157\137\x6f\141\x75\164\150\137\160\162\157\166\151\x64\x65\162\x5f\164\x65\156\141\156\164"])) {
            goto ET;
        }
        $XM = stripslashes(trim($post["\155\157\137\x6f\x61\x75\x74\150\137\x70\x72\x6f\x76\x69\x64\x65\x72\137\x74\145\x6e\141\156\x74"]));
        $WD = str_replace("\164\x65\156\x61\156\164", $XM, $WD);
        $An["\x74\145\156\141\x6e\x74"] = $XM;
        ET:
        goto DT;
        zJ:
        $LB = stripslashes(rtrim($post["\155\157\137\x6f\x61\x75\x74\150\137\x70\162\157\x76\151\144\x65\162\137\144\x6f\155\141\151\x6e"], "\x2f"));
        $WD = str_replace("\x64\x6f\155\141\151\x6e", $LB, $WD);
        $An["\144\157\x6d\141\x69\x6e"] = $LB;
        DT:
        if (isset($post["\x6d\x6f\137\157\141\x75\164\x68\137\x70\162\157\166\x69\144\x65\162\x5f\160\157\x6c\x69\143\171"])) {
            goto i7;
        }
        if (!isset($post["\x6d\157\x5f\157\141\165\x74\150\137\160\162\157\166\151\x64\145\x72\x5f\162\x65\141\x6c\155"])) {
            goto AB;
        }
        $g_ = stripslashes(trim($post["\155\x6f\137\x6f\141\x75\x74\150\137\160\162\x6f\x76\x69\x64\145\x72\x5f\162\145\141\x6c\x6d"]));
        $WD = str_replace("\x72\x65\141\154\155\x6e\x61\155\145", $g_, $WD);
        $An["\162\145\141\154\x6d"] = $g_;
        AB:
        goto xm;
        i7:
        $s9 = stripslashes(trim($post["\155\157\x5f\157\141\x75\x74\x68\x5f\160\162\x6f\166\x69\x64\x65\x72\x5f\x70\x6f\x6c\151\143\171"]));
        $WD = str_replace("\160\x6f\154\x69\143\171", $s9, $WD);
        $An["\x70\x6f\x6c\x69\x63\171"] = $s9;
        xm:
        $XC = null;
        if (filter_var($WD, FILTER_VALIDATE_URL)) {
            goto Cq;
        }
        $An["\151\x73\137\144\x69\x73\x63\x6f\x76\145\x72\x79\137\166\141\x6c\151\x64"] = "\146\x61\154\x73\145";
        goto n0;
        Cq:
        $Uc->mo_oauth_client_update_option("\155\x6f\x5f\157\x63\x5f\x76\x61\x6c\x69\x64\137\x64\x69\x73\143\x6f\166\x65\162\x79\137\x65\x70", true);
        $F6 = array("\163\163\154" => array("\166\145\x72\151\x66\x79\137\160\x65\x65\x72" => false, "\166\145\x72\151\146\x79\137\x70\x65\x65\162\x5f\156\141\155\145" => false));
        $ki = @file_get_contents($WD, false, stream_context_create($F6));
        $XC = array();
        if ($ki) {
            goto qC;
        }
        $An["\151\163\x5f\144\151\x73\x63\157\x76\145\162\171\137\166\141\x6c\x69\x64"] = "\x66\141\x6c\163\145";
        goto uh;
        qC:
        $XC = json_decode($ki);
        $An["\151\163\137\x64\x69\x73\143\157\x76\145\162\x79\137\166\141\154\151\144"] = "\164\x72\165\145";
        uh:
        $N5 = isset($XC->scopes_supported[0]) ? $XC->scopes_supported[0] : '';
        $SL = isset($XC->scopes_supported[1]) ? $XC->scopes_supported[1] : '';
        $fu = stripslashes($N5) . "\x20" . stripslashes($SL);
        $An["\x64\151\x73\x63\157\x76\145\162\x79"] = $WD;
        $An["\x73\143\157\160\145"] = isset($cs) && !empty($cs) ? $cs : $fu;
        $fS = isset($XC->authorization_endpoint) ? stripslashes($XC->authorization_endpoint) : '';
        $Xq = isset($XC->token_endpoint) ? stripslashes($XC->token_endpoint) : '';
        $NI = isset($XC->userinfo_endpoint) ? stripslashes($XC->userinfo_endpoint) : '';
        n0:
        ah:
        goto Ji;
        Hd:
        $Uc->mo_oauth_client_update_option("\155\x6f\x5f\157\141\165\x74\150\x5f\145\x76\145\157\156\154\151\x6e\145\137\x65\x6e\x61\x62\154\x65", 1);
        $Uc->mo_oauth_client_update_option("\x6d\157\x5f\x6f\141\165\x74\150\x5f\x65\x76\x65\x6f\156\x6c\x69\156\x65\x5f\143\154\x69\145\156\164\137\151\x64", $cX);
        $Uc->mo_oauth_client_update_option("\x6d\x6f\137\157\141\165\x74\x68\137\x65\x76\x65\157\x6e\x6c\x69\156\145\x5f\143\154\x69\x65\156\x74\137\x73\145\143\x72\x65\164", $xv);
        if (!($Uc->mo_oauth_client_get_option("\x6d\x6f\137\157\141\165\x74\x68\137\145\x76\x65\157\x6e\154\151\156\145\137\x63\154\151\145\x6e\164\137\151\144") && $Uc->mo_oauth_client_get_option("\x6d\x6f\x5f\157\141\165\164\150\137\x65\166\x65\x6f\x6e\x6c\x69\x6e\145\x5f\x63\x6c\151\145\x6e\x74\137\x73\145\143\x72\145\164"))) {
            goto ZW;
        }
        $Fr = new Customer();
        $sb = $Fr->add_oauth_application("\x65\x76\145\x6f\x6e\154\151\156\145", "\105\x56\x45\40\117\156\x6c\x69\156\x65\x20\117\101\165\164\150");
        if ("\101\x70\160\x6c\x69\x63\x61\164\151\x6f\x6e\x20\103\162\x65\x61\x74\145\144" === $sb) {
            goto w7;
        }
        $Uc->mo_oauth_client_update_option(\MoOAuthConstants::PANEL_MESSAGE_OPTION, $sb);
        $this->mo_oauth_show_error_message();
        goto zD;
        w7:
        $Uc->mo_oauth_client_update_option(\MoOAuthConstants::PANEL_MESSAGE_OPTION, "\x59\x6f\x75\x72\x20\x73\x65\x74\x74\151\156\x67\163\40\x77\x65\x72\x65\x20\163\x61\166\x65\x64\x2e\40\107\x6f\x20\x74\x6f\40\x41\144\x76\x61\156\143\145\144\x20\x45\x56\x45\x20\117\x6e\x6c\151\156\145\40\123\145\x74\164\x69\x6e\147\163\40\x66\157\162\x20\143\157\156\x66\x69\x67\165\162\x69\156\x67\40\x72\145\x73\164\162\x69\x63\164\x69\x6f\x6e\x73\40\x6f\156\40\x75\x73\x65\x72\40\x73\x69\x67\x6e\40\x69\x6e\x2e");
        $this->mo_oauth_show_success_message();
        zD:
        ZW:
        Ji:
        isset($post["\x6d\157\x5f\x6f\141\165\164\150\137\x73\143\x6f\x70\145"]) && !empty($post["\x6d\157\137\x6f\141\x75\164\150\137\163\x63\x6f\160\145"]) ? $An["\x73\143\157\x70\x65"] = sanitize_text_field(wp_unslash($post["\x6d\157\x5f\x6f\141\165\164\x68\137\163\x63\157\x70\x65"])) : '';
        $An["\165\156\151\x71\x75\x65\x5f\x61\160\160\151\x64"] = isset($post["\x6d\157\137\x6f\x61\165\164\x68\x5f\x61\160\160\x5f\156\141\x6d\x65"]) ? stripslashes($post["\x6d\157\137\x6f\141\165\164\150\137\x61\x70\x70\137\x6e\141\x6d\145"]) : '';
        $An["\143\154\151\145\156\164\137\x69\144"] = $Uc->mooauthencrypt(sanitize_text_field(wp_unslash(isset($post["\155\x6f\x5f\157\x61\x75\x74\150\x5f\143\x6c\151\x65\x6e\164\137\x69\x64"]) ? $post["\155\x6f\x5f\x6f\x61\165\x74\x68\x5f\x63\x6c\x69\x65\156\164\137\x69\144"] : '')));
        $An["\x63\154\x69\x65\x6e\x74\137\x73\145\143\x72\145\164"] = $Uc->mooauthencrypt(wp_unslash(isset($post["\x6d\157\137\157\141\x75\x74\150\137\x63\154\151\x65\156\x74\137\163\x65\143\162\145\164"]) ? stripslashes(trim($post["\x6d\157\137\157\x61\x75\164\150\x5f\x63\154\151\x65\156\164\x5f\x73\x65\x63\162\x65\x74"])) : ''));
        $An["\143\154\151\x65\156\164\x5f\143\x72\145\144\163\137\x65\156\x63\162\160\x79\164\x65\144"] = true;
        $An["\x73\x65\x6e\144\x5f\x68\145\x61\144\145\x72\163"] = isset($post["\155\157\137\157\141\x75\164\150\x5f\x61\x75\164\150\x6f\162\x69\172\141\164\x69\x6f\x6e\137\150\145\x61\x64\x65\162"]) ? (int) filter_var($post["\x6d\157\x5f\x6f\141\x75\164\x68\137\x61\x75\x74\x68\x6f\x72\151\x7a\141\164\151\x6f\156\137\150\145\x61\x64\145\x72"], FILTER_SANITIZE_NUMBER_INT) : 0;
        $An["\163\145\156\x64\137\x62\x6f\144\171"] = isset($post["\155\x6f\137\x6f\141\165\x74\x68\137\x62\x6f\x64\x79"]) ? (int) filter_var($post["\155\x6f\137\157\x61\165\164\150\x5f\142\x6f\144\x79"], FILTER_SANITIZE_NUMBER_INT) : 0;
        $An["\163\145\156\144\137\163\164\141\164\x65"] = isset($_POST["\x6d\157\x5f\x6f\x61\165\164\150\x5f\163\164\141\x74\145"]) ? (int) filter_var($_POST["\x6d\157\137\x6f\141\165\x74\150\x5f\163\164\x61\x74\145"], FILTER_SANITIZE_NUMBER_INT) : 0;
        $An["\163\145\156\x64\137\x6e\157\156\x63\x65"] = isset($_POST["\155\157\x5f\x6f\x61\165\164\150\x5f\x6e\x6f\156\143\145"]) ? (int) filter_var($_POST["\155\157\x5f\x6f\141\165\164\150\137\x6e\157\156\143\x65"], FILTER_SANITIZE_NUMBER_INT) : 0;
        $An["\x73\150\x6f\167\x5f\x6f\x6e\137\x6c\x6f\x67\x69\156\x5f\x70\x61\x67\x65"] = isset($post["\x6d\x6f\137\x6f\x61\x75\x74\150\137\163\x68\157\x77\137\157\x6e\x5f\x6c\x6f\x67\151\156\137\160\x61\x67\145"]) ? (int) filter_var($post["\155\x6f\x5f\x6f\x61\165\x74\x68\137\163\150\x6f\167\137\x6f\x6e\137\x6c\157\147\151\x6e\x5f\x70\x61\x67\x65"], FILTER_SANITIZE_NUMBER_INT) : 0;
        if (!(!empty($An["\141\x70\160\x5f\164\171\x70\x65"]) && $An["\141\160\160\x5f\164\171\160\145"] === "\157\141\x75\x74\150\61")) {
            goto Za;
        }
        $An["\x72\145\161\165\145\163\164\165\x72\x6c"] = isset($post["\x6d\157\x5f\157\x61\x75\164\150\137\x72\x65\161\x75\x65\163\x74\x75\162\154"]) ? stripslashes($post["\x6d\x6f\137\x6f\x61\x75\164\x68\137\162\x65\x71\x75\145\x73\x74\165\x72\154"]) : '';
        Za:
        if (isset($An["\141\x70\x70\111\144"])) {
            goto se;
        }
        $An["\141\x70\x70\111\144"] = $og;
        se:
        $An["\162\145\144\151\162\x65\143\x74\x5f\x75\162\x69"] = sanitize_text_field(wp_unslash(isset($post["\x6d\157\137\x75\x70\x64\x61\x74\x65\137\165\162\x6c"]) ? $post["\155\157\x5f\165\160\x64\x61\x74\x65\x5f\165\x72\x6c"] : site_url()));
        $An["\141\x75\164\150\x6f\162\151\172\145\165\x72\x6c"] = $fS;
        $An["\141\143\143\145\x73\x73\164\x6f\153\145\x6e\x75\x72\x6c"] = $Xq;
        $An["\141\x70\x70\x5f\x74\171\160\x65"] = isset($post["\155\157\x5f\157\141\x75\164\x68\137\x61\x70\160\137\164\x79\160\x65"]) ? stripslashes($post["\155\157\x5f\157\141\165\x74\x68\x5f\141\x70\x70\137\164\171\x70\145"]) : stripslashes("\157\141\165\164\x68");
        if (!($An["\x61\160\x70\137\164\171\x70\145"] == "\x6f\x61\165\164\150" || $An["\x61\x70\x70\137\x74\x79\x70\x65"] == "\x6f\x61\165\x74\x68\x31" || isset($post["\155\157\137\157\141\x75\164\x68\x5f\162\145\x73\x6f\165\x72\143\x65\157\167\x6e\x65\162\144\145\x74\x61\x69\154\x73\x75\x72\154"]))) {
            goto Pl;
        }
        $An["\162\145\163\157\165\162\x63\145\x6f\167\x6e\145\x72\x64\145\x74\141\151\x6c\x73\165\x72\154"] = $NI;
        Pl:
        return $An;
    }
    public function change_attribute_mapping($post, $An)
    {
        $Kz = stripslashes($post["\155\x6f\137\x6f\141\x75\x74\x68\137\165\163\145\x72\156\x61\155\x65\x5f\x61\164\x74\162"]);
        $An["\x75\x73\x65\162\x6e\x61\155\x65\x5f\141\x74\x74\162"] = $Kz;
        return $An;
    }
}
