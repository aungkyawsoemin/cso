<?php


namespace MoOauthClient\Free;

use MoOauthClient\AppUI;
use MoOauthClient\App\UpdateAppUI;
use MoOauthClient\AppGuider;
class ClientAppUI
{
    private $common_app_ui;
    public function __construct()
    {
        $this->common_app_ui = new AppUI();
    }
    public function render_free_ui()
    {
        global $Uc;
        $K9 = $Uc->get_plugin_config()->get_current_config();
        $YV = "\144\151\163\141\x62\x6c\145\x64";
        if (empty($K9["\x6d\157\137\x64\x74\x65\137\x73\x74\x61\x74\x65"])) {
            goto Ds;
        }
        $YV = $Uc->mooauthdecrypt($K9["\x6d\157\x5f\x64\x74\145\137\x73\164\x61\x74\x65"]);
        Ds:
        $bO = $this->common_app_ui->get_apps_list();
        if (!($YV == "\144\x69\163\141\x62\154\145\144")) {
            goto ng;
        }
        if (!(isset($_GET["\141\x63\x74\151\157\x6e"]) && "\x64\x65\x6c\x65\x74\145" === $_GET["\141\x63\164\151\157\x6e"])) {
            goto Gm;
        }
        if (!(isset($_GET["\x61\160\160"]) && check_admin_referer("\x6d\x6f\137\x6f\x61\x75\164\150\137\x64\145\x6c\x65\164\x65\137" . sanitize_text_field(wp_unslash($_GET["\141\x70\x70"]))))) {
            goto TB;
        }
        $this->common_app_ui->delete_app($_GET["\x61\160\x70"]);
        return;
        TB:
        Gm:
        ng:
        if (!(isset($_GET["\x61\143\x74\151\157\x6e"]) && "\151\156\163\x74\x72\x75\x63\164\x69\x6f\x6e\x73" === $_GET["\141\x63\x74\x69\x6f\156"] || isset($_GET["\x73\150\x6f\167"]) && "\151\156\163\164\162\x75\143\x74\x69\x6f\x6e\163" === $_GET["\163\x68\x6f\167"])) {
            goto Sl;
        }
        if (!(isset($_GET["\x61\160\160\x49\144"]) && isset($_GET["\146\157\162"]))) {
            goto uP;
        }
        $bA = new AppGuider($_GET["\141\160\160\111\144"], $_GET["\146\x6f\x72"]);
        $bA->show_guide();
        uP:
        if (!(isset($_GET["\163\x68\157\167"]) && "\151\x6e\163\x74\162\x75\x63\164\151\x6f\156\x73" === $_GET["\163\150\157\167"])) {
            goto ft;
        }
        $bA = new AppGuider($_GET["\x61\160\x70\x49\144"]);
        $bA->show_guide();
        $this->common_app_ui->add_app_ui();
        return;
        ft:
        Sl:
        if (!(isset($_GET["\x61\x63\x74\x69\157\156"]) && "\141\144\x64" === $_GET["\141\x63\x74\151\157\x6e"])) {
            goto y0;
        }
        $this->common_app_ui->add_app_ui();
        return;
        y0:
        if (!(isset($_GET["\141\x63\x74\151\x6f\156"]) && "\x75\160\x64\x61\x74\x65" === $_GET["\141\x63\x74\151\x6f\x6e"])) {
            goto wB;
        }
        if (!isset($_GET["\141\160\x70"])) {
            goto lx;
        }
        $Ts = $this->common_app_ui->get_app_by_name($_GET["\x61\x70\x70"]);
        new UpdateAppUI($_GET["\141\x70\x70"], $Ts);
        return;
        lx:
        wB:
        if (!(isset($_GET["\x61\x63\x74\151\x6f\156"]) && "\x61\x64\x64\x5f\x6e\145\167" === $_GET["\x61\x63\164\151\x6f\156"])) {
            goto b3;
        }
        $this->common_app_ui->add_app_ui();
        return;
        b3:
        if (!(is_array($bO) && count($bO) > 0)) {
            goto qQ;
        }
        $this->common_app_ui->show_apps_list_page();
        return;
        qQ:
        $this->common_app_ui->add_app_ui();
    }
}
