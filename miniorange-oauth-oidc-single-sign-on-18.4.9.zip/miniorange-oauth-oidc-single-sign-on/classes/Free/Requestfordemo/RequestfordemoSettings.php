<?php


namespace MoOauthClient\Free;

use MoOauthClient\Customer;
class RequestfordemoSettings
{
    public function save_requestdemo_settings()
    {
        global $Uc;
        if (!(isset($_POST["\x6d\x6f\x5f\157\141\165\164\x68\137\x61\x70\x70\x5f\162\x65\161\165\x65\x73\x74\x64\x65\155\157\x5f\156\x6f\156\143\x65"]) && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST["\x6d\157\x5f\x6f\x61\x75\x74\150\137\x61\x70\160\137\162\x65\x71\165\x65\163\x74\144\145\155\x6f\137\x6e\157\156\143\x65"])), "\x6d\157\137\x6f\x61\165\164\150\x5f\141\160\x70\x5f\x72\145\161\165\145\x73\164\x64\145\155\157") && isset($_POST[\MoOAuthConstants::OPTION]) && "\x6d\157\137\157\x61\x75\x74\150\x5f\141\x70\160\137\162\x65\x71\x75\145\x73\x74\x64\145\x6d\x6f" === $_POST[\MoOAuthConstants::OPTION])) {
            goto AW;
        }
        $gK = $_POST["\x6d\x6f\137\157\141\165\164\x68\137\143\154\x69\145\156\x74\x5f\x64\x65\x6d\157\137\145\x6d\x61\151\x6c"];
        $wI = $_POST["\x6d\x6f\137\x6f\141\165\x74\150\x5f\x63\154\x69\145\x6e\x74\x5f\x64\x65\155\157\x5f\x70\154\141\x6e"];
        $Iu = $_POST["\155\x6f\x5f\157\141\x75\x74\x68\137\143\x6c\151\145\156\x74\x5f\144\145\155\157\137\144\x65\x73\x63\x72\151\x70\164\x69\x6f\156"];
        $Fr = new Customer();
        if ($Uc->mo_oauth_check_empty_or_null($gK) || $Uc->mo_oauth_check_empty_or_null($wI)) {
            goto rx;
        }
        $Rm = json_decode($Fr->mo_oauth_send_demo_alert($gK, $wI, $Iu, "\x57\x50\40\x4f\x41\x75\164\x68\x20\123\x69\x6e\147\x6c\145\40\x53\151\x67\x6e\40\x4f\x6e\40\x44\x65\x6d\157\40\x52\x65\161\165\x65\163\164\40\x2d\x20" . $gK), true);
        $Uc->mo_oauth_client_update_option(\MoOAuthConstants::PANEL_MESSAGE_OPTION, "\124\150\141\x6e\153\x73\40\146\x6f\162\x20\147\x65\x74\164\151\156\147\x20\151\x6e\40\x74\x6f\x75\143\x68\x21\40\x57\145\40\163\x68\141\x6c\x6c\x20\x67\145\164\x20\x62\141\143\153\x20\x74\x6f\x20\171\x6f\x75\x20\x73\x68\x6f\x72\164\x6c\171\x2e");
        $Uc->mo_oauth_show_success_message();
        goto Ri;
        rx:
        $Uc->mo_oauth_client_update_option(\MoOAuthConstants::PANEL_MESSAGE_OPTION, "\120\154\x65\x61\163\145\x20\x66\151\154\154\x20\165\x70\x20\105\155\x61\x69\x6c\x20\x66\x69\145\x6c\x64\40\164\157\40\x73\165\x62\x6d\x69\164\x20\171\157\165\162\x20\x71\x75\x65\x72\x79\56");
        $Uc->mo_oauth_show_success_message();
        Ri:
        AW:
    }
}
