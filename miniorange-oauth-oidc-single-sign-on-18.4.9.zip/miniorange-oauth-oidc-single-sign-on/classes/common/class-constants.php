<?php


class MoOAuthConstants
{
    const PANEL_MESSAGE_OPTION = "\x6d\x65\x73\163\x61\x67\x65";
    const OPTION = "\x6f\x70\x74\x69\x6f\x6e";
    const POST_APP_NAME = "\155\157\x5f\x6f\x61\x75\x74\150\x5f\141\x70\160\x5f\156\x61\155\x65";
    const MAP_KEY = "\x6d\x61\160\160\151\x6e\147\x5f\x6b\x65\x79\137";
    const EMAIL = "\x65\155\x61\151\154";
}
