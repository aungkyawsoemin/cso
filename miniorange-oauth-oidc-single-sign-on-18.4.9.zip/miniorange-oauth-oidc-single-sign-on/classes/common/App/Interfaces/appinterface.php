<?php


namespace MoOauthClient\App;

interface AppInterface
{
    public function get_app_config($YF);
    public function update_app_config($LG, $C0);
}
