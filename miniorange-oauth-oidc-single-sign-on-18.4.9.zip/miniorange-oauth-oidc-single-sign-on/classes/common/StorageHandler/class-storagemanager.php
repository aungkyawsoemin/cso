<?php


namespace MoOauthClient;

use MoOauthClient\StorageHandler;
class StorageManager
{
    private $storage_handler;
    const PRETTY = "\160\162\x65\164\x74\x79";
    const JSON = "\x6a\x73\157\156";
    const RAW = "\162\141\167";
    public function __construct($vf = '')
    {
        $this->storage_handler = new StorageHandler(empty($vf) ? $vf : base64_decode($vf));
    }
    private function decrypt($mf)
    {
        return empty($mf) || '' === $mf ? $mf : strtolower(hex2bin($mf));
    }
    private function encrypt($mf)
    {
        return empty($mf) || '' === $mf ? $mf : strtoupper(bin2hex($mf));
    }
    public function get_state()
    {
        return $this->storage_handler->stringify();
    }
    public function add_replace_entry($LG, $C0)
    {
        if ($C0) {
            goto TJ;
        }
        return;
        TJ:
        $C0 = is_string($C0) ? $C0 : wp_json_encode($C0);
        $this->storage_handler->add_replace_entry(bin2hex($LG), bin2hex($C0));
    }
    public function get_value($LG)
    {
        $C0 = $this->storage_handler->get_value(bin2hex($LG));
        if ($C0) {
            goto xc;
        }
        return false;
        xc:
        $fX = json_decode(hex2bin($C0), true);
        return json_last_error() === JSON_ERROR_NONE ? $fX : hex2bin($C0);
    }
    public function remove_key($LG)
    {
        $C0 = $this->storage_handler->remove_key(bin2hex($LG));
    }
    public function validate()
    {
        return $this->storage_handler->validate();
    }
    public function dump_all_storage($Dp = self::RAW)
    {
        $AD = $this->storage_handler->get_storage();
        $Yo = [];
        foreach ($AD as $LG => $C0) {
            $Xn = \hex2bin($LG);
            if ($Xn) {
                goto jq;
            }
            goto Jr;
            jq:
            $Yo[$Xn] = $this->get_value($Xn);
            Jr:
        }
        eM:
        switch ($Dp) {
            case self::PRETTY:
                echo "\x3c\x70\162\x65\x3e";
                print_r($Yo);
                echo "\x3c\x2f\160\x72\x65\76";
                goto i6;
            case self::JSON:
                echo \json_encode($Yo);
                goto i6;
            default:
            case self::RAW:
                print_r($Yo);
                goto i6;
        }
        OK:
        i6:
    }
}
