<?php


namespace MoOauthClient;

class StorageHandler
{
    private $storage;
    public function __construct($vf = '')
    {
        $t8 = empty($vf) || '' === $vf ? json_encode([]) : sanitize_text_field(wp_unslash($vf));
        $this->storage = json_decode($t8, true);
    }
    public function add_replace_entry($LG, $C0)
    {
        $this->storage[$LG]["\x56"] = $C0;
        $this->storage[$LG]["\110"] = md5($C0);
    }
    public function get_value($LG)
    {
        if (isset($this->storage[$LG])) {
            goto DG;
        }
        return false;
        DG:
        $C0 = $this->storage[$LG];
        if (!(!is_array($C0) || !isset($C0["\126"]) || !isset($C0["\110"]))) {
            goto Ar;
        }
        return false;
        Ar:
        if (!(md5($C0["\x56"]) !== $C0["\x48"])) {
            goto br;
        }
        return false;
        br:
        return $C0["\x56"];
    }
    public function remove_key($LG)
    {
        if (!isset($this->storage[$LG])) {
            goto Ya;
        }
        unset($this->storage[$LG]);
        Ya:
    }
    public function stringify()
    {
        global $Uc;
        $AD = $this->storage;
        $AD[\bin2hex("\165\x69\144")]["\x56"] = bin2hex(MO_UID);
        $AD[\bin2hex("\165\x69\x64")]["\110"] = md5($AD[\bin2hex("\x75\151\x64")]["\126"]);
        return $Uc->base64url_encode(wp_json_encode($AD));
    }
    public function get_storage()
    {
        return $this->storage;
    }
}
