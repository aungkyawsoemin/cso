<?php


namespace MoOauthClient;

use MoOauthClient\Base\InstanceHelper;
use MoOauthClient\OauthHandler;
use MoOauthClient\StorageManager;
use MoOauthClient\MO_Custom_OAuth1;
class LoginHandler
{
    public $oauth_handler;
    public function __construct()
    {
        $this->oauth_handler = new OauthHandler();
        add_action("\151\x6e\x69\x74", array($this, "\155\x6f\x5f\x6f\x61\165\164\x68\137\x64\145\143\151\144\145\x5f\146\x6c\x6f\167"));
        add_action("\x6d\157\x5f\x6f\x61\165\164\150\137\x63\x6c\x69\x65\x6e\x74\137\164\x69\147\150\164\137\x6c\157\147\151\156\137\x69\156\164\x65\x72\x6e\x61\x6c", array($this, "\x68\x61\156\x64\154\145\137\x73\163\x6f"), 10, 4);
    }
    public function mo_oauth_decide_flow()
    {
        global $Uc;
        if (!(isset($_REQUEST[\MoOAuthConstants::OPTION]) && "\164\x65\x73\x74\x61\x74\x74\x72\155\141\x70\160\x69\x6e\x67\143\157\156\146\151\x67" === $_REQUEST[\MoOAuthConstants::OPTION])) {
            goto Go;
        }
        $LL = $_REQUEST["\141\x70\160"];
        wp_safe_redirect(site_url() . "\x3f\x6f\x70\x74\151\157\x6e\x3d\x6f\141\x75\x74\x68\x72\x65\144\151\162\x65\x63\164\46\141\160\x70\x5f\156\x61\x6d\x65\75" . rawurlencode($LL) . "\46\x74\145\163\164\75\x74\x72\x75\x65");
        exit;
        Go:
        $this->mo_oauth_login_validate();
    }
    public function mo_oauth_login_validate()
    {
        global $Uc;
        $zQ = new StorageManager();
        if (!(isset($_REQUEST[\MoOAuthConstants::OPTION]) and strpos($_REQUEST[\MoOAuthConstants::OPTION], "\x6f\x61\165\x74\150\x72\x65\x64\x69\x72\x65\143\164") !== false)) {
            goto Ek;
        }
        if (isset($_REQUEST["\x6d\157\x5f\154\x6f\x67\x69\156\137\160\x6f\x70\165\x70"])) {
            goto Rm;
        }
        if (!(isset($_REQUEST["\162\145\163\157\x75\x72\x63\145"]) && !empty($_REQUEST["\162\x65\163\157\165\x72\143\145"]))) {
            goto WY;
        }
        if (!empty($_REQUEST["\162\x65\163\157\x75\162\x63\x65"])) {
            goto Qd;
        }
        $Uc->handle_error("\124\x68\x65\x20\x72\x65\163\160\x6f\x6e\163\145\40\146\162\x6f\155\40\x75\x73\x65\162\151\x6e\146\157\40\167\141\x73\x20\x65\155\160\x74\171\56");
        MO_Oauth_Debug::mo_oauth_log("\124\x68\145\40\162\x65\x73\160\x6f\156\163\145\x20\x66\162\157\x6d\x20\x75\x73\145\162\x69\156\146\157\x20\167\x61\163\x20\145\155\160\164\x79\x2e");
        wp_die(wp_kses("\x54\x68\145\x20\162\145\x73\x70\157\156\163\x65\x20\x66\x72\x6f\155\x20\165\163\x65\162\151\x6e\146\x6f\40\167\141\x73\40\145\x6d\160\164\171\x2e", \mo_oauth_get_valid_html()));
        Qd:
        $zQ = new StorageManager(urldecode($_REQUEST["\162\x65\163\157\x75\162\x63\x65"]));
        $ET = $zQ->get_value("\x72\x65\x73\x6f\165\x72\x63\145");
        $M9 = $zQ->get_value("\141\160\x70\x6e\141\155\x65");
        $ja = $zQ->get_value("\x72\145\144\x69\x72\145\x63\164\x5f\x75\162\151");
        $k_ = $zQ->get_value("\x61\143\143\145\163\x73\137\x74\x6f\153\x65\x6e");
        $Cf = $Uc->get_app_by_name($M9)->get_app_config();
        $pK = isset($_REQUEST["\164\145\x73\x74"]) && !empty($_REQUEST["\164\x65\x73\164"]);
        if (!($pK && '' !== $pK)) {
            goto oT;
        }
        $this->handle_group_test_conf($ET, $Cf, $k_, false, $pK);
        exit;
        oT:
        $zQ->remove_key("\x72\145\x73\157\165\x72\143\145");
        $zQ->add_replace_entry("\160\157\160\x75\160", "\151\x67\x6e\157\162\x65");
        if (!has_filter("\x77\157\x6f\143\157\x6d\x6d\x65\x72\143\145\137\143\x68\x65\x63\153\x6f\165\164\x5f\x67\145\164\137\166\x61\x6c\165\x65")) {
            goto HV;
        }
        $ET["\x61\x70\x70\x6e\x61\x6d\x65"] = $M9;
        HV:
        do_action("\155\157\x5f\141\x62\x72\137\x66\151\154\164\x65\162\x5f\x6c\x6f\x67\151\156", $ET);
        $this->handle_sso($M9, $Cf, $ET, $zQ->get_state(), ["\x61\x63\x63\145\x73\x73\x5f\164\x6f\153\145\x6e" => $k_]);
        WY:
        if (isset($_REQUEST["\x61\x70\160\x5f\x6e\141\x6d\145"])) {
            goto OF;
        }
        $jk = "\x50\154\x65\x61\163\145\x20\143\x68\145\x63\153\x20\151\x66\40\x79\x6f\x75\40\141\162\x65\40\163\x65\x6e\144\x69\x6e\x67\x20\x74\x68\x65\x20\x27\x61\x70\x70\137\x6e\x61\155\x65\47\x20\160\141\x72\141\x6d\x65\164\x65\162";
        $Uc->handle_error($jk);
        wp_die(wp_kses($jk, \mo_oauth_get_valid_html()));
        exit;
        OF:
        $og = isset($_REQUEST["\x61\x70\x70\x5f\156\x61\x6d\x65"]) && !empty($_REQUEST["\x61\x70\x70\137\156\x61\x6d\x65"]) ? $_REQUEST["\141\160\x70\x5f\x6e\141\155\145"] : '';
        if (!($og == '')) {
            goto Vt;
        }
        $jk = "\x4e\157\40\163\x75\x63\x68\x20\141\160\160\40\146\x6f\165\156\x64\40\x63\157\x6e\x66\151\147\x75\162\x65\144\x2e\40\120\154\x65\x61\x73\x65\x20\x63\150\145\x63\x6b\x20\151\146\x20\x79\x6f\x75\40\141\162\145\40\x73\145\x6e\144\x69\x6e\147\x20\164\150\x65\40\143\157\x72\162\145\143\x74\40\141\x70\160\137\156\141\155\145";
        MO_Oauth_Debug::mo_oauth_log($jk);
        $Uc->handle_error($jk);
        wp_die(wp_kses($jk, \mo_oauth_get_valid_html()));
        exit;
        Vt:
        $KJ = $Uc->mo_oauth_client_get_option("\155\157\x5f\157\x61\x75\x74\x68\137\141\x70\x70\x73\137\154\x69\163\x74");
        if (is_array($KJ) && isset($KJ[$og])) {
            goto GT;
        }
        $jk = "\x4e\157\x20\163\x75\143\150\40\141\x70\x70\40\x66\x6f\165\156\144\40\143\x6f\x6e\146\x69\147\165\162\x65\144\x2e\40\120\154\x65\x61\163\x65\x20\x63\150\x65\x63\153\x20\x69\146\x20\171\157\165\40\141\162\145\x20\x73\145\x6e\x64\x69\156\x67\x20\x74\x68\145\40\143\x6f\162\162\145\x63\x74\40\x61\160\160\137\156\x61\155\x65";
        MO_Oauth_Debug::mo_oauth_log($jk);
        $Uc->handle_error($jk);
        wp_die(wp_kses($jk, \mo_oauth_get_valid_html()));
        exit;
        GT:
        $bJ = "\57\x2f" . $_SERVER["\110\124\x54\x50\x5f\110\x4f\123\124"] . $_SERVER["\x52\105\x51\125\105\x53\x54\x5f\125\x52\111"];
        $bJ = strtok($bJ, "\77");
        $Ro = isset($_REQUEST["\x72\145\144\x69\x72\145\143\x74\x5f\x75\162\154"]) ? urldecode($_REQUEST["\x72\145\x64\x69\x72\x65\x63\164\x5f\165\162\x6c"]) : $bJ;
        $pK = isset($_REQUEST["\164\x65\x73\x74"]) ? urldecode($_REQUEST["\164\x65\163\x74"]) : false;
        $HO = isset($_REQUEST["\162\145\163\164\162\x69\143\x74\162\145\144\151\x72\145\143\x74"]) ? urldecode($_REQUEST["\162\145\x73\x74\162\151\x63\164\162\x65\144\151\x72\x65\143\164"]) : false;
        $Ts = $Uc->get_app_by_name($og);
        $JF = $Ts->get_app_config("\x67\x72\141\x6e\x74\137\x74\x79\x70\x65");
        if (!is_multisite()) {
            goto xN;
        }
        $blog_id = get_current_blog_id();
        $dU = $Uc->mo_oauth_client_get_option("\x6d\x6f\137\157\x61\165\164\x68\137\143\63\x56\151\x63\62\154\60\x5a\130\x4e\172\x5a\x57\x78\x6c\x59\63\122\154\132\x41");
        $AU = array();
        if (!isset($dU)) {
            goto pN;
        }
        $AU = json_decode($Uc->mooauthdecrypt($dU), true);
        pN:
        $ce = false;
        $rM = $Uc->mo_oauth_client_get_option("\155\x6f\x5f\x6f\x61\x75\164\150\137\x69\x73\x4d\165\x6c\x74\151\123\151\164\145\120\x6c\x75\x67\151\156\x52\x65\x71\165\x65\x73\x74\145\144");
        if (!(is_array($AU) && in_array($blog_id, $AU))) {
            goto SW;
        }
        $ce = true;
        SW:
        if (!(is_multisite() && $rM && ($rM && !$ce) && !$pK && $Uc->mo_oauth_client_get_option("\x6e\157\117\146\x53\165\x62\x53\151\x74\x65\163") < 1000)) {
            goto TF;
        }
        $Uc->handle_error("\114\157\x67\151\156\x20\x69\163\x20\144\x69\163\x61\x62\154\x65\x64\40\146\157\x72\40\164\150\x69\x73\x20\163\x69\x74\x65\x2e\x20\120\x6c\145\x61\x73\145\x20\x63\x6f\x6e\x74\x61\x63\x74\40\x79\x6f\x75\x72\x20\x61\x64\x6d\151\156\x69\163\164\x72\x61\164\x6f\x72\56");
        MO_Oauth_Debug::mo_oauth_log("\x4c\x6f\147\x69\x6e\40\151\163\40\144\151\x73\141\142\x6c\145\144\40\x66\157\x72\40\x74\x68\x69\163\x20\x73\x69\164\x65\x2e\x20\120\154\x65\141\x73\x65\40\x63\157\156\164\141\143\164\40\x79\x6f\x75\x72\40\141\144\155\x69\x6e\151\163\164\162\141\x74\x6f\162\x2e");
        wp_die("\x4c\157\x67\x69\156\40\151\x73\40\144\151\163\x61\142\154\145\144\40\146\x6f\162\x20\164\150\x69\x73\x20\x73\x69\164\x65\56\x20\x50\154\x65\141\163\x65\x20\143\157\x6e\164\x61\x63\x74\x20\171\x6f\165\x72\40\x61\144\155\151\x6e\151\163\164\x72\141\x74\157\x72\56");
        TF:
        $zQ->add_replace_entry("\x62\154\157\147\137\x69\144", $blog_id);
        xN:
        MO_Oauth_Debug::mo_oauth_log("\x47\x72\x61\156\x74\72\40" . $JF);
        if ($JF && "\120\141\163\x73\x77\x6f\162\x64\40\x47\x72\141\156\164" === $JF) {
            goto EO;
        }
        if (!($JF && "\x43\x6c\151\x65\x6e\164\40\x43\162\x65\144\x65\x6e\x74\x69\x61\x6c\x73\x20\x47\162\141\156\164" === $JF)) {
            goto j1;
        }
        do_action("\x6d\x6f\x5f\x6f\x61\165\x74\x68\x5f\x63\154\151\x65\x6e\x74\x5f\143\x72\145\x64\145\x6e\164\151\141\154\163\137\147\x72\141\156\164\137\151\x6e\151\164\151\141\x74\x65", $og, $pK);
        exit;
        j1:
        goto qG;
        EO:
        do_action("\160\x77\x64\x5f\x65\x73\163\x65\x6e\164\151\141\x6c\163\137\x69\x6e\164\x65\x72\x6e\141\x6c");
        do_action("\x6d\x6f\137\x6f\x61\165\164\150\137\x63\x6c\151\145\x6e\x74\137\141\x64\x64\x5f\160\167\144\x5f\x6a\x73");
        echo "\11\11\11\11\74\x73\x63\162\151\x70\x74\76\xd\12\x9\x9\11\11\11\166\141\162\x20\155\x6f\137\x6f\x61\x75\x74\x68\137\x61\x70\x70\137\x6e\141\x6d\145\40\75\40\42";
        echo wp_kses($og, \mo_oauth_get_valid_html());
        echo "\42\x3b\15\12\11\x9\x9\11\11\x64\157\143\x75\x6d\x65\x6e\164\56\x61\x64\x64\105\166\145\x6e\x74\114\x69\163\x74\145\156\145\x72\x28\47\x44\x4f\x4d\103\x6f\x6e\x74\x65\x6e\164\x4c\x6f\x61\x64\145\144\x27\54\x20\146\165\156\143\x74\x69\x6f\156\50\51\40\x7b\xd\12\x9\11\x9\11\x9\11";
        if ($pK) {
            goto yo;
        }
        echo "\x9\11\x9\11\x9\x9\11\x6d\157\117\101\x75\164\x68\114\x6f\147\x69\x6e\x50\167\144\x28\x6d\157\x5f\157\x61\165\164\150\137\141\x70\160\137\x6e\x61\x6d\145\x2c\x20\x66\141\x6c\x73\145\x2c\40\x27";
        echo $Ro;
        echo "\47\x29\73\15\12\11\x9\11\11\11\x9";
        goto R1;
        yo:
        echo "\x9\11\11\x9\11\x9\11\155\157\117\101\165\164\150\x4c\157\147\x69\x6e\120\167\144\x28\155\x6f\137\157\141\165\x74\x68\137\x61\x70\x70\137\x6e\x61\x6d\x65\x2c\x20\x74\x72\x75\145\54\40\47";
        echo $Ro;
        echo "\x27\x29\73\xd\12\x9\x9\x9\11\x9\11";
        R1:
        echo "\11\x9\x9\11\11\175\54\x20\146\141\154\x73\x65\x29\73\xd\12\x9\11\x9\x9\x3c\57\x73\143\x72\x69\160\164\76\15\xa\11\11\11\x9";
        exit;
        qG:
        if (!($Ts->get_app_config("\x61\x70\x70\x49\144") === "\164\x77\151\164\164\x65\162" || $Ts->get_app_config("\141\160\160\111\144") === "\x6f\x61\x75\x74\x68\x31")) {
            goto z7;
        }
        MO_Oauth_Debug::mo_oauth_log("\117\x61\165\164\150\61\x20\146\x6c\157\167");
        $pK = isset($_REQUEST["\x74\145\163\164"]) && !empty($_REQUEST["\164\145\x73\x74"]);
        if (!($pK && '' !== $pK)) {
            goto RX;
        }
        setcookie("\157\141\x75\x74\150\61\x5f\x74\x65\x73\164", "\x31", time() + 20);
        RX:
        setcookie("\157\141\165\x74\x68\61\x61\x70\160\156\141\x6d\145", $og, time() + 60);
        $_COOKIE["\157\x61\165\164\150\61\141\x70\x70\x6e\141\155\145"] = $og;
        MO_Custom_OAuth1::mo_oauth1_auth_request($og);
        exit;
        z7:
        $h3 = md5(rand(0, 15));
        $zQ->add_replace_entry("\141\160\160\x6e\x61\155\x65", $og);
        $zQ->add_replace_entry("\x72\x65\144\x69\x72\x65\x63\164\137\165\x72\151", $Ro);
        $zQ->add_replace_entry("\x74\x65\163\x74\137\x63\x6f\156\146\151\x67", $pK);
        $zQ->add_replace_entry("\162\x65\163\164\x72\151\x63\164\162\145\x64\151\162\x65\143\x74", $HO);
        $zQ->add_replace_entry("\163\164\141\x74\x65\137\x6e\x6f\x6e\143\145", $h3);
        $zQ = apply_filters("\155\157\137\157\x61\165\x74\x68\x5f\163\145\x74\x5f\143\x75\163\x74\157\155\x5f\x73\x74\157\x72\141\x67\145", $zQ);
        $Q7 = $zQ->get_state();
        $Q7 = apply_filters("\163\164\141\164\x65\x5f\151\156\x74\x65\x72\x6e\141\x6c", $Q7);
        $VS = $Ts->get_app_config("\141\x75\164\x68\x6f\162\151\x7a\145\165\x72\x6c");
        if (!($Ts->get_app_config("\163\x65\x6e\x64\x5f\x73\164\141\x74\x65") === false || $Ts->get_app_config("\x73\x65\x6e\144\x5f\163\x74\x61\164\x65") === '')) {
            goto oG;
        }
        $Ts->update_app_config("\163\x65\156\144\137\x73\x74\x61\x74\145", 1);
        $Uc->set_app_by_name($og, $Ts->get_app_config('', false));
        oG:
        if ($Ts->get_app_config("\x73\145\x6e\144\137\x73\164\141\x74\x65")) {
            goto wv;
        }
        setcookie("\x73\164\x61\164\145\x5f\x70\141\x72\141\155", $Q7, time() + 60);
        wv:
        $BA = $Ts->get_app_config("\x70\x6b\x63\x65\x5f\x66\x6c\x6f\x77");
        $ja = $Ts->get_app_config("\x72\x65\x64\151\162\x65\143\x74\137\165\162\x69");
        $FO = urlencode($Ts->get_app_config("\143\x6c\x69\x65\x6e\x74\137\151\x64"));
        $ja = empty($ja) ? \site_url() : $ja;
        if ($BA && 1 === $BA) {
            goto qL;
        }
        $ue = $Ts->get_app_config("\163\x65\156\144\x5f\x73\164\x61\x74\x65") ? "\46\163\164\x61\164\145\75" . $Q7 : '';
        if ($Ts->get_app_config("\x73\x65\156\144\137\163\164\141\164\x65")) {
            goto V6;
        }
        setcookie("\x73\x74\x61\164\x65\x5f\160\x61\x72\x61\x6d", $Q7, time() + 60);
        MO_Oauth_Debug::mo_oauth_log("\163\x74\141\x74\145\40\x70\141\x72\x61\155\x65\x74\145\162\40\156\157\x74\40\x73\x65\x6e\164");
        goto V3;
        V6:
        MO_Oauth_Debug::mo_oauth_log("\163\x74\141\x74\x65\x20\x70\141\162\141\x6d\145\164\x65\x72\x20\163\x65\x6e\x74");
        V3:
        if (strpos($VS, "\77") !== false) {
            goto Cu;
        }
        $VS = $VS . "\77\x63\154\151\x65\156\x74\137\151\x64\x3d" . $FO . "\46\163\x63\157\x70\x65\75" . $Ts->get_app_config("\163\x63\x6f\160\x65") . "\46\162\x65\x64\x69\x72\145\143\164\x5f\165\x72\151\x3d" . urlencode($ja) . "\x26\x72\145\163\x70\x6f\156\x73\145\137\164\171\x70\145\75\x63\157\x64\x65" . $ue;
        goto gd;
        Cu:
        $VS = $VS . "\46\x63\154\x69\145\x6e\x74\x5f\151\144\x3d" . $FO . "\x26\163\x63\x6f\160\x65\x3d" . $Ts->get_app_config("\163\x63\x6f\160\x65") . "\x26\162\x65\x64\151\162\145\x63\164\137\x75\162\151\x3d" . urlencode($ja) . "\x26\x72\x65\163\160\x6f\156\x73\x65\x5f\x74\171\x70\x65\x3d\x63\x6f\144\145" . $ue;
        gd:
        goto Gl;
        qL:
        MO_Oauth_Debug::mo_oauth_log("\x50\x4b\x43\x45\40\146\154\x6f\x77");
        $bw = bin2hex(openssl_random_pseudo_bytes(32));
        $r1 = $Uc->base64url_encode(pack("\110\52", $bw));
        $UX = $Uc->base64url_encode(pack("\110\52", hash("\x73\x68\x61\62\65\66", $r1)));
        $zQ->add_replace_entry("\x63\157\144\145\x5f\x76\x65\x72\151\146\151\145\x72", $r1);
        $Q7 = $zQ->get_state();
        $ue = $Ts->get_app_config("\163\x65\156\x64\x5f\x73\164\141\164\145") ? "\46\163\x74\x61\164\145\75" . $Q7 : '';
        if ($Ts->get_app_config("\163\x65\x6e\x64\137\163\164\x61\x74\x65")) {
            goto qz;
        }
        MO_Oauth_Debug::mo_oauth_log("\x73\x74\141\x74\145\40\x70\x61\162\141\155\x65\164\x65\x72\x20\x6e\x6f\x74\40\163\145\156\x74");
        goto Rt;
        qz:
        MO_Oauth_Debug::mo_oauth_log("\163\164\141\164\145\40\x70\141\x72\141\x6d\x65\x74\145\162\40\163\145\156\x74");
        Rt:
        if (strpos($VS, "\x3f") !== false) {
            goto S2;
        }
        $VS = $VS . "\x3f\x63\154\x69\145\x6e\x74\137\x69\x64\x3d" . $FO . "\x26\x73\x63\x6f\160\x65\x3d" . $Ts->get_app_config("\163\143\157\x70\145") . "\x26\x72\145\x64\151\162\145\x63\x74\137\165\x72\x69\x3d" . urlencode($ja) . "\x26\x72\145\163\160\157\156\x73\145\x5f\164\x79\x70\x65\75\x63\157\x64\145" . $ue . "\x26\x63\x6f\144\145\137\x63\150\141\x6c\x6c\145\156\x67\145\x3d" . $UX . "\46\143\157\x64\145\137\x63\x68\141\x6c\x6c\145\x6e\147\x65\x5f\x6d\x65\x74\150\157\x64\75\x53\x32\65\x36";
        goto zM;
        S2:
        $VS = $VS . "\x26\x63\154\151\145\156\x74\137\x69\144\x3d" . $FO . "\x26\163\143\157\160\145\75" . $Ts->get_app_config("\163\143\157\x70\145") . "\x26\x72\145\144\151\162\145\143\x74\137\x75\162\x69\x3d" . urlencode($ja) . "\x26\162\x65\x73\x70\x6f\x6e\x73\x65\x5f\x74\171\160\145\x3d\143\157\144\x65" . $ue . "\46\x63\x6f\144\x65\x5f\x63\150\141\154\x6c\x65\156\x67\x65\75" . $UX . "\x26\x63\x6f\144\x65\x5f\x63\x68\x61\154\154\145\x6e\x67\145\x5f\155\x65\164\x68\x6f\x64\x3d\x53\62\65\66";
        zM:
        Gl:
        if (!(null !== $Ts->get_app_config("\163\145\x6e\144\137\156\157\156\x63\145") && $Ts->get_app_config("\x73\x65\x6e\144\x5f\x6e\x6f\x6e\143\145"))) {
            goto bL;
        }
        $j_ = md5(rand());
        $Uc->set_transient("\155\x6f\137\x6f\141\165\164\x68\x5f\x6e\157\156\x63\x65\x5f" . $j_, $j_, time() + 120);
        $VS = $VS . "\x26\156\157\x6e\x63\145\x3d" . $j_;
        MO_Oauth_Debug::mo_oauth_log("\156\157\x6e\143\145\40\160\x61\x72\x61\155\x65\x74\x65\162\x20\x73\145\x6e\164");
        bL:
        if (!(strpos($VS, "\x61\x70\x70\154\145") !== false)) {
            goto KV;
        }
        $VS = $VS . "\46\x72\145\x73\x70\157\156\x73\145\137\155\x6f\x64\145\x3d\146\157\162\x6d\x5f\x70\x6f\163\164";
        KV:
        $VS = apply_filters("\155\x6f\x5f\x61\x75\x74\x68\x5f\x75\x72\x6c\x5f\x69\156\x74\x65\162\x6e\141\x6c", $VS, $og);
        MO_Oauth_Debug::mo_oauth_log("\101\x75\164\x68\157\162\151\172\x61\x69\157\x6e\40\x45\156\x64\160\x6f\x69\x6e\164\40\x3d\x3e\40" . $VS);
        header("\114\157\143\141\164\151\x6f\156\72\x20" . $VS);
        exit;
        Rm:
        Ek:
        if (isset($_GET["\x65\x72\x72\157\162\x5f\x64\145\163\x63\x72\x69\160\x74\x69\157\156"])) {
            goto Kr;
        }
        if (!isset($_GET["\x65\162\162\x6f\x72"])) {
            goto dq;
        }
        do_action("\155\157\x5f\162\145\144\151\162\145\x63\164\x5f\x74\157\x5f\x63\x75\x73\164\x6f\x6d\x5f\145\162\162\157\x72\x5f\x70\141\x67\x65");
        $eC = "\x45\x72\x72\157\x72\40\146\162\x6f\155\x20\101\x75\164\150\157\x72\x69\x7a\145\x20\105\x6e\144\x70\157\x69\x6e\164\72\x20" . sanitize_text_field($_GET["\145\x72\x72\157\162"]);
        MO_Oauth_Debug::mo_oauth_log($eC);
        $Uc->handle_error($eC);
        wp_die($eC);
        dq:
        goto XP;
        Kr:
        if (!(strpos($_GET["\163\164\x61\x74\145"], "\144\157\153\x61\x6e\x2d\163\x74\x72\151\x70\145\55\143\x6f\156\x6e\x65\143\x74") !== false)) {
            goto ba;
        }
        return;
        ba:
        do_action("\x6d\157\x5f\x72\x65\144\x69\x72\x65\x63\x74\x5f\x74\x6f\x5f\x63\x75\163\164\157\x6d\137\145\x72\162\157\162\x5f\160\x61\147\145");
        $gp = "\x45\162\162\x6f\162\x20\144\145\163\x63\162\151\160\x74\x69\157\x6e\x20\x66\x72\x6f\x6d\40\101\x75\164\150\x6f\162\151\x7a\x65\40\x45\x6e\x64\160\157\151\x6e\164\x3a\x20" . sanitize_text_field($_GET["\x65\x72\162\x6f\x72\x5f\x64\x65\163\x63\162\x69\x70\164\151\157\x6e"]);
        MO_Oauth_Debug::mo_oauth_log($gp);
        $Uc->handle_error($gp);
        wp_die($gp);
        XP:
        if (!(strpos($_SERVER["\x52\105\x51\x55\105\x53\124\137\x55\122\111"], "\x6f\160\145\x6e\151\x64\x63\141\x6c\154\142\141\x63\x6b") !== false || strpos($_SERVER["\122\105\121\125\105\123\x54\x5f\x55\x52\111"], "\157\141\165\x74\150\x5f\x74\x6f\153\145\156") !== false && strpos($_SERVER["\x52\x45\x51\125\105\x53\124\137\125\122\111"], "\157\141\165\x74\x68\x5f\x76\x65\162\x69\x66\x69\x65\162"))) {
            goto AA;
        }
        MO_Oauth_Debug::mo_oauth_log("\x4f\x61\x75\x74\x68\x31\40\143\141\x6c\x6c\142\141\x63\153\x20\x66\154\157\167");
        if (!empty($_COOKIE["\157\x61\x75\x74\x68\61\141\x70\x70\156\141\x6d\145"])) {
            goto a4;
        }
        MO_Oauth_Debug::mo_oauth_log("\x52\145\164\165\162\156\151\x6e\147\x20\146\x72\157\155\40\117\x41\x75\x74\x68\61");
        return;
        a4:
        MO_Oauth_Debug::mo_oauth_log("\x4f\x41\165\164\150\x31\40\141\x70\x70\x20\146\x6f\x75\x6e\x64");
        $og = $_COOKIE["\x6f\141\x75\164\x68\x31\x61\x70\160\x6e\x61\155\145"];
        $ET = MO_Custom_OAuth1::mo_oidc1_get_access_token($_COOKIE["\157\141\x75\x74\x68\x31\141\x70\x70\156\x61\x6d\x65"]);
        $Ko = apply_filters("\x6d\x6f\137\164\x72\137\141\146\164\145\x72\x5f\x70\x72\157\146\x69\x6c\145\137\x69\x6e\146\157\137\145\x78\x74\162\x61\x63\164\x69\x6f\x6e\x5f\x66\x72\157\x6d\x5f\164\x6f\153\145\156", $ET);
        $lc = [];
        $bj = $this->dropdownattrmapping('', $ET, $lc);
        $Uc->mo_oauth_client_update_option("\x6d\x6f\137\x6f\141\x75\164\150\137\141\164\x74\162\137\156\x61\x6d\145\x5f\x6c\x69\163\x74" . $og, $bj);
        if (!(isset($_COOKIE["\x6f\141\x75\164\x68\61\x5f\x74\x65\x73\x74"]) && $_COOKIE["\x6f\x61\x75\164\x68\61\x5f\164\x65\163\x74"] == "\x31")) {
            goto mt;
        }
        $Ts = $Uc->get_app_by_name($og);
        $dm = $Ts->get_app_config();
        $this->render_test_config_output($ET, false, $dm, $og);
        exit;
        mt:
        $Ts = $Uc->get_app_by_name($og);
        $fD = $Ts->get_app_config("\165\163\145\162\x6e\141\155\x65\137\x61\164\164\x72");
        $X9 = isset($Cf["\145\x6d\141\x69\x6c\137\141\164\x74\x72"]) ? $Cf["\145\x6d\x61\x69\154\137\141\x74\164\162"] : '';
        $gK = $Uc->getnestedattribute($ET, $X9);
        $Mk = $Uc->getnestedattribute($ET, $fD);
        if (!empty($Mk)) {
            goto Mo;
        }
        MO_Oauth_Debug::mo_oauth_log("\x55\163\145\162\x6e\x61\x6d\145\40\x6e\157\x74\x20\x72\x65\x63\x65\151\166\x65\144\56\120\x6c\145\x61\163\x65\x20\x63\x6f\156\146\151\147\x75\162\x65\x20\101\x74\x74\162\x69\142\x75\164\x65\40\115\141\160\160\151\x6e\x67");
        wp_die("\125\163\145\x72\x6e\x61\155\145\x20\156\x6f\164\x20\x72\145\x63\x65\x69\x76\145\x64\x2e\x50\x6c\x65\141\x73\x65\40\x63\x6f\156\x66\x69\x67\x75\162\145\x20\x41\164\x74\162\x69\142\x75\x74\x65\x20\x4d\x61\x70\160\151\156\x67");
        Mo:
        if (!empty($gK)) {
            goto au;
        }
        $user = get_user_by("\x6c\x6f\x67\x69\x6e", $Mk);
        goto xo;
        au:
        $gK = $Uc->getnestedattribute($ET, $X9);
        if (!(false === strpos($gK, "\x40"))) {
            goto OG;
        }
        MO_Oauth_Debug::mo_oauth_log("\x4d\141\160\x70\x65\x64\x20\x45\x6d\x61\151\154\x20\x61\x74\164\x72\151\142\x75\164\x65\40\x64\x6f\145\x73\x20\156\x6f\164\x20\x63\x6f\x6e\x74\x61\x69\156\40\166\x61\154\151\x64\40\x65\x6d\x61\x69\154\56");
        wp_die("\x4d\141\160\160\145\x64\40\x45\155\141\151\154\x20\x61\x74\164\162\x69\x62\x75\x74\145\40\x64\157\145\163\40\156\x6f\x74\40\x63\157\156\x74\x61\x69\156\x20\x76\141\x6c\151\x64\x20\145\x6d\141\151\x6c\x2e");
        OG:
        xo:
        if ($user) {
            goto Ql;
        }
        $KK = 0;
        if ($Uc->mo_oauth_hbca_xyake()) {
            goto nL;
        }
        $user = $Uc->mo_oauth_hjsguh_kiishuyauh878gs($gK, $Mk);
        goto qZ;
        nL:
        if ($Uc->mo_oauth_client_get_option("\155\157\x5f\157\x61\x75\x74\x68\137\146\x6c\141\147") !== true) {
            goto Db;
        }
        $LD = base64_decode("PGRpdiBzdHlsZT0ndGV4dC1hbGlnbjpjZW50ZXI7Jz48Yj5Vc2VyIEFjY291bnQgZG9lcyBub3QgZXhpc3QuPC9iPjwvZGl2Pjxicj48c21hbGw+VGhpcyB2ZXJzaW9uIHN1cHBvcnRzIEF1dG8gQ3JlYXRlIFVzZXIgZmVhdHVyZSB1cHRvIDEwIFVzZXJzLiBQbGVhc2UgdXBncmFkZSB0byB0aGUgaGlnaGVyIHZlcnNpb24gb2YgdGhlIHBsdWdpbiB0byBlbmFibGUgYXV0byBjcmVhdGUgdXNlciBmb3IgdW5saW1pdGVkIHVzZXJzIG9yIGFkZCB1c2VyIG1hbnVhbGx5Ljwvc21hbGw+");
        MO_Oauth_Debug::mo_oauth_log($LD);
        wp_die($LD);
        goto FB;
        Db:
        if (!empty($gK)) {
            goto kD;
        }
        $user = $Uc->mo_oauth_jhuyn_jgsukaj($Mk, $Mk);
        goto l_;
        kD:
        $user = $Uc->mo_oauth_jhuyn_jgsukaj($gK, $Mk);
        l_:
        FB:
        qZ:
        goto v8;
        Ql:
        $KK = $user->ID;
        v8:
        if (!$user) {
            goto CT;
        }
        wp_set_current_user($user->ID);
        $TC = false;
        $TC = apply_filters("\155\x6f\137\x72\x65\155\x65\x6d\142\x65\162\x5f\x6d\145", $TC);
        wp_set_auth_cookie($user->ID, $TC);
        $user = get_user_by("\111\104", $user->ID);
        do_action("\167\x70\x5f\x6c\157\x67\x69\156", $user->user_login, $user);
        wp_safe_redirect(home_url());
        exit;
        CT:
        AA:
        if (!(!isset($_SERVER["\x48\124\x54\120\137\x58\137\x52\x45\x51\125\x45\123\124\105\x44\x5f\x57\111\x54\x48"]) && (strpos($_SERVER["\x52\105\x51\125\x45\123\x54\137\125\x52\111"], "\x2f\x6f\141\x75\x74\x68\143\x61\x6c\154\142\x61\143\153") !== false || isset($_REQUEST["\143\x6f\144\x65"]) && !empty($_REQUEST["\143\x6f\144\145"]) && !isset($_REQUEST["\151\144\x5f\164\x6f\x6b\145\156"])))) {
            goto Fa;
        }
        if (!(isset($_REQUEST["\x70\x6f\x73\x74\x5f\x49\104"]) || isset($_REQUEST["\x65\x64\144\55\141\143\x74\151\157\x6e"]))) {
            goto dG;
        }
        return;
        dG:
        try {
            if (isset($_COOKIE["\x73\x74\141\x74\145\x5f\x70\x61\162\x61\x6d"])) {
                goto SG;
            }
            if (isset($_GET["\163\x74\x61\164\x65"])) {
                goto G6;
            }
            $rL = new StorageManager();
            if (!is_multisite()) {
                goto Xn;
            }
            $rL->add_replace_entry("\x62\x6c\x6f\147\x5f\151\x64", 1);
            Xn:
            $tk = $Uc->get_app_by_name();
            if (isset($_GET["\141\x70\160\x5f\156\141\x6d\145"])) {
                goto CU;
            }
            $rL->add_replace_entry("\x61\160\160\x6e\141\155\x65", $tk->get_app_name());
            goto kh;
            CU:
            $rL->add_replace_entry("\x61\160\x70\156\141\155\145", $_GET["\x61\160\x70\137\156\141\155\145"]);
            kh:
            $rL->add_replace_entry("\164\x65\163\164\137\143\157\156\x66\x69\147", false);
            $rL->add_replace_entry("\162\145\x64\151\x72\x65\143\164\137\x75\x72\x69", site_url());
            $Q7 = $rL->get_state();
            goto iW;
            G6:
            $Q7 = wp_unslash($_GET["\163\164\141\x74\x65"]);
            iW:
            goto M5;
            SG:
            $Q7 = $_COOKIE["\163\164\141\x74\145\137\x70\141\x72\x61\x6d"];
            M5:
            $zQ = new StorageManager($Q7);
            if (!empty($zQ->get_value("\x61\160\x70\x6e\x61\x6d\145"))) {
                goto Xr;
            }
            return;
            Xr:
            $og = $zQ->get_value("\141\160\x70\156\x61\x6d\145");
            $pK = $zQ->get_value("\x74\145\x73\x74\137\143\x6f\x6e\146\x69\147");
            if (!is_multisite()) {
                goto gV;
            }
            if (!(empty($zQ->get_value("\x72\x65\144\151\x72\x65\x63\x74\145\144\137\x74\157\137\x73\165\142\163\151\x74\x65")) || $zQ->get_value("\162\x65\144\x69\x72\x65\143\164\145\x64\x5f\164\157\137\163\x75\x62\x73\x69\x74\x65") !== "\162\145\144\x69\162\145\143\164")) {
                goto h5;
            }
            MO_Oauth_Debug::mo_oauth_log("\122\145\144\151\x72\145\x63\164\x69\x6e\x67\x20\x66\157\x72\40\155\165\x6c\164\x69\x73\x74\145\40\163\x75\142\x73\x69\x74\145");
            $blog_id = $zQ->get_value("\142\154\157\147\x5f\x69\144");
            $b0 = get_site_url($blog_id);
            $zQ->add_replace_entry("\162\145\x64\151\162\x65\143\164\145\x64\137\x74\157\137\163\165\142\x73\151\164\x65", "\162\145\144\x69\162\x65\x63\x74");
            $Ay = $zQ->get_state();
            $b0 = $b0 . "\77\143\x6f\144\145\75" . $_GET["\x63\157\144\145"] . "\x26\163\164\x61\x74\145\x3d" . $Ay;
            wp_redirect($b0);
            exit;
            h5:
            gV:
            $M9 = $og ? $og : '';
            $KJ = $Uc->mo_oauth_client_get_option("\x6d\x6f\137\x6f\141\x75\164\150\x5f\141\x70\160\x73\137\154\x69\x73\x74");
            $fD = '';
            $X9 = '';
            $IG = $Uc->get_app_by_name($M9);
            if ($IG) {
                goto UB;
            }
            $Uc->handle_error("\x41\x70\x70\154\x69\x63\141\x74\151\157\156\40\156\157\164\40\143\x6f\156\146\151\147\165\x72\145\x64\56");
            MO_Oauth_Debug::mo_oauth_log("\x41\160\160\154\x69\143\141\x74\151\157\156\x20\x6e\157\x74\x20\143\157\x6e\146\x69\x67\165\162\145\x64\56");
            exit("\101\x70\160\154\x69\x63\x61\x74\x69\x6f\156\40\x6e\157\x74\x20\143\x6f\156\146\x69\147\165\162\x65\x64\x2e");
            UB:
            $Cf = $IG->get_app_config();
            if (!(isset($Cf["\x73\x65\x6e\144\x5f\156\157\x6e\143\x65"]) && $Cf["\163\145\x6e\144\137\x6e\x6f\156\143\x65"] === 1)) {
                goto QT;
            }
            if (!(isset($_REQUEST["\156\157\156\x63\145"]) && !$Uc->get_transient("\155\157\x5f\157\141\165\x74\x68\137\156\x6f\156\143\x65\x5f" . $_REQUEST["\156\x6f\x6e\143\145"]))) {
                goto zb;
            }
            $eC = "\x4e\x6f\156\x63\x65\x20\166\x65\162\151\x66\x69\143\x61\x74\x69\x6f\x6e\40\151\163\40\x66\141\151\154\145\144\x2e\x20\x50\x6c\x65\141\163\145\40\143\x6f\x6e\x74\141\x63\164\x20\x74\x6f\40\x79\157\165\x72\40\x61\x64\x6d\151\x6e\x69\163\164\x72\x61\x74\157\x72\56";
            $Uc->handle_error($eC);
            MO_Oauth_Debug::mo_oauth_log($eC);
            wp_die($eC);
            zb:
            QT:
            $BA = $IG->get_app_config("\160\x6b\143\x65\x5f\x66\x6c\x6f\167");
            $KF = $IG->get_app_config("\160\x6b\143\145\137\x63\x6c\x69\x65\x6e\164\x5f\x73\x65\143\x72\x65\164");
            $nK = array("\x67\162\141\x6e\x74\137\x74\171\x70\145" => "\x61\165\x74\150\x6f\162\x69\172\141\x74\151\x6f\x6e\x5f\x63\x6f\x64\145", "\143\154\151\145\x6e\x74\137\x69\144" => $Cf["\143\x6c\151\145\156\x74\137\151\144"], "\162\145\x64\151\x72\145\x63\164\x5f\165\x72\151" => $Cf["\162\145\x64\x69\x72\x65\143\164\x5f\165\162\x69"], "\x63\x6f\144\x65" => $_REQUEST["\x63\157\x64\x65"]);
            if (!(strpos($Cf["\141\x63\x63\x65\x73\163\164\x6f\x6b\145\x6e\165\x72\154"], "\x73\145\x72\x76\151\143\145\x73\x2f\157\x61\165\164\150\62\x2f\x74\x6f\x6b\x65\156") === false && strpos($Cf["\141\x63\143\x65\163\x73\x74\x6f\153\x65\156\x75\x72\x6c"], "\x73\x61\154\x65\163\146\x6f\x72\x63\145") === false && strpos($Cf["\x61\143\143\x65\x73\163\164\x6f\153\145\156\165\162\154"], "\x2f\x6f\x61\x6d\x2f\157\x61\x75\x74\x68\62\57\x61\143\143\x65\x73\x73\x5f\x74\x6f\153\145\x6e") === false)) {
                goto zG;
            }
            $nK["\x73\143\x6f\160\x65"] = $IG->get_app_config("\x73\x63\157\x70\x65");
            zG:
            if ($BA && 1 === $BA) {
                goto Br;
            }
            $nK["\x63\154\151\145\x6e\x74\137\163\x65\x63\162\x65\x74"] = $Cf["\143\154\x69\145\x6e\x74\x5f\163\x65\x63\162\x65\x74"];
            goto V_;
            Br:
            if (!($KF && 1 === $KF)) {
                goto s5;
            }
            $nK["\143\x6c\151\145\x6e\x74\137\x73\x65\143\x72\x65\x74"] = $Cf["\143\154\151\145\156\x74\137\x73\x65\x63\x72\x65\164"];
            s5:
            $nK = apply_filters("\x6d\x6f\137\157\141\x75\164\150\137\141\144\x64\x5f\x63\154\x69\x65\156\164\137\163\145\x63\162\x65\164\x5f\160\153\x63\145\137\146\154\x6f\x77", $nK, $Cf);
            $nK["\x63\x6f\144\145\137\166\x65\x72\x69\x66\151\x65\162"] = $zQ->get_value("\x63\157\144\x65\x5f\x76\x65\162\x69\146\151\145\162");
            V_:
            $jV = isset($Cf["\163\145\x6e\x64\137\x68\145\x61\x64\x65\162\163"]) ? $Cf["\163\145\156\x64\x5f\150\x65\141\144\x65\162\163"] : 0;
            $vN = isset($Cf["\163\x65\156\x64\x5f\x62\x6f\144\x79"]) ? $Cf["\x73\x65\x6e\144\137\142\157\x64\x79"] : 0;
            if ("\x6f\x70\145\156\151\144\143\157\156\x6e\145\x63\164" === $IG->get_app_config("\141\x70\x70\x5f\x74\x79\160\x65")) {
                goto jg;
            }
            $Xq = $Cf["\x61\x63\x63\145\163\x73\x74\157\x6b\145\x6e\165\162\154"];
            MO_Oauth_Debug::mo_oauth_log("\x4f\101\x75\164\x68\40\146\154\157\167");
            if (strpos($Cf["\x61\x75\164\150\157\x72\x69\x7a\x65\165\162\x6c"], "\143\x6c\145\166\x65\x72\56\143\157\x6d\57\x6f\141\x75\x74\150") != false || strpos($Cf["\141\x63\x63\x65\163\163\x74\157\153\145\x6e\165\x72\154"], "\142\x69\x74\x72\x69\170") != false) {
                goto Nq;
            }
            $dK = json_decode($this->oauth_handler->get_token($Xq, $nK, $jV, $vN), true);
            goto lg;
            Nq:
            $dK = json_decode($this->oauth_handler->get_atoken($Xq, $nK, $_GET["\x63\157\144\x65"], $jV, $vN), true);
            lg:
            if (!(get_current_user_id() && $pK != 1)) {
                goto Un;
            }
            wp_clear_auth_cookie();
            wp_set_current_user(0);
            Un:
            $_SESSION["\x70\162\x6f\x63\x6f\x72\145\137\x61\x63\143\x65\x73\163\137\x74\157\153\145\156"] = isset($dK["\141\143\x63\x65\x73\x73\137\164\157\153\145\x6e"]) ? $dK["\x61\x63\x63\145\163\x73\x5f\164\x6f\153\145\156"] : false;
            if (isset($dK["\x61\x63\143\x65\163\163\137\164\x6f\153\145\x6e"])) {
                goto lH;
            }
            do_action("\x6d\157\137\162\145\144\151\x72\x65\143\164\137\x74\157\x5f\143\x75\163\164\157\x6d\x5f\145\162\x72\157\x72\137\160\141\147\145");
            $Uc->handle_error("\x49\x6e\166\141\x6c\x69\x64\x20\x74\157\x6b\x65\156\40\162\145\143\145\151\166\x65\x64\56");
            MO_Oauth_Debug::mo_oauth_log("\x49\x6e\x76\141\154\151\x64\40\164\157\153\x65\x6e\40\162\145\x63\x65\x69\x76\x65\144\x2e");
            exit("\111\x6e\x76\141\x6c\x69\x64\40\164\157\153\x65\x6e\40\162\145\x63\x65\151\x76\145\x64\56");
            lH:
            MO_Oauth_Debug::mo_oauth_log("\x54\157\x6b\x65\x6e\x20\x52\x65\x73\160\157\x6e\163\145\x20\x3d\76\x20");
            MO_Oauth_Debug::mo_oauth_log($dK);
            $NI = $Cf["\162\145\163\x6f\165\x72\x63\145\157\167\156\x65\x72\144\x65\164\x61\151\154\163\x75\162\x6c"];
            if (!(substr($NI, -1) === "\x3d")) {
                goto n5;
            }
            $NI .= $dK["\x61\x63\143\145\163\163\x5f\x74\157\x6b\x65\x6e"];
            n5:
            MO_Oauth_Debug::mo_oauth_log("\x41\x63\x63\145\x73\x73\40\x74\x6f\x6b\x65\x6e\x20\x72\145\143\x65\x69\166\x65\144\x2e");
            MO_Oauth_Debug::mo_oauth_log("\x41\x63\x63\x65\163\163\x20\124\x6f\x6b\x65\x6e\x20\x3d\x3e\40" . $dK["\x61\143\143\x65\x73\x73\137\164\157\153\145\156"]);
            $ET = false;
            MO_Oauth_Debug::mo_oauth_log("\x52\145\163\x6f\x75\162\x63\145\x20\117\167\156\145\x72\40\75\76\40");
            if (!has_filter("\155\157\137\165\x73\x65\x72\x69\156\x66\x6f\137\x66\154\157\x77\137\x66\157\x72\x5f\167\x61\x6c\x6d\x61\x72\164")) {
                goto WH;
            }
            $ET = apply_filters("\x6d\157\137\165\163\x65\162\x69\156\146\x6f\137\x66\x6c\x6f\167\137\146\x6f\162\137\167\141\x6c\155\141\x72\x74", $NI, $dK, $nK, $M9, $Cf);
            WH:
            if (!($ET === false)) {
                goto aw;
            }
            $UY = null;
            $UY = apply_filters("\x6d\157\137\160\x6f\154\141\x72\137\x72\145\147\151\x73\x74\145\162\137\x75\x73\x65\162", $dK);
            if (!(!empty($UY) && !empty($dK["\x78\137\165\x73\x65\x72\137\151\144"]))) {
                goto a1;
            }
            $NI .= "\57" . $dK["\x78\x5f\165\163\145\x72\x5f\x69\x64"];
            a1:
            $ET = $this->oauth_handler->get_resource_owner($NI, $dK["\141\x63\143\x65\163\163\137\x74\x6f\153\145\156"]);
            $et = array();
            if (!(strpos($IG->get_app_config("\x61\165\x74\150\157\162\x69\x7a\145\165\162\x6c"), "\154\x69\156\x6b\145\144\151\156") !== false && strpos($Cf["\x73\143\157\160\145"], "\162\137\x65\155\x61\151\x6c\x61\x64\144\x72\145\163\163") != false)) {
                goto NM;
            }
            $tx = "\150\x74\x74\x70\163\72\57\57\x61\160\151\x2e\x6c\x69\x6e\x6b\145\144\151\x6e\56\143\157\x6d\x2f\166\x32\57\x65\x6d\x61\x69\154\x41\x64\x64\162\x65\x73\163\77\x71\75\155\x65\155\x62\145\162\x73\46\160\162\157\x6a\145\x63\x74\x69\x6f\x6e\x3d\50\x65\x6c\145\x6d\x65\x6e\164\163\52\x28\150\x61\156\144\154\x65\176\x29\x29";
            $et = $this->oauth_handler->get_resource_owner($tx, $dK["\x61\x63\143\145\163\163\137\x74\x6f\x6b\x65\x6e"]);
            NM:
            $ET = array_merge($ET, $et);
            aw:
            if (!has_filter("\x6d\157\137\x63\x68\145\143\153\x5f\x74\x6f\137\145\170\145\143\165\164\x65\137\x70\x6f\x73\164\137\x75\x73\145\162\151\156\x66\157\x5f\146\x6c\157\167\x5f\x66\x6f\162\x5f\167\141\154\155\141\x72\x74")) {
                goto Tz;
            }
            $ET = apply_filters("\155\157\137\143\x68\x65\x63\153\137\x74\157\x5f\x65\170\145\143\x75\164\145\137\160\157\163\164\137\x75\x73\145\162\151\156\146\157\x5f\146\x6c\157\167\137\x66\157\x72\137\x77\141\154\x6d\141\x72\164", $ET, $M9, $Cf);
            Tz:
            MO_Oauth_Debug::mo_oauth_log($ET);
            $Ko = apply_filters("\x6d\157\137\164\x72\137\x61\x66\x74\145\162\x5f\160\162\157\146\x69\x6c\145\x5f\x69\x6e\146\x6f\137\145\170\x74\x72\x61\143\x74\x69\x6f\156\x5f\x66\162\157\x6d\x5f\164\157\x6b\145\156", $ET);
            if (!($Ko != '' && is_array($Ko))) {
                goto dB;
            }
            $ET = array_merge($ET, $Ko);
            dB:
            $fn = apply_filters("\x61\143\x63\162\145\x64\151\x74\151\157\x6e\x73\137\145\x6e\x64\160\x6f\x69\x6e\x74", $dK["\x61\143\x63\145\163\x73\x5f\x74\157\x6b\145\x6e"]);
            if (!($fn !== '' && is_array($fn))) {
                goto eH;
            }
            $ET = array_merge($ET, $fn);
            eH:
            if (!has_filter("\155\x6f\x5f\x70\157\x6c\x61\162\x5f\x72\x65\147\151\163\x74\x65\x72\x5f\165\163\145\x72")) {
                goto nB;
            }
            $l2 = array();
            $l2["\164\x6f\x6b\145\x6e"] = $dK["\141\143\x63\145\x73\163\x5f\x74\157\x6b\145\x6e"];
            $ET = array_merge($ET, $l2);
            nB:
            if (!(strpos($IG->get_app_config("\141\165\164\150\157\x72\x69\172\145\165\162\154"), "\144\x69\x73\143\x6f\162\144") !== false)) {
                goto ck;
            }
            apply_filters("\155\157\137\144\151\x73\x5f\165\163\x65\x72\137\x61\164\164\x65\x6e\x64\x61\x6e\x63\145", $ET["\151\144"]);
            $Cq = apply_filters("\x6d\x6f\x5f\x64\162\x6d\x5f\147\x65\164\137\165\163\145\162\137\162\157\x6c\145\163", array_key_exists("\151\x64", $ET) ? $ET["\151\144"] : '');
            if (!(false !== $Cq)) {
                goto Av;
            }
            MO_Oauth_Debug::mo_oauth_log("\104\151\163\143\x6f\162\144\x20\122\157\154\145\x73\x20\x3d\x3e\x20");
            MO_Oauth_Debug::mo_oauth_log($Cq);
            $ET["\162\157\x6c\x65\163"] = $Cq;
            Av:
            $KP = $zQ->get_value("\144\x69\x73\x63\157\x72\x64\137\x75\x73\145\x72\x5f\x69\x64");
            do_action("\x6d\x6f\x5f\157\141\x75\x74\x68\137\141\x64\144\x5f\144\x69\x73\137\x75\x73\x65\x72\137\163\145\162\x76\145\162", $KP, $dK, $ET);
            ck:
            if (!(isset($Cf["\x73\145\156\x64\x5f\156\x6f\156\x63\x65"]) && $Cf["\163\145\x6e\x64\x5f\156\x6f\x6e\x63\145"] === 1)) {
                goto EV;
            }
            if (!(isset($ET["\156\x6f\x6e\x63\x65"]) && $ET["\156\x6f\x6e\143\x65"] != NULL)) {
                goto gK;
            }
            if ($Uc->get_transient("\x6d\x6f\137\157\141\165\164\150\x5f\x6e\157\x6e\x63\x65\x5f" . $ET["\x6e\157\156\143\x65"])) {
                goto Dy;
            }
            $eC = "\x4e\157\156\143\145\40\166\145\x72\151\x66\151\143\x61\164\x69\157\x6e\40\151\x73\40\x66\x61\x69\x6c\145\x64\56\40\x50\154\145\141\163\145\40\x63\157\156\x74\141\143\x74\x20\164\x6f\x20\171\x6f\165\x72\40\x61\144\155\151\x6e\x69\x73\164\x72\x61\164\157\x72\56";
            $Uc->handle_error($eC);
            MO_Oauth_Debug::mo_oauth_log($eC);
            wp_die($eC);
            goto Qt;
            Dy:
            $Uc->delete_transient("\155\x6f\137\157\141\165\164\x68\x5f\x6e\157\156\143\x65\137" . $ET["\156\x6f\156\143\x65"]);
            Qt:
            gK:
            EV:
            $lc = [];
            $bj = $this->dropdownattrmapping('', $ET, $lc);
            $Uc->mo_oauth_client_update_option("\155\157\x5f\157\x61\x75\x74\x68\137\x61\164\x74\x72\137\x6e\141\155\x65\x5f\154\151\x73\x74" . $M9, $bj);
            if (!($pK && '' !== $pK)) {
                goto N7;
            }
            $this->handle_group_test_conf($ET, $Cf, $dK["\x61\x63\143\x65\x73\163\x5f\164\157\x6b\145\156"], false, $pK);
            exit;
            N7:
            goto TG;
            jg:
            MO_Oauth_Debug::mo_oauth_log("\x4f\x70\145\156\111\104\x20\x43\x6f\156\156\x65\143\x74\40\x66\x6c\x6f\167");
            $dK = json_decode($this->oauth_handler->get_token($Cf["\141\143\x63\145\x73\163\x74\157\153\x65\156\165\x72\154"], $nK, $jV, $vN), true);
            $ut = [];
            try {
                $ut = $this->resolve_and_get_oidc_response($dK);
            } catch (\Exception $GD) {
                $Uc->handle_error($GD->getMessage());
                MO_Oauth_Debug::mo_oauth_log("\111\156\166\141\154\151\x64\40\122\x65\163\x70\x6f\x6e\x73\145\40\x72\145\x63\x65\x69\x76\145\x64\x2e");
                do_action("\x6d\157\137\x72\x65\x64\151\162\x65\143\164\137\x74\x6f\x5f\143\165\x73\x74\157\x6d\137\145\x72\162\157\x72\x5f\x70\x61\x67\145");
                wp_die("\x49\x6e\x76\141\154\x69\x64\x20\122\145\163\x70\x6f\156\163\145\x20\162\145\143\145\151\x76\145\x64\x2e");
                exit;
            }
            MO_Oauth_Debug::mo_oauth_log("\x49\x44\40\124\x6f\153\x65\x6e\x20\x72\145\x63\x65\x69\166\145\144\40\x53\x75\x63\x63\x65\163\163\146\x75\154\x6c\171");
            MO_Oauth_Debug::mo_oauth_log("\111\x44\40\124\x6f\x6b\x65\156\x20\75\x3e\40" . $ut);
            $ET = $this->get_resource_owner_from_app($ut, $M9);
            MO_Oauth_Debug::mo_oauth_log("\122\x65\x73\157\165\162\x63\x65\x20\117\x77\156\145\162\40\75\76\x20");
            MO_Oauth_Debug::mo_oauth_log($ET);
            if (!(strpos($IG->get_app_config("\141\x75\164\x68\157\x72\x69\x7a\x65\165\162\154"), "\x74\x77\151\x74\x63\150") !== false)) {
                goto cb;
            }
            $zR = apply_filters("\x6d\x6f\137\164\x73\x6d\x5f\147\145\164\137\165\163\145\x72\137\163\165\x62\x73\143\162\x69\x70\164\x69\157\x6e", $ET["\x73\x75\142"], $Cf["\143\154\151\145\156\x74\137\151\144"], $dK["\x61\x63\x63\x65\163\163\137\164\x6f\x6b\x65\156"]);
            if (!(false !== $zR)) {
                goto wb;
            }
            MO_Oauth_Debug::mo_oauth_log("\x54\167\151\x74\143\150\40\x53\x75\x62\163\x63\162\151\160\164\x69\157\156\40\75\x3e\x20");
            MO_Oauth_Debug::mo_oauth_log($zR);
            $ET["\163\x75\x62\163\x63\x72\x69\160\x74\x69\x6f\x6e"] = $zR;
            wb:
            cb:
            if (!($IG->get_app_config("\141\160\160\x49\144") === "\x6b\x65\171\x63\154\157\x61\x6b")) {
                goto fL;
            }
            $Dg = apply_filters("\x6d\x6f\x5f\153\162\155\x5f\x67\145\x74\137\165\x73\x65\162\x5f\162\x6f\154\145\163", $ET, $dK);
            if (!(false !== $Dg)) {
                goto NI;
            }
            $ET["\x72\x6f\x6c\x65\x73"] = $Dg;
            NI:
            fL:
            $ET = apply_filters("\x6d\157\137\141\x7a\165\x72\x65\142\62\x63\x5f\x67\x65\x74\137\x75\x73\x65\x72\137\147\x72\157\x75\160\137\x69\144\x73", $ET, $Cf);
            $Ko = apply_filters("\x6d\x6f\137\164\x72\x5f\141\146\164\145\x72\137\x70\162\157\x66\x69\x6c\x65\x5f\151\156\x66\x6f\x5f\x65\170\x74\x72\141\x63\164\x69\x6f\x6e\x5f\146\x72\157\155\x5f\164\x6f\x6b\145\156", $ET);
            if (!($Ko != '' && is_array($Ko))) {
                goto hb;
            }
            $ET = array_merge($ET, $Ko);
            hb:
            if (!(isset($Cf["\x73\145\156\x64\x5f\x6e\157\156\x63\x65"]) && $Cf["\163\145\x6e\x64\x5f\x6e\157\156\x63\145"] === 1)) {
                goto w_;
            }
            if (!(isset($ET["\156\157\156\x63\x65"]) && $ET["\156\x6f\156\143\145"] != NULL)) {
                goto D9;
            }
            if ($Uc->get_transient("\155\x6f\x5f\x6f\x61\165\x74\x68\137\x6e\x6f\x6e\x63\145\x5f" . $ET["\x6e\x6f\x6e\x63\x65"])) {
                goto Zp;
            }
            $eC = "\x4e\157\156\143\145\40\166\x65\x72\151\x66\x69\143\141\x74\x69\x6f\x6e\x20\151\x73\x20\146\x61\x69\x6c\x65\x64\56\x20\x50\154\145\141\x73\x65\40\143\x6f\x6e\x74\141\x63\164\40\164\157\x20\171\157\165\x72\40\x61\x64\x6d\x69\x6e\x69\x73\x74\x72\x61\164\157\x72\56";
            $Uc->handle_error($eC);
            MO_Oauth_Debug::mo_oauth_log($eC);
            wp_die($eC);
            goto zy;
            Zp:
            $Uc->delete_transient("\155\x6f\137\157\141\165\164\150\x5f\156\157\156\x63\x65\137" . $ET["\156\x6f\156\x63\145"]);
            zy:
            D9:
            w_:
            $lc = [];
            $bj = $this->dropdownattrmapping('', $ET, $lc);
            $Uc->mo_oauth_client_update_option("\x6d\157\137\x6f\141\x75\164\x68\137\141\x74\164\x72\137\156\x61\x6d\x65\x5f\154\151\163\164" . $M9, $bj);
            if (!($pK && '' !== $pK)) {
                goto Xk;
            }
            $dK["\x72\x65\146\162\x65\163\150\137\164\x6f\x6b\145\156"] = isset($dK["\162\145\x66\162\x65\163\150\x5f\164\157\153\x65\x6e"]) ? $dK["\162\145\x66\x72\145\x73\150\x5f\164\157\x6b\145\156"] : '';
            $_SESSION["\x70\162\x6f\143\157\x72\145\137\x72\x65\146\x72\x65\x73\x68\137\164\157\153\145\x6e"] = $dK["\x72\x65\146\162\145\163\150\137\x74\157\153\145\x6e"];
            $Gk = isset($dK["\x61\x63\143\x65\x73\x73\x5f\164\157\x6b\x65\x6e"]) ? $dK["\141\143\143\x65\163\x73\x5f\164\x6f\153\x65\156"] : '';
            $this->handle_group_test_conf($ET, $Cf, $Gk, false, $pK);
            MO_Oauth_Debug::mo_oauth_log("\x41\x74\x74\162\151\x62\x75\164\x65\x20\x52\145\x63\x65\151\x76\x65\144\40\x53\x75\143\143\145\x73\x73\x66\165\x6c\154\171");
            exit;
            Xk:
            TG:
            if (!(isset($Cf["\147\162\x6f\165\x70\x64\145\164\x61\x69\x6c\x73\x75\x72\x6c"]) && !empty($Cf["\x67\162\157\x75\160\144\145\164\x61\151\154\x73\x75\162\x6c"]))) {
                goto tA;
            }
            $ET = $this->handle_group_user_info($ET, $Cf, $dK["\141\143\143\x65\x73\x73\x5f\x74\157\153\x65\156"]);
            MO_Oauth_Debug::mo_oauth_log("\107\x72\157\x75\160\x20\x44\x65\164\x61\151\154\163\x20\117\x62\164\x61\151\156\x65\144\x20\75\76\40" . $ET);
            tA:
            MO_Oauth_Debug::mo_oauth_log("\x46\x65\164\143\x68\x65\144\x20\162\145\x73\x6f\165\x72\x63\x65\x20\157\167\156\145\162\x20\x3a\x20" . json_encode($ET));
            if (!has_filter("\x77\x6f\157\143\157\x6d\x6d\x65\162\143\x65\x5f\143\x68\145\143\x6b\157\x75\164\137\147\x65\x74\137\x76\141\x6c\165\145")) {
                goto xb;
            }
            $ET["\x61\x70\160\x6e\x61\155\145"] = $M9;
            xb:
            do_action("\x6d\x6f\137\141\x62\162\137\146\x69\x6c\x74\x65\x72\x5f\x6c\x6f\147\x69\x6e", $ET);
            $this->handle_sso($M9, $Cf, $ET, $Q7, $dK);
        } catch (Exception $GD) {
            $Uc->handle_error($GD->getMessage());
            MO_Oauth_Debug::mo_oauth_log($GD->getMessage());
            do_action("\155\157\137\162\x65\144\151\x72\x65\x63\164\137\x74\157\137\143\165\x73\164\x6f\x6d\x5f\145\x72\162\x6f\x72\137\160\x61\x67\145");
            exit(esc_html($GD->getMessage()));
        }
        Fa:
    }
    public function dropdownattrmapping($kg, $pa, $lc)
    {
        global $Uc;
        foreach ($pa as $LG => $Y6) {
            if (is_array($Y6)) {
                goto gQ;
            }
            if (!empty($kg)) {
                goto BF;
            }
            array_push($lc, $LG);
            goto W8;
            BF:
            array_push($lc, $kg . "\56" . $LG);
            W8:
            goto ZG;
            gQ:
            if (empty($kg)) {
                goto Si;
            }
            $kg .= "\56";
            Si:
            $lc = $this->dropdownattrmapping($kg . $LG, $Y6, $lc);
            $kg = rtrim($kg, "\x2e");
            ZG:
            N1:
        }
        FU:
        return $lc;
    }
    public function resolve_and_get_oidc_response($dK = array())
    {
        if (!empty($dK)) {
            goto CR;
        }
        throw new \Exception("\x54\x6f\x6b\145\x6e\40\162\145\x73\x70\157\156\163\x65\x20\151\x73\x20\145\155\x70\164\171", "\151\156\166\x61\154\151\144\x5f\x72\x65\x73\x70\x6f\x6e\x73\145");
        CR:
        global $Uc;
        $Ne = isset($dK["\x69\144\x5f\164\157\153\145\x6e"]) ? $dK["\x69\144\137\164\x6f\153\145\x6e"] : false;
        $k_ = isset($dK["\x61\x63\143\145\x73\163\137\164\x6f\x6b\145\x6e"]) ? $dK["\141\143\143\145\163\163\x5f\164\x6f\153\x65\x6e"] : false;
        $_SESSION["\x70\162\x6f\x63\x6f\162\x65\x5f\x61\143\x63\145\x73\163\137\x74\x6f\x6b\145\x6e"] = isset($k_) ? $k_ : $Ne;
        if (!$Uc->is_valid_jwt($Ne)) {
            goto Mf;
        }
        return $Ne;
        Mf:
        if (!$Uc->is_valid_jwt($k_)) {
            goto fw;
        }
        return $k_;
        fw:
        MO_Oauth_Debug::mo_oauth_log("\x54\157\153\145\x6e\x20\x69\x73\x20\156\157\x74\40\x61\x20\x76\141\154\151\x64\x20\x4a\x57\x54\56");
        throw new \Exception("\124\157\153\x65\156\x20\x69\x73\40\156\x6f\164\40\141\x20\166\141\154\151\144\x20\x4a\x57\124\x2e");
    }
    public function handle_group_test_conf($ET = array(), $Cf = array(), $k_ = '', $qX = false, $pK = false)
    {
        $this->render_test_config_output($ET, false);
    }
    public function testattrmappingconfig($kg, $pa)
    {
        foreach ($pa as $LG => $Y6) {
            if (is_array($Y6) || is_object($Y6)) {
                goto MK;
            }
            echo "\74\x74\x72\76\x3c\164\144\76";
            if (empty($kg)) {
                goto GO;
            }
            echo $kg . "\56";
            GO:
            echo $LG . "\74\x2f\x74\144\76\74\164\144\76" . $Y6 . "\74\x2f\164\x64\x3e\x3c\57\164\162\76";
            goto dN;
            MK:
            if (empty($kg)) {
                goto aa;
            }
            $kg .= "\x2e";
            aa:
            $this->testattrmappingconfig($kg . $LG, $Y6);
            $kg = rtrim($kg, "\x2e");
            dN:
            N3:
        }
        yL:
    }
    public function render_test_config_output($ET, $qX = false)
    {
        MO_Oauth_Debug::mo_oauth_log("\x54\x68\151\x73\40\151\x73\x20\164\x65\x73\164\x20\x63\157\x6e\x66\x69\x67\x75\162\141\x74\x69\x6f\156\40\x66\x6c\x6f\167\40\x3d\x3e\40");
        echo "\x3c\x64\151\166\40\163\164\171\154\x65\x3d\x22\146\x6f\x6e\x74\x2d\146\x61\x6d\151\x6c\x79\72\103\x61\154\151\142\x72\x69\x3b\x70\141\x64\x64\151\156\x67\72\60\40\x33\45\73\x22\76";
        echo "\x3c\163\x74\171\154\145\76\164\141\142\x6c\x65\173\x62\x6f\162\144\145\162\55\143\157\154\x6c\141\x70\163\145\72\x63\x6f\154\154\x61\x70\x73\x65\x3b\175\x74\150\40\173\x62\141\143\x6b\x67\x72\x6f\165\x6e\144\55\143\157\x6c\x6f\162\72\x20\x23\x65\x65\x65\73\x20\164\x65\x78\164\x2d\x61\154\151\x67\x6e\72\40\x63\145\x6e\164\x65\162\x3b\x20\160\141\144\x64\x69\x6e\x67\72\x20\x38\160\170\x3b\40\142\x6f\162\x64\145\162\x2d\167\x69\144\164\150\72\61\160\170\73\40\x62\x6f\162\144\x65\x72\55\163\164\171\154\145\x3a\163\157\154\x69\144\73\40\142\x6f\162\144\145\162\55\143\157\154\x6f\162\72\x23\x32\x31\x32\x31\x32\61\73\x7d\164\x72\72\x6e\164\x68\x2d\143\150\151\154\144\50\x6f\144\144\x29\x20\173\142\x61\143\153\147\162\x6f\165\156\x64\55\143\x6f\x6c\x6f\162\x3a\x20\43\146\x32\146\62\146\x32\73\175\40\x74\x64\173\x70\141\x64\144\151\x6e\x67\x3a\70\x70\170\73\x62\x6f\x72\x64\x65\162\55\167\151\144\x74\150\x3a\x31\160\170\73\x20\x62\157\162\144\x65\162\55\163\x74\x79\x6c\x65\x3a\x73\x6f\154\x69\144\73\40\142\157\162\x64\x65\162\55\143\157\154\157\162\72\x23\62\x31\62\61\x32\61\x3b\175\x3c\57\x73\164\x79\x6c\145\76";
        echo "\74\x68\62\76";
        echo $qX ? "\x47\x72\157\165\160\40\111\x6e\x66\157" : "\x54\145\163\x74\40\103\x6f\x6e\x66\x69\x67\165\x72\141\x74\151\x6f\156";
        echo "\x3c\57\x68\62\76\x3c\164\141\142\x6c\x65\76\74\x74\162\x3e\x3c\x74\x68\76\101\x74\x74\162\x69\x62\x75\164\x65\x20\x4e\141\x6d\x65\74\57\164\x68\x3e\x3c\x74\x68\x3e\101\x74\164\x72\x69\x62\x75\x74\x65\40\x56\x61\154\165\x65\74\57\x74\x68\76\x3c\x2f\x74\x72\x3e";
        $this->testattrmappingconfig('', $ET);
        echo "\x3c\57\x74\141\142\154\145\76";
        if ($qX) {
            goto SF;
        }
        echo "\x3c\x64\151\x76\40\x73\164\171\x6c\x65\x3d\x22\160\x61\144\144\151\156\x67\72\x20\61\60\x70\170\x3b\42\x3e\74\x2f\144\x69\x76\x3e\x3c\x69\156\x70\x75\x74\40\x73\164\x79\x6c\x65\x3d\x22\160\x61\144\144\151\156\x67\x3a\61\45\73\x77\x69\x64\x74\x68\72\x31\x30\60\160\x78\73\x62\x61\143\x6b\x67\162\x6f\165\156\x64\72\x20\43\x30\60\x39\x31\x43\x44\40\156\x6f\x6e\145\x20\162\x65\160\145\141\x74\40\163\143\162\157\x6c\x6c\x20\x30\45\40\60\x25\73\143\x75\162\163\x6f\162\x3a\x20\x70\x6f\x69\156\x74\145\162\x3b\146\157\156\x74\x2d\163\x69\x7a\145\72\61\65\160\170\73\142\x6f\162\x64\145\x72\55\x77\x69\144\x74\150\72\x20\x31\x70\170\73\142\x6f\x72\x64\145\x72\55\163\x74\x79\x6c\145\x3a\x20\x73\x6f\x6c\151\144\73\142\x6f\162\x64\x65\x72\55\162\141\144\151\x75\x73\72\40\63\160\170\73\x77\x68\151\x74\x65\55\163\160\141\143\145\x3a\x20\x6e\157\x77\162\141\160\x3b\142\x6f\170\55\163\x69\172\151\156\147\72\x20\x62\157\162\x64\x65\162\x2d\142\x6f\170\x3b\142\x6f\162\144\145\x72\55\x63\x6f\154\x6f\162\x3a\40\43\x30\x30\67\63\x41\x41\x3b\142\157\x78\55\163\x68\141\x64\x6f\167\72\40\x30\x70\x78\x20\x31\x70\x78\40\x30\160\x78\40\x72\x67\x62\x61\x28\61\62\x30\x2c\x20\x32\60\x30\54\x20\x32\63\60\x2c\x20\x30\56\x36\51\x20\151\x6e\x73\145\x74\x3b\x63\157\154\157\162\72\40\x23\106\106\106\x3b\42\x74\171\160\x65\75\42\142\x75\x74\164\x6f\156\42\40\166\141\154\x75\x65\75\42\104\x6f\x6e\x65\x22\x20\x6f\x6e\x43\154\x69\143\153\75\x22\x73\145\x6c\x66\56\x63\x6c\x6f\163\145\x28\51\73\x22\76\74\57\144\x69\166\76";
        SF:
    }
    public function handle_sso($M9, $Cf, $ET, $Q7, $dK, $xU = false)
    {
        MO_Oauth_Debug::mo_oauth_log("\x53\x53\117\40\150\141\156\144\154\151\156\x67\40\x66\x6c\x6f\167");
        global $Uc;
        if (!(get_class($this) === "\115\157\117\x61\165\x74\x68\x43\154\151\145\x6e\x74\x5c\x4c\x6f\147\151\156\110\x61\156\x64\154\145\x72" && $Uc->check_versi(1))) {
            goto Qw;
        }
        $f5 = new \MoOauthClient\Base\InstanceHelper();
        $nd = $f5->get_login_handler_instance();
        $nd->handle_sso($M9, $Cf, $ET, $Q7, $dK, $xU);
        Qw:
        $fD = isset($Cf["\x6e\141\155\145\x5f\141\164\x74\x72"]) ? $Cf["\156\x61\x6d\145\x5f\x61\164\164\x72"] : '';
        $X9 = isset($Cf["\145\x6d\x61\x69\x6c\x5f\x61\x74\x74\x72"]) ? $Cf["\145\x6d\x61\151\x6c\137\x61\164\x74\x72"] : '';
        $gK = $Uc->getnestedattribute($ET, $X9);
        $Mk = $Uc->getnestedattribute($ET, $fD);
        if (!empty($gK)) {
            goto lG;
        }
        MO_Oauth_Debug::mo_oauth_log("\x45\x6d\x61\x69\x6c\x20\141\144\x64\x72\x65\x73\x73\40\x6e\157\164\x20\x72\145\143\x65\x69\166\145\144\x2e\40\x43\150\x65\x63\153\40\x79\157\x75\x72\x20\101\164\164\x72\x69\x62\165\x74\x65\40\115\x61\160\x70\x69\156\x67\x20\143\157\156\146\151\147\165\162\x61\164\x69\x6f\x6e\56");
        wp_die("\105\x6d\x61\x69\154\x20\141\144\144\x72\145\163\x73\40\x6e\x6f\164\x20\x72\145\x63\145\x69\166\x65\x64\x2e\40\x43\x68\x65\x63\x6b\40\x79\157\165\162\x20\74\x73\x74\x72\x6f\x6e\147\76\101\x74\x74\x72\151\x62\165\164\145\x20\115\141\x70\160\x69\156\x67\x3c\57\163\164\162\157\x6e\147\76\40\143\157\156\x66\x69\147\165\x72\x61\164\x69\157\x6e\x2e");
        lG:
        if (!(false === strpos($gK, "\100"))) {
            goto ul;
        }
        MO_Oauth_Debug::mo_oauth_log("\x4d\141\160\x70\145\144\40\x45\x6d\x61\x69\154\40\141\164\x74\x72\x69\x62\x75\164\x65\40\144\157\x65\163\40\x6e\x6f\164\40\x63\x6f\x6e\x74\x61\151\x6e\40\166\x61\x6c\151\x64\x20\145\x6d\x61\x69\154\56");
        wp_die("\x4d\x61\x70\160\145\144\40\x45\155\x61\151\x6c\40\x61\x74\x74\x72\151\x62\x75\x74\x65\40\x64\157\145\x73\40\x6e\157\164\x20\x63\157\x6e\164\x61\x69\x6e\x20\166\x61\x6c\x69\x64\40\145\x6d\x61\x69\x6c\x2e");
        ul:
        $user = get_user_by("\154\157\x67\x69\156", $gK);
        if ($user) {
            goto ER;
        }
        $user = get_user_by("\145\x6d\141\x69\x6c", $gK);
        ER:
        if ($user) {
            goto Bk;
        }
        $KK = 0;
        if ($Uc->mo_oauth_hbca_xyake()) {
            goto dK;
        }
        $user = $Uc->mo_oauth_hjsguh_kiishuyauh878gs($gK, $Mk);
        goto aj;
        dK:
        if ($Uc->mo_oauth_client_get_option("\x6d\x6f\x5f\x6f\x61\165\x74\150\137\x66\x6c\141\147") !== true) {
            goto LZ;
        }
        $LD = base64_decode("PGRpdiBzdHlsZT0ndGV4dC1hbGlnbjpjZW50ZXI7Jz48Yj5Vc2VyIEFjY291bnQgZG9lcyBub3QgZXhpc3QuPC9iPjwvZGl2Pjxicj48c21hbGw+VGhpcyB2ZXJzaW9uIHN1cHBvcnRzIEF1dG8gQ3JlYXRlIFVzZXIgZmVhdHVyZSB1cHRvIDEwIFVzZXJzLiBQbGVhc2UgdXBncmFkZSB0byB0aGUgaGlnaGVyIHZlcnNpb24gb2YgdGhlIHBsdWdpbiB0byBlbmFibGUgYXV0byBjcmVhdGUgdXNlciBmb3IgdW5saW1pdGVkIHVzZXJzIG9yIGFkZCB1c2VyIG1hbnVhbGx5Ljwvc21hbGw+");
        MO_Oauth_Debug::mo_oauth_log($LD);
        wp_die($LD);
        goto xB;
        LZ:
        $user = $Uc->mo_oauth_jhuyn_jgsukaj($gK, $Mk);
        xB:
        aj:
        goto NC;
        Bk:
        $KK = $user->ID;
        NC:
        if (!$user) {
            goto pG;
        }
        wp_set_current_user($user->ID);
        MO_Oauth_Debug::mo_oauth_log("\125\163\145\x72\x20\x46\157\165\x6e\144");
        $TC = false;
        $TC = apply_filters("\155\x6f\x5f\x72\145\155\145\155\x62\x65\162\137\155\x65", $TC);
        if (!$TC) {
            goto ct;
        }
        MO_Oauth_Debug::mo_oauth_log("\x52\x65\x6d\145\155\x62\x65\162\x20\101\x64\x64\157\x6e\x20\x61\143\164\x69\x76\x61\x74\x65\144");
        ct:
        wp_set_auth_cookie($user->ID, $TC);
        MO_Oauth_Debug::mo_oauth_log("\x55\163\145\x72\x20\143\x6f\157\153\151\145\40\x73\145\x74");
        $user = get_user_by("\111\104", $user->ID);
        do_action("\x77\160\137\154\157\x67\151\x6e", $user->user_login, $user);
        wp_safe_redirect(home_url());
        MO_Oauth_Debug::mo_oauth_log("\125\x73\x65\162\40\x52\145\x64\151\x72\145\x63\164\145\144\x20\x74\157\x20\x68\x6f\x6d\x65\x20\x75\x72\x6c");
        exit;
        pG:
    }
    public function get_resource_owner_from_app($Ne, $io)
    {
        return $this->oauth_handler->get_resource_owner_from_id_token($Ne);
    }
}
