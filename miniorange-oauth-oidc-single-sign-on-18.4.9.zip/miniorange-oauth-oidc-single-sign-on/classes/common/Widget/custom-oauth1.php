<?php


namespace MoOauthClient;

use MoOauthClient\MO_Custom_OAuth1;
use MoOauthClient\MO_Oauth_Debug;
class MO_Custom_OAuth1
{
    public static function mo_oauth1_auth_request($og)
    {
        global $Uc;
        $Cf = $Uc->get_app_by_name($og)->get_app_config();
        $FO = $Cf["\x63\x6c\151\145\x6e\x74\137\x69\x64"];
        $fd = $Cf["\143\154\x69\x65\156\x74\137\163\145\x63\x72\x65\x74"];
        $D2 = $Cf["\141\165\164\150\157\x72\151\172\x65\x75\x72\154"];
        $ra = $Cf["\x72\x65\x71\x75\x65\163\x74\x75\162\154"];
        $nf = $Cf["\x61\143\143\145\163\x73\164\x6f\153\145\156\x75\162\154"];
        $mn = $Cf["\162\x65\163\x6f\x75\x72\143\x65\157\x77\x6e\145\162\144\145\x74\x61\151\154\x73\165\x72\x6c"];
        $Vc = new MO_Custom_OAuth1_Flow($FO, $fd, $ra, $nf, $mn);
        $aL = $Vc->mo_oauth1_get_request_token();
        if (!(strpos($D2, "\77") == false)) {
            goto jG;
        }
        $D2 .= "\77";
        jG:
        $ix = $D2 . "\157\x61\165\164\x68\x5f\x74\x6f\153\145\x6e\75" . $aL;
        if (!($aL == '' || $aL == NULL)) {
            goto FE;
        }
        MO_Oauth_Debug::mo_oauth_log("\105\162\162\157\162\x20\151\156\40\x52\145\161\x75\145\163\164\x20\x54\x6f\x6b\x65\x6e\40\x45\x6e\144\160\x6f\x69\156\x74");
        wp_die("\x45\x72\162\157\162\40\151\156\40\x52\x65\161\x75\145\163\164\x20\x54\x6f\x6b\x65\x6e\x20\105\156\144\x70\157\x69\156\x74\72\40\x49\x6e\x76\141\x6c\151\x64\40\164\x6f\153\145\156\40\x72\145\x63\x65\x69\166\145\144\56\x20\x43\x6f\156\x74\x61\143\164\40\x74\157\x20\x79\x6f\x75\x72\40\141\x64\155\151\155\x69\163\164\162\141\164\157\162\x20\146\157\162\40\155\157\x72\x65\x20\151\156\x66\x6f\x72\155\x61\x74\151\157\156\x2e");
        FE:
        MO_Oauth_Debug::mo_oauth_log("\x52\x65\161\165\x65\x73\x74\40\x54\x6f\x6b\x65\x6e\x20\162\x65\143\145\x69\166\x65\x64\x2e");
        MO_Oauth_Debug::mo_oauth_log("\x52\x65\161\x75\x65\163\164\x20\x54\x6f\153\145\156\x20\75\76\40" . $aL);
        header("\x4c\157\x63\141\x74\151\157\x6e\72" . $ix);
        exit;
    }
    static function mo_oidc1_get_access_token($og)
    {
        $Yh = explode("\x26", $_SERVER["\122\105\121\125\x45\123\x54\x5f\x55\x52\111"]);
        $Ds = explode("\75", $Yh[1]);
        $vD = explode("\75", $Yh[0]);
        $KJ = get_option("\x6d\x6f\x5f\157\141\165\164\150\x5f\141\x70\160\x73\137\154\x69\x73\164");
        $M9 = $og;
        $IG = null;
        foreach ($KJ as $LG => $Ts) {
            if (!($og == $LG)) {
                goto Oj;
            }
            $IG = $Ts;
            goto wM;
            Oj:
            gT:
        }
        wM:
        global $Uc;
        $Cf = $Uc->get_app_by_name($og)->get_app_config();
        $FO = $Cf["\143\154\x69\x65\x6e\x74\x5f\151\144"];
        $fd = $Cf["\x63\x6c\x69\145\156\x74\137\x73\x65\x63\x72\x65\x74"];
        $D2 = $Cf["\141\165\x74\150\157\162\x69\172\x65\x75\x72\x6c"];
        $ra = $Cf["\x72\x65\x71\165\145\163\x74\165\x72\154"];
        $nf = $Cf["\x61\143\x63\x65\x73\163\164\157\153\x65\x6e\x75\x72\154"];
        $mn = $Cf["\x72\145\163\157\x75\x72\143\x65\157\x77\x6e\x65\162\x64\x65\x74\141\151\x6c\163\x75\162\154"];
        $xC = new MO_Custom_OAuth1_Flow($FO, $fd, $ra, $nf, $mn);
        $hn = $xC->mo_oauth1_get_access_token($Ds[1], $vD[1]);
        $qV = explode("\46", $hn);
        $Ii = '';
        $UG = '';
        foreach ($qV as $LG) {
            $wC = explode("\75", $LG);
            if ($wC[0] == "\x6f\x61\165\x74\x68\x5f\x74\157\x6b\x65\x6e") {
                goto hC;
            }
            if (!($wC[0] == "\157\x61\x75\x74\150\137\x74\x6f\x6b\145\x6e\137\163\x65\x63\x72\145\x74")) {
                goto Ap;
            }
            $UG = $wC[1];
            Ap:
            goto Ke;
            hC:
            $Ii = $wC[1];
            Ke:
            b8:
        }
        Jm:
        MO_Oauth_Debug::mo_oauth_log("\x41\143\143\x65\163\x73\x20\x54\157\x6b\145\156\x20\162\145\x63\145\151\166\x65\144\56");
        MO_Oauth_Debug::mo_oauth_log("\x41\143\x63\145\x73\163\x20\x54\157\x6b\x65\x6e\40\x3d\76\x20" . $Ii);
        $wW = new MO_Custom_OAuth1_Flow($FO, $fd, $ra, $nf, $mn);
        $xb = isset($CM[1]) ? $CM[1] : '';
        $ld = isset($GW[1]) ? $GW[1] : '';
        $UD = isset($hM[1]) ? $hM[1] : '';
        $iJ = $wW->mo_oauth1_get_profile_signature($Ii, $UG);
        if (isset($iJ)) {
            goto Du;
        }
        wp_die("\x49\x6e\166\x61\x6c\x69\144\40\x43\157\156\x66\x69\147\165\162\141\164\x69\x6f\x6e\x73\56\x20\120\154\145\141\x73\145\x20\143\x6f\x6e\x74\141\x63\x74\40\164\157\40\x74\x68\145\x20\x61\x64\x6d\x69\x6d\151\x73\x74\x72\141\x74\157\162\40\x66\157\x72\40\155\x6f\x72\x65\x20\x69\156\146\x6f\x72\155\x61\164\x69\157\x6e");
        Du:
        return $iJ;
    }
}
class MO_Custom_OAuth1_Flow
{
    var $key = '';
    var $secret = '';
    var $request_token_url = '';
    var $access_token_url = '';
    var $userinfo_url = '';
    function __construct($Hb, $fd, $ra, $nf, $mn)
    {
        $this->key = $Hb;
        $this->secret = $fd;
        $this->request_token_url = $ra;
        $this->access_token_url = $nf;
        $this->userinfo_url = $mn;
    }
    function mo_oauth1_get_request_token()
    {
        $w0 = array("\x6f\141\x75\164\150\137\x76\145\x72\163\151\157\x6e" => "\61\x2e\x30", "\x6f\141\x75\x74\x68\137\156\x6f\x6e\143\x65" => time(), "\x6f\x61\x75\164\150\x5f\x74\151\155\x65\163\x74\x61\155\160" => time(), "\157\141\x75\164\x68\137\x63\x6f\x6e\163\x75\x6d\x65\x72\137\153\x65\x79" => $this->key, "\157\x61\x75\164\x68\137\x73\x69\x67\156\141\164\165\162\145\137\155\x65\x74\x68\x6f\x64" => "\110\x4d\101\103\55\123\110\x41\61");
        if (!(strpos($this->request_token_url, "\77") != false)) {
            goto hl;
        }
        $lc = explode("\77", $this->request_token_url);
        $this->request_token_url = $lc[0];
        $YF = explode("\46", $lc[1]);
        foreach ($YF as $WM) {
            $Ck = explode("\75", $WM);
            $w0[$Ck[0]] = $Ck[1];
            LM:
        }
        bb:
        hl:
        $St = array_keys($w0);
        $WS = array_values($w0);
        $w0 = $this->mo_oauth1_url_encode_rfc3986(array_combine($St, $WS));
        uksort($w0, "\163\164\162\x63\155\160");
        foreach ($w0 as $gF => $jc) {
            $J0[] = $this->mo_oauth1_url_encode_rfc3986($gF) . "\x3d" . $this->mo_oauth1_url_encode_rfc3986($jc);
            nt:
        }
        yh:
        $O9 = implode("\x26", $J0);
        $xS = $O9;
        $xS = str_replace("\75", "\x25\x33\x44", $xS);
        $xS = str_replace("\46", "\45\x32\66", $xS);
        $xS = "\107\x45\x54\46" . $this->mo_oauth1_url_encode_rfc3986($this->request_token_url) . "\46" . $xS;
        $Ob = $this->mo_oauth1_url_encode_rfc3986($this->secret) . "\46";
        $w0["\x6f\x61\x75\164\x68\137\x73\151\x67\x6e\x61\x74\165\x72\x65"] = $this->mo_oauth1_url_encode_rfc3986(base64_encode(hash_hmac("\x73\x68\141\x31", $xS, $Ob, TRUE)));
        uksort($w0, "\x73\x74\162\143\155\160");
        foreach ($w0 as $gF => $jc) {
            $ck[] = $gF . "\75" . $jc;
            pZ:
        }
        kr:
        $vI = implode("\x26", $ck);
        $yN = $this->request_token_url . "\77" . $vI;
        MO_Oauth_Debug::mo_oauth_log("\122\145\x71\x75\145\163\164\40\x54\x6f\x6b\x65\156\40\125\122\114\40\x3d\x3e\x20" . $yN);
        $mj = $this->mo_oauth1_https($yN);
        MO_Oauth_Debug::mo_oauth_log("\x52\145\161\165\145\163\x74\x20\x54\x6f\x6b\145\x6e\40\x45\x6e\x64\160\157\x69\x6e\x74\40\122\x65\x73\x70\x6f\x6e\x73\145\40\x3d\x3e\x20");
        MO_Oauth_Debug::mo_oauth_log($mj);
        $BL = explode("\46", $mj);
        $ej = '';
        foreach ($BL as $LG) {
            $wC = explode("\x3d", $LG);
            if ($wC[0] == "\x6f\x61\x75\x74\150\x5f\x74\x6f\x6b\x65\x6e") {
                goto XZ;
            }
            if (!($wC[0] == "\157\141\x75\x74\150\137\164\157\x6b\145\x6e\137\x73\145\143\162\x65\x74")) {
                goto xQ;
            }
            setcookie("\155\x6f\137\164\163", $wC[1], time() + 30);
            xQ:
            goto d5;
            XZ:
            $ej = $wC[1];
            d5:
            Nj:
        }
        yV:
        return $ej;
    }
    function mo_oauth1_get_access_token($Ds, $vD)
    {
        $w0 = array("\x6f\141\165\x74\150\x5f\166\145\x72\x73\151\x6f\156" => "\61\56\60", "\x6f\141\165\x74\150\x5f\156\157\x6e\143\145" => time(), "\157\141\x75\x74\x68\137\x74\151\155\145\x73\164\x61\x6d\160" => time(), "\x6f\x61\x75\164\x68\137\x63\157\x6e\163\x75\x6d\145\162\137\x6b\x65\x79" => $this->key, "\x6f\x61\165\164\x68\137\x74\x6f\x6b\145\x6e" => $vD, "\157\x61\x75\x74\150\137\x73\151\147\x6e\x61\164\165\162\x65\x5f\155\x65\164\x68\x6f\x64" => "\110\x4d\101\103\55\x53\x48\x41\x31", "\157\x61\x75\164\x68\x5f\x76\145\162\151\x66\151\x65\x72" => $Ds);
        $St = $this->mo_oauth1_url_encode_rfc3986(array_keys($w0));
        $WS = $this->mo_oauth1_url_encode_rfc3986(array_values($w0));
        $w0 = array_combine($St, $WS);
        uksort($w0, "\x73\x74\162\143\155\160");
        foreach ($w0 as $gF => $jc) {
            $J0[] = $this->mo_oauth1_url_encode_rfc3986($gF) . "\75" . $this->mo_oauth1_url_encode_rfc3986($jc);
            dS:
        }
        KI:
        $O9 = implode("\x26", $J0);
        $xS = $O9;
        $xS = str_replace("\x3d", "\45\63\x44", $xS);
        $xS = str_replace("\x26", "\45\x32\x36", $xS);
        $xS = "\x47\105\124\x26" . $this->mo_oauth1_url_encode_rfc3986($this->access_token_url) . "\x26" . $xS;
        $R7 = isset($_COOKIE["\155\x6f\x5f\x74\163"]) ? $_COOKIE["\x6d\157\x5f\164\x73"] : '';
        $Ob = $this->mo_oauth1_url_encode_rfc3986($this->secret) . "\x26" . $R7;
        $w0["\157\x61\x75\164\x68\x5f\x73\151\x67\x6e\141\x74\165\x72\x65"] = $this->mo_oauth1_url_encode_rfc3986(base64_encode(hash_hmac("\x73\x68\x61\61", $xS, $Ob, TRUE)));
        uksort($w0, "\163\x74\162\143\x6d\x70");
        foreach ($w0 as $gF => $jc) {
            $ck[] = $gF . "\x3d" . $jc;
            iO:
        }
        ja:
        $vI = implode("\46", $ck);
        $yN = $this->access_token_url . "\77" . $vI;
        MO_Oauth_Debug::mo_oauth_log("\x41\x63\x63\x65\x73\163\40\124\x6f\153\145\156\40\x45\x6e\x64\x70\157\151\156\164\x20\x55\122\x4c\x20\75\76\40" . $yN);
        $mj = $this->mo_oauth1_https($yN);
        MO_Oauth_Debug::mo_oauth_log("\x41\x63\x63\145\x73\x73\x20\x54\x6f\x6b\145\x6e\x20\105\x6e\x64\x70\x6f\x69\x6e\164\x20\122\145\163\160\157\x6e\163\145\40\x3d\76\40" . $mj);
        return $mj;
    }
    function mo_oauth1_get_profile_signature($hn, $GW, $hM = '')
    {
        $w0 = array("\157\141\165\x74\x68\137\166\x65\x72\163\x69\157\156" => "\x31\x2e\60", "\157\141\165\164\x68\137\156\x6f\x6e\x63\x65" => time(), "\x6f\x61\165\164\150\x5f\164\151\x6d\145\163\x74\x61\x6d\x70" => time(), "\x6f\141\165\x74\150\137\x63\x6f\156\x73\x75\155\x65\x72\x5f\153\145\171" => $this->key, "\157\x61\x75\x74\x68\137\x74\x6f\153\x65\156" => $hn, "\x6f\141\x75\x74\x68\x5f\163\151\147\156\x61\164\x75\162\145\137\x6d\x65\x74\150\157\144" => "\x48\115\101\x43\x2d\x53\110\x41\61");
        if (!(strpos($this->userinfo_url, "\x3f") != false)) {
            goto H6;
        }
        $lc = explode("\x3f", $this->userinfo_url);
        $this->userinfo_url = $lc[0];
        $YF = explode("\x26", $lc[1]);
        foreach ($YF as $WM) {
            $Ck = explode("\75", $WM);
            $w0[$Ck[0]] = $Ck[1];
            Bz:
        }
        g9:
        H6:
        $St = $this->mo_oauth1_url_encode_rfc3986(array_keys($w0));
        $WS = $this->mo_oauth1_url_encode_rfc3986(array_values($w0));
        $w0 = array_combine($St, $WS);
        uksort($w0, "\163\x74\x72\143\155\x70");
        foreach ($w0 as $gF => $jc) {
            $J0[] = $this->mo_oauth1_url_encode_rfc3986($gF) . "\x3d" . $this->mo_oauth1_url_encode_rfc3986($jc);
            xO:
        }
        B9:
        $O9 = implode("\46", $J0);
        $xS = "\107\105\x54\x26" . $this->mo_oauth1_url_encode_rfc3986($this->userinfo_url) . "\x26" . $this->mo_oauth1_url_encode_rfc3986($O9);
        $Ob = $this->mo_oauth1_url_encode_rfc3986($this->secret) . "\46" . $this->mo_oauth1_url_encode_rfc3986($GW);
        $w0["\157\x61\165\164\x68\x5f\x73\x69\147\x6e\x61\164\x75\x72\145"] = $this->mo_oauth1_url_encode_rfc3986(base64_encode(hash_hmac("\163\150\x61\61", $xS, $Ob, TRUE)));
        uksort($w0, "\163\x74\162\x63\155\160");
        foreach ($w0 as $gF => $jc) {
            $ck[] = $gF . "\75" . $jc;
            XK:
        }
        HK:
        $vI = implode("\46", $ck);
        $yN = $this->userinfo_url . "\x3f" . $vI;
        MO_Oauth_Debug::mo_oauth_log("\x52\145\163\x6f\165\162\143\145\40\x45\x6e\x64\160\157\x69\156\x74\x20\125\122\114\40\x3d\x3e\x20" . $yN);
        $nK = array();
        MO_Oauth_Debug::mo_oauth_log("\x52\145\163\157\165\162\143\145\x20\x45\156\144\x70\157\151\x6e\164\x20\151\156\x66\x6f\x20\x3d\x3e\x20");
        MO_Oauth_Debug::mo_oauth_log($w0);
        $xY = wp_remote_get($yN, $nK);
        MO_Oauth_Debug::mo_oauth_log("\x52\145\x73\157\165\x72\x63\145\x20\105\x6e\144\160\x6f\x69\156\164\x20\122\x65\x73\160\x6f\156\x73\x65\40\x3d\x3e\40");
        MO_Oauth_Debug::mo_oauth_log($xY);
        $iJ = json_decode($xY["\142\x6f\144\x79"], true);
        return $iJ;
    }
    function mo_oauth1_https($yN, $QR = null)
    {
        if (!isset($QR)) {
            goto cU;
        }
        $nK = array("\155\x65\164\150\x6f\144" => "\x50\117\x53\x54", "\x62\x6f\144\x79" => $QR, "\x74\151\155\x65\157\165\164" => "\61\x35", "\162\145\144\x69\162\145\x63\x74\x69\157\x6e" => "\x35", "\x68\164\164\x70\x76\145\162\163\x69\x6f\156" => "\x31\56\x30", "\142\x6c\157\143\x6b\151\x6e\147" => true);
        MO_Oauth_Debug::mo_oauth_log("\x4f\x61\x75\164\150\61\x20\120\x4f\x53\124\40\x45\156\144\x70\x6f\x69\156\x74\40\x41\162\147\x75\155\145\156\164\163\x20\x3d\76\x20");
        MO_Oauth_Debug::mo_oauth_log($xY);
        $Oo = wp_remote_post($yN, $nK);
        return $Oo["\x62\157\144\x79"];
        cU:
        $nK = array();
        $xY = wp_remote_get($yN, $nK);
        if (!is_wp_error($xY)) {
            goto vP;
        }
        wp_die($xY);
        vP:
        $mj = $xY["\142\x6f\144\x79"];
        return $mj;
    }
    function mo_oauth1_url_encode_rfc3986($TO)
    {
        if (is_array($TO)) {
            goto QH;
        }
        if (is_scalar($TO)) {
            goto XX;
        }
        return '';
        goto k4;
        XX:
        return str_replace("\53", "\x20", str_replace("\x25\x37\105", "\x7e", rawurlencode($TO)));
        k4:
        goto gL;
        QH:
        return array_map(array("\115\157\x4f\141\x75\x74\150\x43\154\x69\145\156\x74\x5c\x4d\x4f\137\x43\165\163\164\x6f\x6d\137\x4f\101\165\164\x68\x31\137\106\x6c\157\167", "\x6d\157\x5f\x6f\x61\x75\x74\x68\61\x5f\x75\162\154\137\145\x6e\143\157\144\145\x5f\x72\x66\x63\63\71\x38\66"), $TO);
        gL:
    }
}
