<?php


namespace MoOauthClient\Backup;

use MoOauthClient\App;
use MoOauthClient\Config;
class BackupHandler
{
    private $plugin_config;
    private $apps_list;
    public static function restore_settings($SF = '')
    {
        if (!(!is_array($SF) || empty($SF))) {
            goto RO;
        }
        return false;
        RO:
        $XN = false;
        $Ig = isset($SF["\x70\x6c\165\x67\151\x6e\x5f\143\x6f\156\x66\x69\147"]) ? $SF["\x70\154\x75\147\x69\x6e\x5f\143\x6f\156\146\151\x67"] : false;
        $sl = isset($SF["\x61\160\160\x5f\x63\x6f\156\x66\151\x67\163"]) ? $SF["\x61\160\160\x5f\x63\x6f\156\x66\x69\147\x73"] : false;
        if (!$Ig) {
            goto II;
        }
        $XN = self::restore_plugin_config($Ig);
        II:
        if (!$sl) {
            goto me;
        }
        return $XN && self::restore_apps_config($sl);
        me:
        return false;
    }
    private static function restore_plugin_config($Ig)
    {
        global $Uc;
        if (!empty($Ig)) {
            goto Wg;
        }
        return false;
        Wg:
        $K9 = new Config($Ig);
        if (empty($K9)) {
            goto YL;
        }
        $Uc->mo_oauth_client_update_option("\x6d\x6f\137\x6f\141\x75\164\x68\137\x63\154\151\x65\x6e\x74\137\143\x6f\x6e\x66\x69\x67", $K9);
        return true;
        YL:
        return false;
    }
    private static function restore_apps_config($sl)
    {
        global $Uc;
        if (!(!is_array($sl) && empty($sl))) {
            goto TK;
        }
        return false;
        TK:
        $hU = [];
        foreach ($sl as $io => $Cf) {
            $Ts = new App($Cf);
            $Ts->set_app_name($io);
            $hU[$io] = $Ts;
            Qe:
        }
        Kw:
        $Uc->mo_oauth_client_update_option("\x6d\157\x5f\x6f\x61\165\x74\x68\x5f\141\160\x70\163\x5f\x6c\151\163\164", $hU);
        return true;
    }
    public static function get_backup_json()
    {
        global $Uc;
        $kE = $Uc->export_plugin_config();
        return json_encode($kE, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    }
}
