<?php


namespace MoOauthClient\Backup;

use MoOauthClient\App;
class EnvVarResolver
{
    public static function resolve_var($LG, $C0)
    {
        switch ($LG) {
            case "\155\157\x5f\157\141\x75\164\x68\x5f\x61\x70\x70\x73\137\x6c\x69\163\164":
                $C0 = self::resolve_apps_list($C0);
                goto Cv;
            default:
                goto Cv;
        }
        GK:
        Cv:
        return $C0;
    }
    private static function resolve_apps_list($C0)
    {
        if (!is_array($C0)) {
            goto BI;
        }
        return $C0;
        BI:
        $C0 = json_decode($C0, true);
        if (!(json_last_error() !== JSON_ERROR_NONE)) {
            goto Vj;
        }
        return [];
        Vj:
        $Ih = [];
        foreach ($C0 as $io => $Cf) {
            if (!$Cf instanceof App) {
                goto B8;
            }
            $Ih[$io] = $Cf;
            goto OO;
            B8:
            if (!(!isset($Cf["\x63\154\151\x65\x6e\164\x5f\x69\144"]) || empty($Cf["\143\154\x69\x65\156\164\137\151\144"]))) {
                goto Rx;
            }
            $Cf["\x63\x6c\151\x65\x6e\164\x5f\x69\144"] = isset($Cf["\x63\x6c\x69\145\x6e\x74\x69\144"]) ? $Cf["\143\x6c\x69\x65\156\164\151\x64"] : '';
            Rx:
            if (!(!isset($Cf["\143\x6c\x69\145\x6e\164\x5f\x73\x65\x63\x72\x65\x74"]) || empty($Cf["\143\154\x69\x65\156\x74\x5f\163\x65\143\x72\x65\164"]))) {
                goto t5;
            }
            $Cf["\x63\x6c\x69\145\156\164\x5f\163\145\x63\162\x65\x74"] = isset($Cf["\x63\154\x69\x65\156\164\x73\145\143\162\x65\164"]) ? $Cf["\143\154\151\x65\x6e\x74\163\x65\x63\162\145\x74"] : '';
            t5:
            unset($Cf["\143\154\x69\145\156\x74\x69\x64"]);
            unset($Cf["\143\154\x69\145\156\164\x73\x65\143\162\x65\164"]);
            $Ts = new App();
            $Ts->migrate_app($Cf, $io);
            $Ih[$io] = $Ts;
            OO:
        }
        Kz:
        return $Ih;
    }
}
