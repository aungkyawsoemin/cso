<?php


namespace MoOauthClient\Config;

interface ConfigInterface
{
    public function get_current_config();
}
