<?php


namespace MoOauthClient\Base;

use MoOauthClient\Licensing;
use MoOauthClient\MoAddons;
use MoOauthClient\Base\InstanceHelper;
class Loader
{
    private $instance_helper;
    public function __construct()
    {
        add_action("\141\144\x6d\151\156\137\145\156\x71\x75\145\165\145\137\x73\143\162\151\160\x74\163", array($this, "\160\x6c\x75\147\151\x6e\137\x73\x65\x74\164\x69\x6e\x67\x73\x5f\163\x74\x79\x6c\x65"));
        add_action("\x61\144\155\x69\156\x5f\x65\x6e\x71\165\x65\165\x65\137\x73\x63\x72\151\x70\164\x73", array($this, "\x70\x6c\x75\147\x69\x6e\x5f\163\145\x74\x74\x69\x6e\x67\163\x5f\163\143\162\x69\160\164"));
        $this->instance_helper = new InstanceHelper();
    }
    public function plugin_settings_style()
    {
        wp_enqueue_style("\x6d\157\137\157\141\165\x74\x68\x5f\x61\x64\x6d\151\x6e\137\163\145\164\164\x69\156\147\x73\137\163\x74\x79\154\145", MOC_URL . "\x72\x65\163\x6f\165\x72\143\145\163\x2f\143\163\x73\57\x73\164\x79\154\145\x5f\163\x65\x74\x74\151\x6e\x67\x73\x2e\143\x73\x73", array(), $YG = null, $gS = false);
        wp_enqueue_style("\x6d\157\x5f\157\x61\165\x74\x68\x5f\x61\x64\x6d\151\x6e\x5f\163\145\164\164\151\156\147\163\137\x70\x68\x6f\156\145\x5f\x73\164\171\x6c\x65", MOC_URL . "\162\x65\x73\x6f\165\162\143\x65\x73\x2f\x63\x73\163\57\x70\150\157\x6e\145\x2e\x63\x73\163", array(), $YG = null, $gS = false);
        wp_enqueue_style("\155\x6f\x5f\157\141\165\x74\x68\x5f\x61\x64\155\151\156\x5f\163\x65\164\164\x69\x6e\147\163\x5f\x64\141\x74\141\x74\141\x62\x6c\x65", MOC_URL . "\x72\145\x73\157\165\x72\x63\145\163\x2f\143\163\163\57\152\161\165\x65\x72\171\56\144\x61\x74\141\124\141\x62\154\145\163\56\155\x69\156\x2e\x63\x73\x73", array(), $YG = null, $gS = false);
        wp_enqueue_style("\x6d\x6f\x2d\167\160\x2d\142\x6f\157\x74\x73\x74\x72\141\x70\x2d\x73\x6f\143\151\x61\x6c", MOC_URL . "\x72\x65\x73\x6f\165\162\x63\145\163\57\x63\163\x73\x2f\x62\x6f\x6f\x74\x73\164\162\141\x70\x2d\x73\x6f\143\151\x61\154\x2e\x63\x73\x73", array(), $YG = null, $gS = false);
        wp_enqueue_style("\x6d\x6f\55\167\160\x2d\x62\157\157\164\x73\164\x72\141\160\55\x6d\141\151\x6e", MOC_URL . "\x72\x65\163\157\165\x72\143\x65\163\57\x63\163\163\57\142\157\157\x74\x73\164\x72\141\160\x2e\x6d\151\156\x2d\x70\162\145\x76\151\145\x77\56\x63\x73\x73", array(), $YG = null, $gS = false);
        wp_enqueue_style("\155\x6f\x2d\x77\x70\x2d\146\x6f\x6e\164\x2d\141\167\145\163\157\155\145", MOC_URL . "\x72\145\x73\x6f\165\x72\x63\145\163\x2f\x63\x73\x73\57\x66\157\156\164\x2d\141\167\x65\x73\157\x6d\145\x2e\x6d\151\156\56\143\x73\x73\x3f\166\x65\162\x73\151\x6f\156\75\64\x2e\70", array(), $YG = null, $gS = false);
        wp_enqueue_style("\155\x6f\x2d\x77\160\55\146\157\x6e\164\55\141\167\x65\163\157\155\145", MOC_URL . "\x72\x65\x73\157\x75\x72\143\145\163\x2f\143\x73\163\57\146\157\156\164\55\141\167\145\163\x6f\x6d\145\56\143\x73\x73\x3f\x76\145\x72\x73\151\x6f\156\75\x34\56\70", array(), $YG = null, $gS = false);
        if (!(isset($_REQUEST["\164\141\142"]) && "\154\x69\143\145\x6e\x73\151\156\x67" === $_REQUEST["\164\x61\142"])) {
            goto M0;
        }
        wp_enqueue_style("\155\x6f\137\x6f\x61\x75\x74\150\x5f\x62\x6f\157\x74\163\164\x72\141\x70\x5f\143\x73\x73", MOC_URL . "\x72\145\x73\x6f\x75\x72\x63\145\x73\x2f\143\x73\x73\57\142\157\157\x74\x73\x74\x72\141\x70\x2f\x62\x6f\x6f\x74\x73\x74\162\x61\x70\x2e\x6d\151\x6e\x2e\143\x73\x73", array(), $YG = null, $gS = false);
        wp_enqueue_style("\x6d\x6f\137\157\141\x75\164\150\137\154\x69\143\145\x6e\163\145\137\x70\141\147\145\x5f\x73\x74\x79\154\x65", MOC_URL . "\162\x65\x73\157\165\x72\x63\x65\x73\x2f\143\x73\x73\x2f\x6d\x6f\x2d\157\141\165\x74\150\55\154\x69\143\x65\156\x73\151\156\147\x2e\143\x73\163");
        M0:
    }
    public function plugin_settings_script()
    {
        wp_enqueue_script("\155\x6f\137\157\141\165\164\150\x5f\141\144\155\x69\156\137\163\x65\164\164\151\156\147\x73\x5f\163\143\162\151\160\x74", MOC_URL . "\162\145\x73\157\165\162\143\x65\x73\x2f\x6a\x73\57\x73\x65\x74\164\151\x6e\x67\163\x2e\152\163", array(), $YG = null, $gS = false);
        wp_enqueue_script("\155\x6f\x5f\157\x61\165\164\150\137\x61\x64\155\x69\x6e\x5f\x73\x65\164\x74\151\x6e\147\x73\x5f\160\x68\x6f\x6e\x65\137\163\x63\162\151\160\164", MOC_URL . "\x72\145\163\157\x75\x72\x63\145\163\x2f\x6a\x73\57\x70\x68\x6f\x6e\145\56\x6a\163", array(), $YG = null, $gS = false);
        wp_enqueue_script("\155\x6f\137\x6f\x61\165\x74\150\137\x61\x64\155\x69\156\x5f\163\145\164\x74\151\156\x67\163\x5f\x64\x61\x74\x61\x74\141\142\x6c\x65", MOC_URL . "\x72\145\x73\157\165\162\x63\x65\x73\x2f\x6a\163\57\152\x71\x75\145\162\171\x2e\144\x61\164\x61\124\x61\142\x6c\x65\x73\x2e\155\151\156\56\x6a\x73", array(), $YG = null, $gS = false);
        if (!(isset($_REQUEST["\164\x61\x62"]) && "\154\151\x63\145\x6e\163\151\x6e\x67" === $_REQUEST["\164\141\x62"])) {
            goto Tu;
        }
        wp_enqueue_script("\155\x6f\x5f\157\x61\x75\x74\x68\137\x6d\157\144\145\x72\156\151\x7a\162\x5f\x73\143\162\x69\x70\x74", MOC_URL . "\x72\145\163\157\x75\x72\x63\x65\x73\x2f\x6a\163\57\155\157\144\x65\x72\156\151\172\x72\56\152\163", array(), $YG = null, $gS = true);
        wp_enqueue_script("\155\x6f\137\157\141\x75\x74\150\137\x70\157\x70\157\166\145\162\137\x73\x63\162\151\x70\x74", MOC_URL . "\162\145\x73\157\x75\x72\143\145\x73\57\152\x73\x2f\142\157\157\x74\x73\164\x72\141\x70\57\160\157\x70\x70\145\x72\56\x6d\x69\156\x2e\152\163", array(), $YG = null, $gS = true);
        wp_enqueue_script("\155\157\x5f\x6f\141\165\164\150\137\142\157\157\x74\163\164\x72\x61\160\137\163\x63\x72\151\160\x74", MOC_URL . "\x72\x65\x73\157\165\162\143\145\163\x2f\x6a\163\57\142\157\157\x74\163\x74\x72\141\x70\57\142\x6f\x6f\164\x73\x74\x72\141\160\56\155\151\x6e\56\152\163", array(), $YG = null, $gS = true);
        Tu:
    }
    public function load_current_tab($hH)
    {
        global $Uc;
        $b4 = 0 === $Uc->get_versi();
        $VA = false;
        if ($b4) {
            goto Yl;
        }
        $VA = $Uc->mo_oauth_client_get_option("\x6d\x6f\x5f\x6f\x61\x75\164\150\137\143\x6c\x69\145\156\x74\137\154\157\141\144\x5f\141\x6e\141\x6c\x79\164\x69\143\x73");
        $VA = boolval($VA) ? boolval($VA) : false;
        $b4 = $Uc->check_versi(1) && $Uc->mo_oauth_is_clv();
        Yl:
        if ("\141\x63\x63\157\165\x6e\164" === $hH || !$b4) {
            goto AR;
        }
        if ("\x63\x75\163\164\157\x6d\151\x7a\x61\x74\151\x6f\156" === $hH && $b4) {
            goto SE;
        }
        if ("\163\151\147\x6e\151\156\x73\x65\164\164\x69\156\x67\163" === $hH && $b4) {
            goto C8;
        }
        if ("\x73\x75\142\x73\151\164\145\x73\145\x74\164\151\156\147\163" === $hH && $b4) {
            goto o3;
        }
        if ($VA && "\141\x6e\x61\x6c\x79\x74\x69\143\163" === $hH && $b4) {
            goto hF;
        }
        if ("\154\x69\143\145\x6e\x73\x69\156\147" === $hH) {
            goto F7;
        }
        if ("\162\x65\x71\165\145\163\x74\146\x6f\x72\x64\145\155\x6f" === $hH && $b4) {
            goto SD;
        }
        if ("\141\x64\144\157\x6e\163" === $hH) {
            goto C2;
        }
        $this->instance_helper->get_clientappui_instance()->render_free_ui();
        goto pH;
        AR:
        $CZ = $this->instance_helper->get_accounts_instance();
        if ($Uc->mo_oauth_client_get_option("\x76\x65\x72\151\x66\171\x5f\143\165\x73\164\157\155\145\162") === "\x74\x72\x75\145") {
            goto wG;
        }
        if (trim($Uc->mo_oauth_client_get_option("\x6d\157\x5f\x6f\141\165\164\x68\137\141\144\155\x69\156\137\x65\155\141\151\154")) !== '' && trim($Uc->mo_oauth_client_get_option("\155\157\137\x6f\141\x75\x74\150\x5f\x61\x64\x6d\151\x6e\x5f\x61\160\x69\137\153\145\171")) === '' && $Uc->mo_oauth_client_get_option("\156\145\167\137\x72\x65\x67\x69\163\164\162\x61\164\151\x6f\x6e") !== "\x74\x72\x75\145") {
            goto G3;
        }
        if (!$Uc->mo_oauth_is_clv() && $Uc->check_versi(1) && $Uc->mo_oauth_is_customer_registered()) {
            goto aB;
        }
        $CZ->register();
        goto rZ;
        wG:
        $CZ->verify_password_ui();
        goto rZ;
        G3:
        $CZ->verify_password_ui();
        goto rZ;
        aB:
        $CZ->mo_oauth_lp();
        rZ:
        goto pH;
        SE:
        $this->instance_helper->get_customization_instance()->render_free_ui();
        goto pH;
        C8:
        $this->instance_helper->get_sign_in_settings_instance()->render_free_ui();
        goto pH;
        o3:
        $this->instance_helper->get_subsite_settings()->render_ui();
        goto pH;
        hF:
        $this->instance_helper->get_user_analytics()->render_ui();
        goto pH;
        F7:
        (new Licensing())->show_licensing_page();
        goto pH;
        SD:
        $this->instance_helper->get_requestdemo_instance()->render_free_ui();
        goto pH;
        C2:
        (new MoAddons())->addons_page();
        pH:
    }
}
