<?php


namespace MoOauthClient;

use MoOauthClient\Backup\BackupHandler;
use MoOauthClient\mc_utils;
use MoOauthClient\Customer;
use MoOauthClient\Config;
class Settings
{
    public $config;
    public $util;
    public function __construct()
    {
        global $Uc;
        $this->util = $Uc;
        add_action("\x61\x64\155\x69\156\x5f\x69\156\151\x74", array($this, "\x6d\151\x6e\151\157\x72\x61\x6e\147\145\x5f\157\141\165\x74\x68\137\x73\x61\x76\145\137\163\x65\x74\x74\151\x6e\x67\x73"));
        add_shortcode("\155\157\x5f\x6f\141\165\164\150\137\154\157\147\x69\x6e", array($this, "\155\157\x5f\157\x61\x75\x74\150\x5f\163\x68\157\x72\164\x63\157\x64\x65\x5f\x6c\157\147\151\156"));
        add_action("\x61\144\155\x69\x6e\x5f\x69\156\151\164", array($this, "\155\157\x5f\157\141\x75\x74\150\137\144\x65\x62\x75\147\x5f\x6c\157\x67\x5f\141\x6a\x61\170\x5f\150\x6f\157\x6b"));
        $this->config = $this->util->get_plugin_config();
    }
    function mo_oauth_debug_log_ajax_hook()
    {
        add_action("\x77\x70\x5f\141\x6a\141\x78\137\x6d\x6f\x5f\x6f\x61\x75\164\x68\137\144\145\142\165\x67\137\x61\x6a\x61\x78", array($this, "\x6d\157\137\157\x61\x75\164\150\x5f\144\x65\x62\165\x67\137\x6c\157\147\137\x61\x6a\x61\170"));
    }
    function mo_oauth_debug_log_ajax()
    {
        if (!isset($_POST["\155\x6f\137\157\x61\165\164\150\x5f\x6e\x6f\x6e\143\x65"]) || !wp_verify_nonce(sanitize_text_field($_POST["\155\157\137\157\141\165\x74\150\x5f\x6e\157\156\143\145"]), "\155\157\55\x6f\x61\x75\164\150\55\104\x65\x62\165\147\55\x6c\157\x67\x73\x2d\x75\x6e\151\x71\x75\x65\x2d\163\x74\x72\x69\x6e\147\x2d\156\x6f\x6e\143\x65")) {
            goto wR;
        }
        switch (sanitize_text_field($_POST["\x6d\x6f\x5f\x6f\x61\165\164\x68\137\157\160\164\x69\x6f\x6e"])) {
            case "\155\157\x5f\x6f\141\165\x74\x68\x5f\162\x65\163\x65\x74\137\x64\145\x62\x75\147":
                $this->mo_oauth_reset_debug();
                goto uS;
        }
        sH:
        uS:
        goto FL;
        wR:
        wp_send_json("\145\x72\162\157\162");
        FL:
    }
    public function mo_oauth_reset_debug()
    {
        global $Uc;
        if (isset($_POST["\155\157\x5f\x6f\141\x75\x74\x68\x5f\x6f\x70\164\x69\157\156"]) and sanitize_text_field(wp_unslash($_POST["\x6d\157\x5f\157\141\165\x74\150\137\x6f\160\164\151\157\x6e"])) == "\x6d\x6f\x5f\x6f\141\165\164\x68\137\x72\x65\163\x65\164\x5f\144\x65\142\x75\147" && isset($_REQUEST["\155\157\137\157\x61\x75\x74\150\137\156\157\x6e\x63\145"]) && wp_verify_nonce(sanitize_text_field(wp_unslash($_REQUEST["\x6d\x6f\137\x6f\x61\165\164\150\137\156\157\x6e\143\145"])), "\x6d\x6f\55\x6f\x61\165\164\150\x2d\x44\x65\x62\x75\147\x2d\x6c\157\x67\163\55\x75\x6e\151\x71\165\145\x2d\163\x74\x72\x69\156\147\x2d\x6e\x6f\156\x63\x65")) {
            goto sm;
        }
        echo "\x65\162\x72\x6f\162";
        goto OI;
        sm:
        $Ry = false;
        if (!isset($_POST["\155\157\x5f\157\x61\165\x74\150\137\155\157\x5f\157\x61\165\164\150\137\x64\x65\x62\x75\147\x5f\x63\150\145\x63\x6b"])) {
            goto kQ;
        }
        $Ry = sanitize_text_field($_POST["\155\x6f\x5f\157\x61\x75\x74\x68\x5f\x6d\x6f\x5f\157\x61\165\x74\x68\x5f\144\x65\142\165\147\x5f\x63\150\x65\x63\x6b"]);
        kQ:
        $h1 = current_time("\x74\151\x6d\x65\x73\164\x61\155\x70");
        $Uc->mo_oauth_client_update_option("\155\157\137\x64\x65\x62\x75\x67\x5f\x65\156\x61\142\154\x65", $Ry);
        if (!$Uc->mo_oauth_client_get_option("\x6d\157\137\x64\x65\x62\165\147\x5f\145\156\x61\142\154\x65")) {
            goto on;
        }
        $Uc->mo_oauth_client_update_option("\155\x6f\137\144\145\142\x75\147\x5f\143\150\145\143\153", 1);
        $Uc->mo_oauth_client_update_option("\x6d\157\x5f\x64\145\x62\165\x67\x5f\164\x69\155\x65", $h1);
        on:
        if (!$Uc->mo_oauth_client_get_option("\155\157\137\x64\x65\x62\165\147\137\145\156\x61\142\154\145")) {
            goto QO;
        }
        $Uc->mo_oauth_client_update_option("\155\x6f\137\157\x61\165\x74\x68\137\x64\x65\x62\x75\x67", "\x6d\x6f\137\x6f\141\x75\164\x68\x5f\144\x65\x62\165\147" . uniqid());
        $fz = $Uc->mo_oauth_client_get_option("\155\x6f\x5f\157\141\x75\164\x68\137\144\x65\142\165\147");
        $QH = dirname(__DIR__) . DIRECTORY_SEPARATOR . "\x4f\x41\165\x74\150\110\141\x6e\144\x6c\x65\x72" . DIRECTORY_SEPARATOR . $fz . "\x2e\154\x6f\147";
        $P_ = fopen($QH, "\x77");
        chmod($QH, 0644);
        $Uc->mo_oauth_client_update_option("\155\x6f\x5f\x64\145\x62\x75\147\137\x63\x68\x65\143\x6b", 1);
        MO_Oauth_Debug::mo_oauth_log('');
        $Uc->mo_oauth_client_update_option("\155\157\x5f\144\145\x62\x75\147\x5f\x63\x68\x65\x63\x6b", 0);
        QO:
        $Cy = $Uc->mo_oauth_client_get_option("\155\x6f\x5f\x64\145\x62\x75\x67\x5f\145\156\141\142\154\x65");
        $mj["\163\x77\x69\x74\143\150\x5f\x73\x74\x61\164\165\163"] = $Cy;
        wp_send_json($mj);
        OI:
    }
    public function miniorange_oauth_save_settings()
    {
        global $Uc;
        $K9 = $Uc->get_plugin_config()->get_current_config();
        $YV = "\x64\x69\x73\x61\x62\x6c\145\x64";
        if (empty($K9["\x6d\x6f\x5f\x64\x74\x65\x5f\x73\164\141\x74\x65"])) {
            goto xl;
        }
        $YV = $Uc->mooauthdecrypt($K9["\155\x6f\x5f\x64\x74\x65\x5f\163\164\141\x74\145"]);
        xl:
        if (!(isset($_POST["\x63\150\x61\156\x67\x65\137\155\151\x6e\x69\157\162\141\156\x67\x65\137\156\157\x6e\143\x65"]) && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST["\143\x68\141\x6e\x67\145\137\x6d\151\156\151\157\162\x61\156\x67\x65\x5f\156\157\x6e\143\145"])), "\x63\150\x61\x6e\147\x65\137\155\x69\x6e\151\157\162\141\156\147\145") && isset($_POST[\MoOAuthConstants::OPTION]) && "\x63\x68\141\156\x67\x65\x5f\155\151\x6e\x69\x6f\x72\141\156\x67\145" === $_POST[\MoOAuthConstants::OPTION])) {
            goto lr;
        }
        mo_oauth_deactivate();
        return;
        lr:
        if (!(isset($_POST["\155\157\x5f\x6f\141\x75\x74\x68\137\145\x6e\141\x62\x6c\x65\x5f\x64\145\x62\165\x67\x5f\144\157\x77\x6e\x6c\x6f\141\x64\137\x6e\x6f\x6e\x63\145"]) && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST["\x6d\157\x5f\157\141\x75\x74\x68\137\x65\x6e\x61\x62\x6c\145\x5f\144\145\x62\165\147\137\x64\x6f\167\x6e\154\157\x61\144\x5f\x6e\x6f\156\143\145"])), "\x6d\157\x5f\x6f\141\x75\164\150\137\145\x6e\141\x62\154\x65\x5f\144\x65\142\x75\x67\x5f\144\x6f\x77\156\x6c\157\x61\x64") && isset($_POST[\MoOAuthConstants::OPTION]) && "\x6d\157\x5f\x6f\x61\x75\x74\150\137\x65\x6e\x61\x62\154\145\x5f\x64\x65\x62\165\x67\137\x64\157\x77\x6e\154\157\x61\144" === $_POST[\MoOAuthConstants::OPTION])) {
            goto Hy;
        }
        $Wj = plugin_dir_path(__FILE__) . "\x2f\x2e\x2e\x2f\117\101\x75\x74\150\x48\141\x6e\x64\154\x65\x72\57" . $Uc->mo_oauth_client_get_option("\x6d\157\x5f\x6f\x61\x75\x74\150\x5f\144\x65\142\x75\x67") . "\x2e\x6c\x6f\147";
        if (is_file($Wj)) {
            goto hn;
        }
        echo "\x34\60\x34\x20\106\151\154\145\40\x6e\x6f\x74\40\x66\157\165\156\x64\41";
        exit;
        hn:
        $YX = filesize($Wj);
        $UQ = basename($Wj);
        $rH = strtolower(pathinfo($UQ, PATHINFO_EXTENSION));
        $CS = "\141\x70\160\154\151\143\x61\164\x69\x6f\156\x2f\x66\157\x72\143\x65\55\144\x6f\167\156\x6c\x6f\x61\x64";
        if (!ob_get_contents()) {
            goto bF;
        }
        ob_clean();
        bF:
        header("\x50\162\141\147\x6d\141\x3a\x20\x70\165\x62\154\x69\x63");
        header("\x45\170\x70\151\162\145\x73\72\40\60");
        header("\103\141\x63\x68\x65\x2d\x43\157\x6e\164\162\157\154\72\x20\155\165\163\x74\55\162\145\166\141\154\x69\144\x61\164\145\x2c\x20\160\157\x73\x74\x2d\x63\150\x65\x63\x6b\75\60\54\40\x70\x72\145\x2d\x63\x68\145\143\153\x3d\x30");
        header("\x43\141\x63\150\145\x2d\x43\157\x6e\164\162\157\154\x3a\40\x70\165\x62\x6c\151\x63");
        header("\x43\x6f\x6e\x74\145\156\x74\x2d\x44\145\x73\x63\x72\x69\160\164\x69\x6f\x6e\72\x20\x46\151\x6c\145\40\x54\162\141\156\163\x66\145\x72");
        header("\x43\157\x6e\x74\x65\x6e\x74\55\x54\x79\160\145\72\x20{$CS}");
        $Kh = "\103\157\156\164\x65\x6e\x74\x2d\x44\x69\x73\x70\x6f\163\x69\164\151\x6f\x6e\72\40\x61\x74\x74\141\143\x68\x6d\x65\156\x74\x3b\40\146\x69\x6c\x65\x6e\x61\155\145\x3d" . $UQ . "\x3b";
        header($Kh);
        header("\103\157\156\x74\x65\x6e\164\x2d\124\162\141\156\x73\x66\145\162\55\x45\156\143\x6f\x64\151\x6e\x67\x3a\40\x62\151\x6e\141\162\x79");
        header("\103\x6f\x6e\164\145\x6e\164\55\x4c\145\156\x67\164\x68\x3a\40" . $YX);
        @readfile($Wj);
        exit;
        Hy:
        if (!(isset($_POST["\155\x6f\x5f\157\x61\165\164\x68\137\x63\154\145\x61\162\x5f\154\x6f\x67\137\x6e\157\156\143\145"]) && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST["\155\157\x5f\x6f\141\x75\x74\150\x5f\143\x6c\145\x61\162\137\x6c\x6f\147\x5f\x6e\x6f\x6e\143\x65"])), "\155\157\x5f\x6f\141\x75\x74\150\x5f\x63\x6c\145\141\162\x5f\x6c\157\147") && isset($_POST[\MoOAuthConstants::OPTION]) && "\x6d\157\137\157\141\165\164\150\137\143\x6c\145\141\x72\137\154\157\x67" === $_POST[\MoOAuthConstants::OPTION])) {
            goto gw;
        }
        $Wj = plugin_dir_path(__FILE__) . "\x2f\56\x2e\57\117\x41\x75\164\150\x48\x61\156\x64\154\x65\162\57" . $Uc->mo_oauth_client_get_option("\155\x6f\x5f\157\141\165\x74\x68\137\x64\x65\142\165\x67") . "\x2e\154\x6f\147";
        if (is_file($Wj)) {
            goto P1;
        }
        echo "\64\x30\x34\40\x46\151\154\x65\x20\x6e\x6f\x74\40\146\x6f\165\x6e\x64\41";
        exit;
        P1:
        file_put_contents($Wj, '');
        file_put_contents($Wj, "\124\150\x69\x73\40\x69\163\x20\164\150\145\x20\155\151\x6e\151\117\x72\x61\x6e\147\x65\40\117\101\165\x74\150\x20\160\x6c\165\147\x69\156\x20\x44\x65\x62\x75\x67\40\114\x6f\x67\40\146\151\154\145");
        $this->util->mo_oauth_client_update_option(\MoOAuthConstants::PANEL_MESSAGE_OPTION, "\104\x65\x62\165\147\40\x4c\x6f\x67\x73\40\143\154\x65\141\x72\145\144\40\x73\165\143\x63\x65\x73\x73\146\x75\x6c\154\171\56");
        $this->util->mo_oauth_show_success_message();
        gw:
        if (!(isset($_POST["\x6d\x6f\x5f\157\141\165\164\150\137\x72\x65\x67\x69\x73\x74\145\x72\x5f\143\x75\163\164\157\155\145\162\137\156\157\x6e\x63\x65"]) && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST["\155\x6f\x5f\x6f\x61\165\x74\x68\137\162\145\x67\x69\x73\164\145\162\137\x63\165\163\x74\157\155\x65\162\137\156\157\x6e\x63\145"])), "\155\157\x5f\x6f\141\x75\x74\150\x5f\x72\145\147\151\x73\x74\145\162\x5f\143\x75\x73\164\157\155\145\x72") && isset($_POST[\MoOAuthConstants::OPTION]) && "\155\157\137\157\141\x75\x74\x68\x5f\162\x65\147\151\163\164\x65\162\137\143\x75\163\164\157\x6d\145\x72" === $_POST[\MoOAuthConstants::OPTION])) {
            goto XC;
        }
        $gK = '';
        $oZ = '';
        $I3 = '';
        $tw = '';
        $ya = '';
        $x1 = '';
        $Ev = '';
        if (!($this->util->mo_oauth_check_empty_or_null($_POST["\x65\155\141\151\x6c"]) || $this->util->mo_oauth_check_empty_or_null($_POST["\160\x61\163\163\x77\157\x72\144"]) || $this->util->mo_oauth_check_empty_or_null($_POST["\x63\x6f\x6e\146\x69\162\155\x50\141\163\x73\x77\157\x72\144"]))) {
            goto U7;
        }
        $this->util->mo_oauth_client_update_option(\MoOAuthConstants::PANEL_MESSAGE_OPTION, "\x41\x6c\x6c\40\x74\150\x65\x20\x66\x69\x65\154\x64\163\40\x61\x72\145\x20\162\x65\x71\165\151\162\145\x64\56\x20\120\154\x65\x61\163\145\40\x65\156\x74\145\162\40\x76\x61\154\x69\x64\x20\x65\x6e\164\x72\151\x65\163\56");
        $this->util->mo_oauth_show_error_message();
        return;
        U7:
        if (strlen($_POST["\x70\141\x73\x73\167\157\162\144"]) < 8 || strlen($_POST["\x63\x6f\x6e\x66\151\x72\155\120\x61\x73\163\167\x6f\x72\x64"]) < 8) {
            goto tm;
        }
        $gK = sanitize_email($_POST["\145\155\141\151\x6c"]);
        $oZ = stripslashes($_POST["\x70\150\x6f\x6e\145"]);
        $I3 = stripslashes($_POST["\160\141\x73\x73\x77\157\x72\144"]);
        $tw = stripslashes($_POST["\x66\x6e\141\155\145"]);
        $ya = stripslashes($_POST["\154\x6e\x61\x6d\145"]);
        $x1 = stripslashes($_POST["\x63\x6f\155\160\x61\x6e\x79"]);
        $Ev = stripslashes($_POST["\x63\157\156\146\x69\162\155\120\141\163\x73\x77\x6f\162\144"]);
        goto Kb;
        tm:
        $this->util->mo_oauth_client_update_option(\MoOAuthConstants::PANEL_MESSAGE_OPTION, "\103\x68\157\x6f\x73\x65\x20\x61\x20\x70\x61\163\x73\x77\x6f\162\x64\x20\167\151\x74\x68\40\x6d\x69\x6e\151\x6d\165\x6d\x20\154\x65\x6e\x67\x74\x68\40\70\56");
        $this->util->mo_oauth_show_error_message();
        return;
        Kb:
        $this->util->mo_oauth_client_update_option("\155\x6f\137\157\x61\165\x74\150\137\141\x64\155\151\156\x5f\145\155\141\x69\154", $gK);
        $this->util->mo_oauth_client_update_option("\155\157\137\157\x61\x75\164\x68\x5f\141\x64\155\x69\x6e\x5f\x70\x68\157\156\x65", $oZ);
        $this->util->mo_oauth_client_update_option("\155\157\x5f\x6f\x61\165\164\150\x5f\141\144\155\151\x6e\x5f\x66\x6e\141\x6d\x65", $tw);
        $this->util->mo_oauth_client_update_option("\x6d\157\x5f\x6f\141\165\164\150\x5f\141\x64\155\x69\156\137\154\x6e\141\x6d\x65", $ya);
        $this->util->mo_oauth_client_update_option("\x6d\x6f\x5f\x6f\x61\x75\164\150\x5f\x61\144\x6d\151\x6e\137\143\157\x6d\x70\141\156\171", $x1);
        if (!($this->util->mo_oauth_is_curl_installed() === 0)) {
            goto f9;
        }
        return $this->util->mo_oauth_show_curl_error();
        f9:
        if (strcmp($I3, $Ev) === 0) {
            goto xk;
        }
        $this->util->mo_oauth_client_update_option(\MoOAuthConstants::PANEL_MESSAGE_OPTION, "\x50\x61\163\163\167\157\162\144\x73\40\144\157\x20\156\157\164\40\x6d\141\164\143\150\56");
        $this->util->mo_oauth_client_delete_option("\166\145\162\x69\146\171\x5f\x63\165\x73\x74\157\x6d\145\162");
        $this->util->mo_oauth_show_error_message();
        goto wm;
        xk:
        $this->util->mo_oauth_client_update_option("\x70\141\x73\x73\x77\x6f\x72\144", $I3);
        $Fr = new Customer();
        $gK = $this->util->mo_oauth_client_get_option("\155\157\137\157\141\165\164\150\137\141\x64\155\151\x6e\137\x65\x6d\141\x69\154");
        $ki = json_decode($Fr->check_customer(), true);
        if (strcasecmp($ki["\x73\x74\141\164\165\163"], "\103\125\123\x54\x4f\115\105\x52\137\x4e\x4f\124\137\x46\117\x55\116\104") === 0) {
            goto bH;
        }
        $this->mo_oauth_get_current_customer();
        goto Rn;
        bH:
        $this->create_customer();
        Rn:
        wm:
        XC:
        if (!(isset($_POST["\155\157\x5f\x6f\x61\165\164\150\x5f\x76\x65\162\151\146\x79\x5f\143\165\163\164\157\155\145\162\x5f\x6e\157\156\x63\x65"]) && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST["\155\157\137\157\x61\x75\x74\150\x5f\166\x65\162\x69\x66\x79\x5f\x63\165\x73\164\157\x6d\x65\162\137\156\x6f\x6e\143\x65"])), "\x6d\157\x5f\157\141\165\164\x68\137\x76\145\x72\x69\x66\171\x5f\x63\165\x73\164\x6f\155\x65\162") && isset($_POST[\MoOAuthConstants::OPTION]) && "\155\x6f\137\157\141\165\164\150\x5f\166\x65\162\x69\x66\x79\x5f\x63\x75\x73\164\157\155\x65\x72" === $_POST[\MoOAuthConstants::OPTION])) {
            goto e7;
        }
        if (!($this->util->mo_oauth_is_curl_installed() === 0)) {
            goto XA;
        }
        return $this->util->mo_oauth_show_curl_error();
        XA:
        $gK = isset($_POST["\x65\x6d\x61\151\x6c"]) ? sanitize_email(wp_unslash($_POST["\145\x6d\141\x69\154"])) : '';
        $I3 = isset($_POST["\x70\141\163\x73\167\x6f\162\x64"]) ? $_POST["\160\x61\163\163\x77\157\x72\144"] : '';
        if (!($this->util->mo_oauth_check_empty_or_null($gK) || $this->util->mo_oauth_check_empty_or_null($I3))) {
            goto HY;
        }
        $this->util->mo_oauth_client_update_option(\MoOAuthConstants::PANEL_MESSAGE_OPTION, "\x41\154\x6c\x20\164\150\x65\40\146\151\x65\x6c\x64\x73\x20\x61\x72\145\x20\x72\145\x71\x75\x69\x72\145\144\56\40\120\154\x65\141\163\x65\40\145\156\x74\x65\x72\x20\166\x61\154\x69\144\x20\145\x6e\x74\x72\151\x65\163\x2e");
        $this->util->mo_oauth_show_error_message();
        return;
        HY:
        $this->util->mo_oauth_client_update_option("\155\157\x5f\x6f\141\165\164\150\137\x61\144\155\x69\x6e\137\x65\x6d\x61\x69\x6c", $gK);
        $this->util->mo_oauth_client_update_option("\x70\x61\163\x73\x77\x6f\x72\x64", $I3);
        $Fr = new Customer();
        $ki = $Fr->get_customer_key();
        $sZ = json_decode($ki, true);
        if (json_last_error() === JSON_ERROR_NONE) {
            goto QR;
        }
        $this->util->mo_oauth_client_update_option(\MoOAuthConstants::PANEL_MESSAGE_OPTION, "\111\x6e\x76\141\x6c\151\x64\40\165\163\x65\162\x6e\x61\x6d\145\40\x6f\x72\x20\x70\x61\x73\x73\x77\x6f\x72\144\56\40\x50\154\145\x61\x73\x65\40\164\x72\x79\40\x61\147\141\x69\x6e\56");
        $this->util->mo_oauth_show_error_message();
        goto Eu;
        QR:
        $this->util->mo_oauth_client_update_option("\155\157\x5f\x6f\141\165\164\150\137\x61\x64\x6d\x69\x6e\137\143\165\x73\164\157\x6d\145\162\137\x6b\x65\171", $sZ["\151\x64"]);
        $this->util->mo_oauth_client_update_option("\x6d\x6f\x5f\x6f\141\x75\x74\150\137\x61\x64\155\151\156\137\141\160\151\137\153\145\171", $sZ["\141\x70\x69\x4b\x65\x79"]);
        $this->util->mo_oauth_client_update_option("\143\x75\x73\x74\x6f\x6d\x65\162\137\x74\157\x6b\145\x6e", $sZ["\164\157\153\x65\156"]);
        if (!isset($n7["\160\x68\157\x6e\x65"])) {
            goto PM;
        }
        $this->util->mo_oauth_client_update_option("\155\157\137\157\141\165\164\x68\x5f\x61\x64\155\x69\x6e\x5f\160\x68\157\156\x65", $sZ["\x70\x68\x6f\x6e\145"]);
        PM:
        $this->util->mo_oauth_client_delete_option("\160\141\163\163\167\x6f\162\144");
        $this->util->mo_oauth_client_update_option(\MoOAuthConstants::PANEL_MESSAGE_OPTION, "\103\165\163\164\x6f\155\145\162\40\x72\145\164\x72\x69\x65\166\145\144\x20\163\x75\x63\143\x65\163\x73\x66\x75\x6c\154\x79");
        $this->util->mo_oauth_client_delete_option("\x76\145\x72\151\x66\171\137\x63\165\x73\164\x6f\155\145\x72");
        $this->util->mo_oauth_show_success_message();
        Eu:
        e7:
        if (!(isset($_POST["\155\x6f\x5f\x6f\141\x75\164\x68\137\x63\x68\141\156\x67\145\137\x65\x6d\141\x69\154\x5f\156\157\156\x63\145"]) && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST["\155\157\x5f\x6f\141\x75\164\150\x5f\x63\x68\141\156\x67\x65\137\145\155\141\151\154\137\x6e\x6f\x6e\x63\145"])), "\x6d\x6f\137\157\x61\165\x74\x68\137\143\150\141\156\147\x65\x5f\x65\155\x61\151\154") && isset($_POST[\MoOAuthConstants::OPTION]) && "\155\157\137\x6f\141\165\164\150\x5f\143\x68\141\x6e\x67\145\137\145\x6d\x61\x69\154" === $_POST[\MoOAuthConstants::OPTION])) {
            goto Bc;
        }
        $this->util->mo_oauth_client_update_option("\166\145\162\x69\146\171\x5f\x63\165\163\x74\x6f\155\x65\x72", '');
        $this->util->mo_oauth_client_update_option("\x6d\x6f\137\x6f\x61\165\x74\x68\137\162\145\147\151\163\164\162\x61\x74\x69\157\x6e\x5f\163\164\x61\x74\x75\163", '');
        $this->util->mo_oauth_client_update_option("\156\x65\x77\x5f\x72\x65\x67\x69\163\164\162\141\164\151\x6f\156", "\164\x72\x75\145");
        Bc:
        if (!(isset($_POST["\x6d\157\x5f\157\x61\x75\164\150\137\x63\157\x6e\x74\141\x63\x74\137\165\x73\137\161\165\145\162\171\137\157\x70\x74\x69\x6f\x6e\137\156\x6f\x6e\x63\x65"]) && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST["\x6d\x6f\137\x6f\141\x75\164\x68\137\143\157\156\164\x61\x63\164\137\x75\x73\137\161\165\145\x72\x79\x5f\157\x70\164\151\x6f\156\x5f\156\157\x6e\x63\x65"])), "\x6d\157\x5f\157\141\165\x74\150\x5f\x63\x6f\156\164\x61\x63\x74\x5f\165\x73\137\x71\x75\x65\162\x79\x5f\157\160\x74\151\x6f\156") && isset($_POST[\MoOAuthConstants::OPTION]) && "\x6d\x6f\137\157\x61\165\x74\150\137\x63\x6f\156\164\x61\x63\x74\x5f\165\163\x5f\x71\165\145\162\171\x5f\x6f\160\x74\x69\x6f\156" === $_POST[\MoOAuthConstants::OPTION])) {
            goto fc;
        }
        if (!($this->util->mo_oauth_is_curl_installed() === 0)) {
            goto EY;
        }
        return $this->util->mo_oauth_show_curl_error();
        EY:
        $gK = isset($_POST["\x6d\157\x5f\x6f\141\165\164\x68\137\x63\157\156\x74\x61\143\164\x5f\165\x73\x5f\145\155\141\151\154"]) ? sanitize_text_field(wp_unslash($_POST["\155\157\x5f\x6f\141\x75\164\150\137\143\157\156\x74\x61\x63\x74\137\x75\163\137\145\x6d\x61\151\x6c"])) : '';
        $oZ = isset($_POST["\155\x6f\x5f\x6f\x61\165\164\150\x5f\x63\157\156\x74\141\x63\x74\137\165\163\x5f\x70\x68\157\x6e\145"]) ? sanitize_text_field(wp_unslash($_POST["\x6d\x6f\x5f\x6f\141\165\164\150\x5f\x63\157\x6e\x74\141\143\164\x5f\x75\x73\137\160\150\157\x6e\145"])) : '';
        $Iu = isset($_POST["\155\157\x5f\157\141\x75\164\150\x5f\143\x6f\156\164\141\143\164\137\165\x73\x5f\161\165\x65\x72\x79"]) ? sanitize_text_field(wp_unslash($_POST["\155\157\x5f\x6f\x61\x75\164\150\x5f\143\x6f\x6e\164\x61\143\x74\x5f\x75\163\x5f\161\165\145\x72\171"])) : '';
        $J9 = isset($_POST["\x6d\157\x5f\x6f\x61\165\164\150\137\x73\x65\156\x64\x5f\160\154\165\147\x69\156\137\143\x6f\156\x66\x69\x67"]);
        $Fr = new Customer();
        if ($this->util->mo_oauth_check_empty_or_null($gK) || $this->util->mo_oauth_check_empty_or_null($Iu)) {
            goto q5;
        }
        $Rm = $Fr->submit_contact_us($gK, $oZ, $Iu, $J9);
        if (false === $Rm) {
            goto b0;
        }
        $this->util->mo_oauth_client_update_option(\MoOAuthConstants::PANEL_MESSAGE_OPTION, "\124\x68\x61\156\x6b\x73\40\146\157\x72\x20\147\x65\x74\164\x69\x6e\x67\x20\151\x6e\40\164\x6f\165\143\x68\41\40\x57\145\40\x73\x68\141\154\154\40\x67\145\x74\40\x62\141\x63\153\x20\x74\157\x20\171\157\165\x20\163\150\x6f\x72\x74\x6c\171\x2e");
        $this->util->mo_oauth_show_success_message();
        goto X1;
        b0:
        $this->util->mo_oauth_client_update_option(\MoOAuthConstants::PANEL_MESSAGE_OPTION, "\131\x6f\165\162\40\161\x75\145\162\171\40\143\157\165\x6c\144\x20\x6e\157\x74\x20\x62\x65\x20\x73\165\x62\155\x69\164\x74\145\144\56\40\120\154\x65\x61\x73\x65\x20\x74\x72\171\x20\x61\147\x61\151\156\56");
        $this->util->mo_oauth_show_error_message();
        X1:
        goto Jk;
        q5:
        $this->util->mo_oauth_client_update_option(\MoOAuthConstants::PANEL_MESSAGE_OPTION, "\120\154\145\x61\x73\x65\x20\x66\151\x6c\154\40\165\160\x20\x45\x6d\141\x69\x6c\40\141\156\x64\x20\x51\x75\145\x72\x79\40\146\151\x65\154\x64\x73\40\x74\157\x20\x73\x75\142\x6d\x69\164\40\x79\157\x75\162\x20\x71\165\145\x72\171\x2e");
        $this->util->mo_oauth_show_error_message();
        Jk:
        fc:
        if (!(isset($_POST["\x6d\157\137\x6f\141\x75\x74\x68\x5f\143\x6f\x6e\x74\x61\143\x74\x5f\x75\x73\x5f\x71\165\145\162\x79\x5f\157\x70\x74\151\157\x6e\137\165\x70\x67\162\141\x64\x65\137\x6e\x6f\156\x63\145"]) && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST["\155\x6f\137\x6f\x61\x75\x74\x68\x5f\143\157\156\164\141\143\164\x5f\x75\163\x5f\161\165\145\162\171\137\x6f\160\164\x69\157\x6e\x5f\165\160\147\x72\141\x64\145\137\156\157\156\x63\145"])), "\155\x6f\137\157\x61\x75\164\150\137\143\157\156\164\x61\143\164\137\165\x73\x5f\161\x75\x65\x72\171\137\x6f\x70\164\151\157\x6e\x5f\165\160\147\162\x61\x64\x65") && isset($_POST[\MoOAuthConstants::OPTION]) && "\x6d\157\x5f\x6f\141\x75\164\x68\137\143\157\156\x74\x61\x63\164\x5f\x75\163\137\x71\x75\145\162\171\137\157\x70\x74\x69\157\156\x5f\165\x70\x67\162\x61\x64\x65" === $_POST[\MoOAuthConstants::OPTION])) {
            goto SY;
        }
        if (!($this->util->mo_oauth_is_curl_installed() === 0)) {
            goto fz;
        }
        return $this->util->mo_oauth_show_curl_error();
        fz:
        $gK = isset($_POST["\155\x6f\x5f\157\x61\x75\x74\x68\137\x63\x6f\156\164\x61\x63\x74\x5f\x75\163\x5f\145\x6d\141\151\x6c"]) ? sanitize_text_field(wp_unslash($_POST["\x6d\x6f\137\157\141\x75\x74\150\137\143\157\x6e\164\x61\143\x74\137\165\163\x5f\x65\155\141\x69\154"])) : '';
        $go = isset($_POST["\155\x6f\137\x6f\x61\165\x74\x68\x5f\x63\165\x72\x72\x65\156\164\137\x76\x65\162\163\151\x6f\156"]) ? sanitize_text_field(wp_unslash($_POST["\x6d\x6f\x5f\157\x61\x75\164\150\137\x63\x75\162\162\x65\156\x74\137\166\145\x72\x73\151\157\156"])) : '';
        $EE = isset($_POST["\x6d\x6f\137\x6f\x61\165\164\x68\137\x75\x70\147\x72\x61\x64\x69\156\x67\x5f\164\x6f\137\x76\x65\162\163\151\x6f\x6e"]) ? sanitize_text_field(wp_unslash($_POST["\155\157\x5f\157\141\165\164\150\137\165\160\x67\162\141\144\151\156\x67\137\164\157\137\x76\145\162\163\x69\x6f\156"])) : '';
        $nO = isset($_POST["\x6d\157\137\x66\145\x61\x74\165\162\145\x73\x5f\x72\x65\x71\x75\x69\x72\145\144"]) ? sanitize_text_field(wp_unslash($_POST["\x6d\157\137\146\145\x61\x74\x75\162\x65\163\x5f\x72\145\161\x75\x69\162\145\144"])) : '';
        $Fr = new Customer();
        if ($this->util->mo_oauth_check_empty_or_null($gK)) {
            goto Tj;
        }
        $Rm = $Fr->submit_contact_us_upgrade($gK, $go, $EE, $nO);
        if (false === $Rm) {
            goto Va;
        }
        $this->util->mo_oauth_client_update_option(\MoOAuthConstants::PANEL_MESSAGE_OPTION, "\124\150\x61\156\153\x73\40\146\157\162\x20\147\x65\164\x74\151\x6e\147\40\151\x6e\40\x74\157\165\x63\150\x21\x20\x57\x65\x20\163\x68\141\154\x6c\40\x67\x65\x74\40\142\141\143\x6b\40\x74\x6f\40\x79\x6f\x75\40\163\150\157\162\164\x6c\x79\40\167\x69\x74\x68\40\x71\x75\157\164\141\164\151\x6f\x6e");
        $this->util->mo_oauth_show_success_message();
        goto wY;
        Va:
        $this->util->mo_oauth_client_update_option(\MoOAuthConstants::PANEL_MESSAGE_OPTION, "\x59\157\165\162\40\161\165\x65\162\171\x20\x63\157\x75\x6c\144\40\156\x6f\164\40\142\x65\x20\x73\165\x62\155\151\164\x74\x65\x64\56\x20\120\x6c\x65\x61\x73\145\40\164\162\x79\x20\141\x67\141\x69\156\x2e");
        $this->util->mo_oauth_show_error_message();
        wY:
        goto bx;
        Tj:
        $this->util->mo_oauth_client_update_option(\MoOAuthConstants::PANEL_MESSAGE_OPTION, "\120\x6c\x65\141\163\145\40\x66\151\x6c\154\40\x75\160\40\x45\x6d\141\x69\x6c\40\x66\151\x65\x6c\144\x20\x74\157\x20\x73\x75\x62\155\151\x74\x20\x79\x6f\165\162\40\161\x75\x65\162\171\x2e");
        $this->util->mo_oauth_show_error_message();
        bx:
        SY:
        if (!($YV == "\x64\151\x73\141\x62\154\145\144")) {
            goto jC;
        }
        if (!(isset($_POST["\155\157\137\x6f\141\x75\x74\150\137\162\x65\x73\164\x6f\x72\145\137\142\141\143\x6b\x75\x70\x5f\156\157\156\143\145"]) && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST["\x6d\157\x5f\x6f\x61\x75\x74\150\137\162\x65\163\164\157\162\145\x5f\x62\x61\x63\153\165\x70\x5f\x6e\157\x6e\143\145"])), "\155\157\x5f\x6f\x61\165\164\x68\x5f\162\145\163\164\x6f\x72\145\137\142\x61\x63\153\165\x70") && isset($_POST[\MoOAuthConstants::OPTION]) && "\155\157\137\157\x61\165\x74\x68\x5f\x72\x65\163\x74\157\162\145\x5f\142\x61\x63\x6b\x75\x70" === $_POST[\MoOAuthConstants::OPTION])) {
            goto Zc;
        }
        $jk = "\x54\x68\x65\x72\x65\x20\x77\141\x73\40\141\x6e\40\x65\x72\x72\157\x72\x20\165\160\x6c\x6f\141\x64\x69\156\147\40\164\x68\145\40\x66\151\x6c\x65";
        if (isset($_FILES["\x6d\157\137\157\x61\x75\x74\150\137\143\154\151\145\x6e\x74\137\142\141\143\153\x75\x70"])) {
            goto BR;
        }
        $this->util->mo_oauth_client_update_option(\MoOAuthConstants::PANEL_MESSAGE_OPTION, $jk);
        $this->util->mo_oauth_show_error_message();
        return;
        BR:
        if (!function_exists("\167\x70\x5f\150\x61\x6e\144\154\x65\137\165\x70\x6c\x6f\x61\x64")) {
            require_once ABSPATH . "\167\x70\x2d\x61\x64\155\x69\156\x2f\151\156\x63\154\x75\144\x65\163\x2f\x66\151\154\145\56\160\150\x70";
        }
        $To = $_FILES["\155\157\x5f\x6f\x61\x75\x74\x68\137\x63\154\151\145\156\164\137\x62\141\x63\153\165\x70"];
        if (!(!isset($To["\145\x72\162\x6f\x72"]) || is_array($To["\x65\x72\x72\x6f\162"]) || UPLOAD_ERR_OK !== $To["\x65\x72\162\157\162"])) {
            goto Y9;
        }
        $this->util->mo_oauth_client_update_option(\MoOAuthConstants::PANEL_MESSAGE_OPTION, $jk . "\x3a\x20" . json_encode($To["\145\x72\x72\157\x72"], JSON_UNESCAPED_SLASHES));
        $this->util->mo_oauth_show_error_message();
        return;
        Y9:
        $fW = new \finfo(FILEINFO_MIME_TYPE);
        $oL = array_search($fW->file($To["\x74\155\160\x5f\156\141\x6d\145"]), array("\x74\x65\x78\x74" => "\164\x65\x78\164\57\160\154\141\x69\x6e", "\152\x73\157\156" => "\x61\x70\160\x6c\151\x63\x61\x74\x69\x6f\156\57\152\163\157\156"), true);
        $ZZ = explode("\x2e", $To["\156\x61\155\x65"]);
        $ZZ = $ZZ[count($ZZ) - 1];
        if (!(false === $oL || $ZZ !== "\152\163\x6f\156")) {
            goto Dk;
        }
        $this->util->mo_oauth_client_update_option(\MoOAuthConstants::PANEL_MESSAGE_OPTION, $jk . "\x3a\40\x49\x6e\166\141\154\151\144\40\x46\x69\154\x65\40\x46\157\162\155\141\x74\56");
        $this->util->mo_oauth_show_error_message();
        return;
        Dk:
        $Ag = file_get_contents($To["\164\x6d\160\137\156\x61\x6d\145"]);
        $K9 = json_decode($Ag, true);
        if (!(json_last_error() !== JSON_ERROR_NONE)) {
            goto pf;
        }
        $this->util->mo_oauth_client_update_option(\MoOAuthConstants::PANEL_MESSAGE_OPTION, $jk . "\x3a\40\x49\156\166\x61\154\x69\144\40\x46\x69\x6c\x65\40\x46\157\x72\155\141\x74\x2e");
        $this->util->mo_oauth_show_error_message();
        return;
        pf:
        $Hx = BackupHandler::restore_settings($K9);
        if (!$Hx) {
            goto Hn;
        }
        $this->util->mo_oauth_client_update_option(\MoOAuthConstants::PANEL_MESSAGE_OPTION, "\123\145\164\x74\151\x6e\x67\163\40\162\x65\163\x74\x6f\x72\x65\x64\x20\163\165\143\143\145\163\163\146\165\x6c\154\x79\56");
        $this->util->mo_oauth_show_success_message();
        return;
        Hn:
        $this->util->mo_oauth_client_update_option(\MoOAuthConstants::PANEL_MESSAGE_OPTION, "\x54\x68\x65\162\x65\40\167\x61\163\x20\x61\156\x20\x69\x73\x73\165\145\x20\167\x68\151\154\x65\40\x72\x65\163\x74\157\x72\151\156\x67\40\164\150\145\x20\143\x6f\x6e\x66\x69\x67\165\162\x61\x74\151\157\156\x2e");
        $this->util->mo_oauth_show_error_message();
        return;
        Zc:
        if (!(isset($_POST["\x6d\x6f\x5f\157\x61\165\x74\x68\x5f\x64\x6f\x77\156\x6c\157\141\144\137\142\141\143\x6b\x75\160\137\156\157\156\x63\x65"]) && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST["\155\157\137\x6f\141\x75\164\x68\x5f\144\x6f\167\x6e\x6c\x6f\141\x64\137\142\x61\143\x6b\x75\160\x5f\156\157\x6e\143\x65"])), "\x6d\157\x5f\x6f\x61\165\164\x68\x5f\144\x6f\x77\x6e\154\x6f\x61\x64\x5f\x62\x61\x63\x6b\165\x70") && isset($_POST[\MoOAuthConstants::OPTION]) && "\155\x6f\137\x6f\x61\x75\164\150\x5f\144\x6f\167\156\154\x6f\141\144\137\x62\x61\x63\x6b\x75\x70" === $_POST[\MoOAuthConstants::OPTION])) {
            goto Mj;
        }
        $Gf = BackupHandler::get_backup_json();
        header("\103\157\156\164\x65\x6e\164\x2d\124\171\160\x65\72\40\141\160\160\154\x69\143\141\164\151\x6f\156\57\152\x73\x6f\x6e");
        header("\103\157\156\x74\x65\156\x74\x2d\104\151\x73\x70\x6f\163\x69\164\151\157\x6e\72\x20\x61\x74\164\141\143\x68\x6d\145\156\x74\73\x20\x66\x69\x6c\145\156\141\155\145\75\x22\160\x6c\x75\147\151\x6e\137\142\x61\x63\x6b\x75\160\x2e\x6a\x73\x6f\x6e\42");
        header("\x43\x6f\156\164\x65\156\x74\x2d\x4c\145\156\147\x74\150\72\40" . strlen($Gf));
        header("\103\157\x6e\156\145\143\x74\151\x6f\156\72\x20\143\154\x6f\163\145");
        echo $Gf;
        exit;
        Mj:
        jC:
        do_action("\144\157\137\155\141\x69\156\137\x73\145\x74\x74\151\x6e\x67\163\x5f\151\156\164\145\x72\x6e\141\154", $_POST);
    }
    public function mo_oauth_get_current_customer()
    {
        $Fr = new Customer();
        $ki = $Fr->get_customer_key();
        $sZ = json_decode($ki, true);
        if (json_last_error() === JSON_ERROR_NONE) {
            goto X2;
        }
        $this->util->mo_oauth_client_update_option(\MoOAuthConstants::PANEL_MESSAGE_OPTION, "\131\x6f\x75\x20\x61\154\x72\145\141\144\x79\40\x68\x61\166\x65\40\x61\156\40\141\x63\x63\x6f\x75\x6e\164\x20\167\151\x74\150\x20\x6d\x69\156\151\117\x72\x61\x6e\x67\145\56\x20\120\154\145\x61\x73\145\40\x65\156\164\145\162\x20\x61\40\x76\x61\154\x69\x64\x20\x70\141\x73\x73\x77\157\x72\x64\56");
        $this->util->mo_oauth_client_update_option("\166\145\162\151\x66\x79\x5f\143\165\x73\x74\157\155\145\x72", "\164\x72\165\x65");
        $this->util->mo_oauth_show_error_message();
        goto Gk;
        X2:
        $this->util->mo_oauth_client_update_option("\155\x6f\137\x6f\x61\165\164\150\x5f\x61\144\155\151\x6e\x5f\143\x75\163\x74\x6f\x6d\x65\162\137\153\x65\x79", $sZ["\x69\144"]);
        $this->util->mo_oauth_client_update_option("\155\x6f\x5f\157\x61\165\164\x68\137\x61\x64\155\x69\156\x5f\x61\160\x69\x5f\x6b\145\x79", $sZ["\x61\x70\x69\113\145\171"]);
        $this->util->mo_oauth_client_update_option("\x63\x75\x73\164\157\155\145\162\137\x74\x6f\153\x65\156", $sZ["\x74\157\x6b\x65\x6e"]);
        $this->util->mo_oauth_client_update_option("\x70\x61\x73\x73\x77\x6f\x72\x64", '');
        $this->util->mo_oauth_client_update_option(\MoOAuthConstants::PANEL_MESSAGE_OPTION, "\x43\165\x73\164\x6f\x6d\145\x72\40\x72\145\164\162\151\x65\166\145\x64\x20\x73\x75\x63\143\145\163\x73\146\165\154\x6c\171");
        $this->util->mo_oauth_client_delete_option("\x76\x65\x72\x69\x66\x79\x5f\143\x75\163\x74\x6f\155\x65\x72");
        $this->util->mo_oauth_client_delete_option("\156\x65\167\137\162\x65\147\151\x73\x74\x72\x61\x74\x69\x6f\x6e");
        $this->util->mo_oauth_show_success_message();
        Gk:
    }
    public function create_customer()
    {
        global $Uc;
        $Fr = new Customer();
        $sZ = json_decode($Fr->create_customer(), true);
        if (strcasecmp($sZ["\163\x74\x61\164\x75\x73"], "\103\x55\x53\x54\x4f\115\x45\x52\x5f\125\x53\105\122\116\101\115\x45\137\101\x4c\122\105\101\x44\131\137\105\x58\x49\x53\124\123") === 0) {
            goto H3;
        }
        if (strcasecmp($sZ["\x73\164\141\x74\165\x73"], "\123\x55\103\x43\105\x53\x53") === 0) {
            goto Ka;
        }
        goto ar;
        H3:
        $this->mo_oauth_get_current_customer();
        $this->util->mo_oauth_client_delete_option("\155\x6f\x5f\157\141\165\x74\150\137\156\x65\167\137\143\165\x73\164\157\155\x65\162");
        goto ar;
        Ka:
        $this->util->mo_oauth_client_update_option("\155\157\x5f\x6f\x61\165\x74\150\x5f\x61\144\155\x69\x6e\137\143\x75\x73\164\x6f\155\145\162\137\153\145\171", $sZ["\x69\x64"]);
        $this->util->mo_oauth_client_update_option("\x6d\x6f\137\157\x61\165\x74\x68\x5f\x61\144\155\151\156\137\141\x70\x69\137\153\145\x79", $sZ["\x61\x70\151\113\x65\x79"]);
        $this->util->mo_oauth_client_update_option("\x63\x75\x73\164\x6f\x6d\145\162\137\x74\x6f\153\x65\x6e", $sZ["\164\157\153\x65\156"]);
        $this->util->mo_oauth_client_update_option("\160\141\163\163\167\157\162\x64", '');
        $this->util->mo_oauth_client_update_option(\MoOAuthConstants::PANEL_MESSAGE_OPTION, "\x52\145\147\151\x73\164\x65\162\145\x64\x20\163\x75\x63\x63\145\x73\163\146\165\154\x6c\x79\56");
        $this->util->mo_oauth_client_update_option("\x6d\157\x5f\x6f\x61\x75\x74\150\137\x72\x65\x67\151\163\164\162\141\164\x69\157\x6e\x5f\x73\164\x61\x74\165\x73", "\x4d\117\137\117\x41\125\x54\x48\137\122\105\x47\x49\123\124\x52\x41\124\x49\117\116\x5f\x43\x4f\115\120\x4c\x45\124\x45");
        $this->util->mo_oauth_client_update_option("\x6d\157\x5f\x6f\x61\165\x74\x68\137\156\145\167\137\x63\165\163\x74\157\x6d\145\162", 1);
        $this->util->mo_oauth_client_delete_option("\166\x65\x72\151\146\x79\137\x63\x75\163\x74\157\155\145\162");
        $this->util->mo_oauth_client_delete_option("\156\145\167\137\162\x65\x67\x69\163\x74\x72\141\x74\x69\x6f\156");
        $this->util->mo_oauth_show_success_message();
        ar:
    }
}
