<?php


namespace MoOauthClient;

use MoOauthClient\App;
use MoOauthClient\Backup\EnvVarResolver;
class MOUtils
{
    const FREE = 0;
    const STANDARD = 1;
    const PREMIUM = 2;
    const MULTISITE_PREMIUM = 3;
    const ENTERPRISE = 4;
    const ALL_INCLUSIVE_SINGLE_SITE = 5;
    const MULTISITE_ENTERPRISE = 6;
    const ALL_INCLUSIVE_MULTISITE = 7;
    private $is_multisite = false;
    public function __construct()
    {
        remove_action("\141\x64\x6d\151\156\x5f\156\157\164\151\143\x65\163", array($this, "\155\157\137\x6f\141\x75\164\150\137\x73\x75\143\143\145\x73\x73\x5f\155\145\x73\163\x61\x67\145"));
        remove_action("\141\144\155\x69\x6e\x5f\156\x6f\164\151\x63\145\163", array($this, "\x6d\x6f\137\x6f\x61\x75\164\x68\137\x65\162\x72\x6f\162\137\155\x65\163\163\141\x67\x65"));
        $this->is_multisite = boolval(get_site_option("\155\157\137\x6f\141\x75\164\x68\x5f\151\x73\115\x75\154\x74\x69\x53\x69\164\x65\x50\154\x75\147\x69\x6e\x52\145\x71\x75\x65\163\x74\145\x64")) ? true : ($this->is_multisite_versi() ? true : false);
    }
    public function mo_oauth_success_message()
    {
        $RN = "\x65\162\x72\x6f\162";
        $sb = $this->mo_oauth_client_get_option(\MoOAuthConstants::PANEL_MESSAGE_OPTION);
        echo "\74\144\151\166\x20\x63\x6c\x61\163\x73\75\x27" . $RN . "\47\x3e\x20\74\x70\76" . $sb . "\74\x2f\160\76\74\57\x64\x69\x76\x3e";
    }
    public function mo_oauth_error_message()
    {
        $RN = "\x75\x70\x64\x61\x74\145\144";
        $sb = $this->mo_oauth_client_get_option(\MoOAuthConstants::PANEL_MESSAGE_OPTION);
        echo "\x3c\144\151\166\40\x63\154\141\163\163\x3d\x27" . $RN . "\47\x3e\74\160\x3e" . $sb . "\x3c\57\x70\76\x3c\x2f\x64\x69\166\76";
    }
    public function mo_oauth_show_success_message()
    {
        $uw = is_multisite() && $this->is_multisite_versi() ? "\x6e\x65\x74\167\x6f\x72\153\x5f" : '';
        remove_action("{$uw}\141\x64\155\x69\x6e\137\156\157\x74\x69\x63\x65\163", array($this, "\x6d\157\x5f\x6f\141\165\164\x68\137\x73\165\143\143\145\x73\x73\137\x6d\x65\163\163\141\147\x65"));
        add_action("{$uw}\x61\x64\x6d\151\156\x5f\x6e\x6f\x74\x69\143\145\x73", array($this, "\x6d\x6f\137\157\x61\x75\x74\150\x5f\x65\162\x72\157\x72\x5f\155\145\x73\163\x61\147\145"));
    }
    public function mo_oauth_show_error_message()
    {
        $uw = is_multisite() && $this->is_multisite_versi() ? "\x6e\x65\164\x77\x6f\162\x6b\137" : '';
        remove_action("{$uw}\x61\x64\x6d\x69\x6e\137\x6e\157\164\x69\143\145\x73", array($this, "\155\157\137\157\141\x75\164\150\137\x65\x72\x72\x6f\x72\137\155\x65\163\x73\x61\147\145"));
        add_action("{$uw}\x61\144\155\151\156\x5f\156\x6f\x74\151\143\x65\163", array($this, "\155\157\137\x6f\141\165\164\150\x5f\x73\x75\x63\x63\x65\x73\163\137\155\145\x73\163\141\147\x65"));
    }
    public function mo_oauth_is_customer_registered()
    {
        $gK = $this->mo_oauth_client_get_option("\x6d\157\137\x6f\141\165\164\150\137\141\144\155\151\156\x5f\x65\x6d\141\x69\x6c");
        $sZ = $this->mo_oauth_client_get_option("\x6d\157\137\x6f\x61\x75\164\150\x5f\141\x64\155\151\x6e\x5f\143\x75\163\x74\157\155\145\x72\x5f\153\145\x79");
        if (!$gK || !$sZ || !is_numeric(trim($sZ))) {
            goto eq;
        }
        return 1;
        goto uK;
        eq:
        return 0;
        uK:
    }
    public function mooauthencrypt($DR)
    {
        $om = $this->mo_oauth_client_get_option("\143\x75\x73\x74\x6f\155\145\162\137\x74\x6f\x6b\145\x6e");
        if ($om) {
            goto dR;
        }
        return "\x66\141\x6c\x73\145";
        dR:
        $om = str_split(str_pad('', strlen($DR), $om, STR_PAD_RIGHT));
        $pe = str_split($DR);
        foreach ($pe as $gF => $jc) {
            $gQ = ord($jc) + ord($om[$gF]);
            $pe[$gF] = chr($gQ > 255 ? $gQ - 256 : $gQ);
            Fv:
        }
        Qz:
        return base64_encode(join('', $pe));
    }
    public function mooauthdecrypt($DR)
    {
        $DR = base64_decode($DR);
        $om = $this->mo_oauth_client_get_option("\x63\x75\163\x74\x6f\x6d\145\x72\137\x74\157\153\145\156");
        if ($om) {
            goto vK;
        }
        return "\146\x61\154\x73\145";
        vK:
        $om = str_split(str_pad('', strlen($DR), $om, STR_PAD_RIGHT));
        $pe = str_split($DR);
        foreach ($pe as $gF => $jc) {
            $gQ = ord($jc) - ord($om[$gF]);
            $pe[$gF] = chr($gQ < 0 ? $gQ + 256 : $gQ);
            iN:
        }
        ni:
        return join('', $pe);
    }
    public function mo_oauth_check_empty_or_null($C0)
    {
        if (!(!isset($C0) || empty($C0))) {
            goto BX;
        }
        return true;
        BX:
        return false;
    }
    public function is_multisite_plan()
    {
        return $this->is_multisite;
    }
    public function mo_oauth_is_curl_installed()
    {
        if (in_array("\143\x75\x72\154", get_loaded_extensions())) {
            goto Vh;
        }
        return 0;
        goto dU;
        Vh:
        return 1;
        dU:
    }
    public function mo_oauth_show_curl_error()
    {
        if (!($this->mo_oauth_is_curl_installed() === 0)) {
            goto E9;
        }
        $this->mo_oauth_client_update_option(\MoOAuthConstants::PANEL_MESSAGE_OPTION, "\x3c\141\x20\x68\162\145\x66\75\x22\x68\164\164\160\72\57\x2f\160\150\x70\x2e\x6e\x65\164\x2f\x6d\141\x6e\x75\141\x6c\x2f\x65\156\x2f\x63\x75\x72\x6c\x2e\x69\x6e\163\164\x61\x6c\x6c\x61\164\x69\x6f\156\56\x70\150\160\x22\40\164\141\162\x67\145\x74\75\42\137\x62\154\x61\156\153\42\x3e\x50\x48\120\40\x43\125\x52\x4c\40\145\x78\164\145\156\x73\x69\157\156\x3c\x2f\x61\x3e\x20\x69\163\x20\x6e\157\164\40\x69\156\x73\164\x61\154\154\145\x64\40\157\x72\40\x64\151\x73\x61\142\154\145\144\x2e\x20\120\x6c\x65\x61\x73\x65\x20\x65\x6e\141\142\154\x65\40\x69\164\40\164\x6f\40\x63\157\x6e\164\151\x6e\x75\x65\56");
        $this->mo_oauth_show_error_message();
        return;
        E9:
    }
    public function mo_oauth_is_clv()
    {
        $Ue = $this->mo_oauth_client_get_option("\155\157\x5f\x6f\x61\165\164\x68\137\x6c\166");
        $Ue = boolval($Ue) ? $this->mooauthdecrypt($Ue) : "\x66\141\154\x73\145";
        $Ue = !empty($this->mo_oauth_client_get_option("\155\x6f\x5f\157\141\165\x74\x68\137\154\153")) && "\164\162\x75\x65" === $Ue ? 1 : 0;
        if (!($Ue === 0)) {
            goto oE;
        }
        return $this->verify_lk();
        oE:
        return $Ue;
    }
    public function mo_oauth_hbca_xyake()
    {
        if ($this->mo_oauth_is_customer_registered()) {
            goto Oh;
        }
        return false;
        Oh:
        if ($this->mo_oauth_client_get_option("\155\x6f\137\x6f\141\x75\x74\x68\137\x61\144\155\151\156\137\143\165\x73\164\157\x6d\x65\162\x5f\x6b\x65\x79") > 138200) {
            goto mi;
        }
        return false;
        goto dl;
        mi:
        return true;
        dl:
    }
    public function get_default_app($P1, $Wy = false)
    {
        if ($P1) {
            goto Xz;
        }
        return false;
        Xz:
        $XT = false;
        $l8 = file_get_contents(MOC_DIR . "\x72\x65\x73\157\x75\x72\x63\x65\x73\x2f\141\x70\x70\x5f\x63\x6f\155\x70\157\156\x65\x6e\x74\163\x2f\144\145\146\141\165\154\x74\141\x70\x70\x73\x2e\x6a\163\x6f\156", true);
        $ZN = json_decode($l8, $Wy);
        foreach ($ZN as $vg => $qR) {
            if (!($vg === $P1)) {
                goto Mz;
            }
            if ($Wy) {
                goto j2;
            }
            $qR->appId = $vg;
            goto Gp;
            j2:
            $qR["\141\160\x70\111\x64"] = $vg;
            Gp:
            return $qR;
            Mz:
            de:
        }
        TM:
        return false;
    }
    public function get_plugin_config()
    {
        $K9 = $this->mo_oauth_client_get_option("\155\x6f\x5f\157\x61\165\164\150\x5f\143\x6c\151\145\156\x74\137\x63\157\x6e\x66\x69\147");
        return !$K9 || empty($K9) ? new Config(array()) : $K9;
    }
    public function get_app_list()
    {
        return $this->mo_oauth_client_get_option("\x6d\157\x5f\x6f\x61\x75\x74\150\137\141\160\x70\x73\x5f\154\x69\163\164") ? $this->mo_oauth_client_get_option("\155\x6f\x5f\x6f\141\x75\x74\x68\x5f\x61\x70\x70\163\137\x6c\x69\x73\x74") : false;
    }
    public function get_app_by_name($og = '')
    {
        $KJ = $this->get_app_list();
        if ($KJ) {
            goto G8;
        }
        return false;
        G8:
        if (!('' === $og || false === $og)) {
            goto a2;
        }
        $eD = array_values($KJ);
        return isset($eD[0]) ? $eD[0] : false;
        a2:
        foreach ($KJ as $LG => $Ts) {
            if (!($og === $LG)) {
                goto Zq;
            }
            return $Ts;
            Zq:
            if (!((int) $og === $LG)) {
                goto Rb;
            }
            return $Ts;
            Rb:
            KP:
        }
        SR:
        return false;
    }
    public function get_default_app_by_code_name($og = '')
    {
        $KJ = $this->mo_oauth_client_get_option("\x6d\x6f\x5f\157\141\165\164\150\137\x61\x70\x70\x73\x5f\154\x69\x73\x74") ? $this->mo_oauth_client_get_option("\155\x6f\137\157\x61\165\x74\x68\x5f\141\x70\160\x73\137\154\x69\x73\164") : false;
        if ($KJ) {
            goto KT;
        }
        return false;
        KT:
        if (!('' === $og)) {
            goto FZ;
        }
        $eD = array_values($KJ);
        return isset($eD[0]) ? $eD[0] : false;
        FZ:
        foreach ($KJ as $LG => $Ts) {
            $kS = $Ts->get_app_name();
            if (!($og === $kS)) {
                goto la;
            }
            return $this->get_default_app($Ts->get_app_config("\141\160\160\x5f\x74\x79\x70\145"), true);
            la:
            dX:
        }
        bA:
        return false;
    }
    public function set_app_by_name($og, $Cf)
    {
        $KJ = $this->mo_oauth_client_get_option("\x6d\157\x5f\157\141\x75\164\150\137\x61\x70\x70\163\137\x6c\151\x73\164") ? $this->mo_oauth_client_get_option("\x6d\157\137\157\141\165\164\x68\x5f\x61\x70\x70\163\137\x6c\x69\163\x74") : false;
        if ($KJ) {
            goto ht;
        }
        return false;
        ht:
        foreach ($KJ as $LG => $Ts) {
            if (!(gettype($LG) === "\151\x6e\x74\x65\x67\145\162")) {
                goto kc;
            }
            $LG = strval($LG);
            kc:
            if (!($og === $LG)) {
                goto q0;
            }
            $KJ[$LG] = new App($Cf);
            $KJ[$LG]->set_app_name($LG);
            $this->mo_oauth_client_update_option("\155\157\x5f\x6f\x61\165\164\x68\x5f\141\x70\x70\163\137\154\151\x73\164", $KJ);
            return true;
            q0:
            Li:
        }
        xI:
        return false;
    }
    public function mo_oauth_jhuyn_jgsukaj($tj, $Dq)
    {
        return $this->mo_oauth_jkhuiysuayhbw($tj, $Dq);
    }
    public function mo_oauth_jkhuiysuayhbw($zn, $N4)
    {
        $jN = 0;
        $ce = false;
        $xI = $this->mo_oauth_client_get_option("\155\157\x5f\157\x61\165\164\x68\137\x61\165\x74\150\x6f\x72\151\172\141\164\151\157\x6e\x73");
        if (empty($xI)) {
            goto Tr;
        }
        $jN = $this->mo_oauth_client_get_option("\155\157\137\x6f\141\165\x74\x68\x5f\x61\165\164\150\x6f\162\151\x7a\x61\164\x69\157\156\x73");
        Tr:
        $user = $this->mo_oauth_hjsguh_kiishuyauh878gs($zn, $N4);
        if (!$user) {
            goto vH;
        }
        ++$jN;
        vH:
        $this->mo_oauth_client_update_option("\155\x6f\x5f\157\141\165\x74\150\x5f\x61\165\164\150\x6f\162\151\172\141\164\151\x6f\x6e\x73", $jN);
        if (!($jN >= 10)) {
            goto mz;
        }
        $Gl = base64_decode("bW9fb2F1dGhfZmxhZw==");
        $this->mo_oauth_client_update_option($Gl, true);
        mz:
        return $user;
    }
    public function mo_oauth_hjsguh_kiishuyauh878gs($gK, $Mk)
    {
        $GO = 10;
        $cv = false;
        $HK = false;
        $K9 = apply_filters("\x6d\x6f\137\157\141\x75\164\x68\137\x70\x61\163\163\167\x6f\x72\144\x5f\160\x6f\154\x69\143\171\x5f\155\x61\x6e\141\x67\x65\162", $GO);
        if (!is_array($K9)) {
            goto kt;
        }
        $GO = intval($K9["\x70\141\x73\x73\x77\157\162\144\x5f\x6c\145\x6e\x67\x74\150"]);
        $cv = $K9["\x73\160\x65\143\151\x61\x6c\x5f\x63\150\x61\162\141\x63\164\x65\x72\x73"];
        $HK = $K9["\145\170\x74\162\x61\137\x73\160\x65\143\x69\141\x6c\x5f\x63\x68\141\162\141\143\x74\145\162\x73"];
        kt:
        $d2 = wp_generate_password($GO, $cv, $HK);
        $KK = is_email($gK) ? wp_create_user($gK, $d2, $gK) : wp_create_user($gK, $d2);
        $r8 = array("\x49\x44" => $KK, "\x75\x73\x65\x72\x5f\145\155\x61\x69\x6c" => $gK, "\165\163\x65\162\137\x6c\x6f\x67\151\156" => $Mk, "\165\x73\145\162\x5f\156\151\143\145\156\x61\x6d\145" => $Mk, "\x66\151\162\163\164\x5f\x6e\141\x6d\x65" => $Mk);
        do_action("\165\163\x65\x72\137\x72\x65\147\x69\163\164\145\x72", $KK, $r8);
        $user = get_user_by("\x6c\x6f\x67\x69\x6e", $gK);
        wp_update_user(array("\111\x44" => $KK, "\146\x69\x72\163\164\137\156\141\x6d\145" => $Mk));
        return $user;
    }
    public function check_versi($TA)
    {
        return $this->get_versi() >= $TA;
    }
    public function is_multisite_versi()
    {
        return $this->get_versi() >= 6 || $this->get_versi() == 3;
    }
    public function get_versi()
    {
        return VERSION === "\155\157\x5f\x6d\x75\154\164\151\x73\x69\164\x65\x5f\x61\154\154\137\x69\156\x63\x6c\x75\163\151\166\145\137\166\145\162\x73\x69\x6f\x6e" ? self::ALL_INCLUSIVE_MULTISITE : (VERSION === "\155\x6f\137\x6d\x75\154\x74\151\x73\151\x74\145\137\160\x72\145\155\x69\x75\155\137\x76\145\x72\163\x69\157\156" ? self::MULTISITE_PREMIUM : (VERSION === "\x6d\157\x5f\x6d\165\154\164\151\x73\x69\x74\x65\137\x65\x6e\164\x65\x72\160\162\151\x73\x65\x5f\166\145\162\163\151\x6f\156" ? self::MULTISITE_ENTERPRISE : (VERSION === "\155\x6f\x5f\x61\x6c\x6c\137\151\x6e\x63\x6c\165\x73\151\x76\145\x5f\166\x65\x72\x73\151\x6f\x6e" ? self::ALL_INCLUSIVE_SINGLE_SITE : (VERSION === "\155\x6f\x5f\145\156\164\x65\162\160\162\x69\163\x65\x5f\166\x65\x72\163\151\x6f\x6e" ? self::ENTERPRISE : (VERSION === "\x6d\157\137\x70\162\145\x6d\151\x75\155\137\166\x65\x72\x73\151\157\156" ? self::PREMIUM : (VERSION === "\155\157\x5f\x73\164\141\x6e\144\x61\x72\144\x5f\166\x65\162\x73\x69\157\156" ? self::STANDARD : self::FREE))))));
    }
    public function get_plan_type_versi()
    {
        switch ($this->get_versi()) {
            case self::ALL_INCLUSIVE_MULTISITE:
                return "\101\x4c\114\x5f\111\116\x43\114\x55\123\111\126\105\137\x4d\125\x4c\x54\111\123\111\124\x45";
            case self::MULTISITE_PREMIUM:
                return "\x4d\x55\x4c\124\x49\123\x49\x54\x45\137\120\x52\105\x4d\111\x55\115";
            case self::MULTISITE_ENTERPRISE:
                return "\115\125\x4c\124\111\123\x49\x54\105\137\x45\x4e\x54\105\x52\120\x52\111\x53\105";
            case self::ALL_INCLUSIVE_SINGLE_SITE:
                return "\105\116\124\x45\x52\x50\122\x49\x53\105";
            case self::ENTERPRISE:
                return "\x45\116\x54\105\122\120\122\111\123\x45";
            case self::PREMIUM:
                return '';
            case self::STANDARD:
                return "\x53\x54\101\x4e\x44\x41\122\104";
            case self::FREE:
            default:
                return "\x46\x52\x45\105";
        }
        W9:
        PZ:
    }
    public function get_versi_str()
    {
        switch ($this->get_versi()) {
            case self::ALL_INCLUSIVE_MULTISITE:
                return "\x41\x4c\x4c\137\x49\x4e\103\x4c\x55\x53\x49\126\105\137\115\x55\x4c\x54\x49\123\111\x54\x45";
            case self::MULTISITE_PREMIUM:
                return "\x4d\x55\x4c\124\x49\x53\x49\x54\x45\x5f\120\x52\105\x4d\x49\x55\115";
            case self::MULTISITE_ENTERPRISE:
                return "\115\125\114\124\111\123\x49\124\x45\137\105\116\124\x45\x52\x50\x52\111\123\x45";
            case self::ALL_INCLUSIVE_SINGLE_SITE:
                return "\101\x4c\114\x5f\111\116\103\114\125\x53\111\126\x45\137\x53\x49\116\107\114\x45\137\123\111\124\x45";
            case self::ENTERPRISE:
                return "\x45\116\124\105\122\x50\122\111\123\105";
            case self::PREMIUM:
                return "\120\122\105\x4d\x49\125\x4d";
            case self::STANDARD:
                return "\x53\x54\x41\x4e\x44\101\x52\x44";
            case self::FREE:
            default:
                return "\x46\122\105\x45";
        }
        Ry:
        tr:
    }
    public function mo_oauth_client_get_option($LG, $OJ = false)
    {
        $C0 = getenv(strtoupper($LG));
        if (!$C0) {
            goto go;
        }
        $C0 = EnvVarResolver::resolve_var($LG, $C0);
        goto LD;
        go:
        $C0 = is_multisite() && $this->is_multisite ? get_site_option($LG, $OJ) : get_option($LG, $OJ);
        LD:
        if (!(!$C0 || $OJ == $C0)) {
            goto mC;
        }
        return $OJ;
        mC:
        return $C0;
    }
    public function mo_oauth_client_update_option($LG, $C0)
    {
        return is_multisite() && $this->is_multisite ? update_site_option($LG, $C0) : update_option($LG, $C0);
    }
    public function mo_oauth_client_delete_option($LG)
    {
        return is_multisite() && $this->is_multisite ? delete_site_option($LG) : delete_option($LG);
    }
    public function array_overwrite($kJ, $zS, $gR)
    {
        if ($gR) {
            goto fj;
        }
        array_push($kJ, $zS);
        return array_unique($kJ);
        fj:
        foreach ($zS as $LG => $C0) {
            $kJ[$LG] = $C0;
            Tn:
        }
        Yj:
        return $kJ;
    }
    public function gen_rand_str($GO = 10)
    {
        $Ew = "\141\x62\143\144\145\x66\x67\x68\x69\x6a\153\x6c\x6d\x6e\x6f\160\x71\x72\163\x74\x75\166\167\170\171\x7a\101\x42\103\x44\x45\x46\107\110\x49\112\x4b\114\115\x4e\117\x50\x51\122\x53\124\x55\x56\x57\130\131\x5a";
        $Py = strlen($Ew);
        $kq = '';
        $P6 = 0;
        n1:
        if (!($P6 < $GO)) {
            goto kj;
        }
        $kq .= $Ew[rand(0, $Py - 1)];
        TL:
        $P6++;
        goto n1;
        kj:
        return $kq;
    }
    public function parse_url($yN)
    {
        $XT = array();
        $TP = explode("\77", $yN);
        $XT["\150\x6f\x73\x74"] = $TP[0];
        $XT["\x71\x75\145\x72\171"] = isset($TP[1]) && '' !== $TP[1] ? $TP[1] : '';
        if (!(empty($XT["\161\x75\x65\162\x79"]) || '' === $XT["\161\165\145\x72\171"])) {
            goto np;
        }
        return $XT;
        np:
        $Oe = [];
        foreach (explode("\46", $XT["\161\165\x65\x72\x79"]) as $LH) {
            $TP = explode("\75", $LH);
            if (!(is_array($TP) && count($TP) === 2)) {
                goto Tp;
            }
            $Oe[str_replace("\141\x6d\x70\73", '', $TP[0])] = $TP[1];
            Tp:
            if (!(is_array($TP) && "\x73\164\x61\164\x65" === $TP[0])) {
                goto VK;
            }
            $TP = explode("\x73\x74\141\x74\x65\x3d", $LH);
            $Oe["\x73\x74\141\x74\x65"] = $TP[1];
            VK:
            eX:
        }
        p7:
        $XT["\x71\165\x65\162\171"] = is_array($Oe) && !empty($Oe) ? $Oe : [];
        return $XT;
    }
    public function generate_url($vh)
    {
        if (!(!is_array($vh) || empty($vh))) {
            goto Tt;
        }
        return '';
        Tt:
        if (isset($vh["\x68\157\x73\164"])) {
            goto vp;
        }
        return '';
        vp:
        $yN = $vh["\150\157\163\164"];
        $Nh = '';
        $P6 = 0;
        foreach ($vh["\x71\165\145\x72\171"] as $YF => $C0) {
            if (!($P6 !== 0)) {
                goto OQ;
            }
            $Nh .= "\46";
            OQ:
            $Nh .= "{$YF}\x3d{$C0}";
            $P6 += 1;
            D6:
        }
        ac:
        return $yN . "\77" . $Nh;
    }
    public function getnestedattribute($Y6, $LG)
    {
        if (!($LG == '')) {
            goto Kl;
        }
        return '';
        Kl:
        if (!filter_var($LG, FILTER_VALIDATE_URL)) {
            goto Y7;
        }
        if (isset($Y6[$LG])) {
            goto cW;
        }
        return '';
        goto vW;
        cW:
        return $Y6[$LG];
        vW:
        Y7:
        $St = explode("\x2e", $LG);
        if (count($St) > 1) {
            goto li;
        }
        if (isset($Y6[$LG]) && is_array($Y6[$LG])) {
            goto Yc;
        }
        $UH = $St[0];
        if (isset($Y6[$UH])) {
            goto tV;
        }
        return '';
        goto xw;
        tV:
        if (is_array($Y6[$UH])) {
            goto iC;
        }
        return $Y6[$UH];
        goto Op;
        iC:
        return $Y6[$UH][0];
        Op:
        xw:
        goto t7;
        Yc:
        if (!(count($Y6[$LG]) > 1)) {
            goto Ug;
        }
        return $Y6[$LG];
        Ug:
        if (!isset($Y6[$LG][0])) {
            goto NA;
        }
        return $Y6[$LG][0];
        NA:
        if (!is_array($Y6[$LG])) {
            goto FR;
        }
        return array_key_first($Y6[$LG]);
        FR:
        t7:
        goto ax;
        li:
        $UH = $St[0];
        if (!isset($Y6[$UH])) {
            goto PD;
        }
        $rS = array_count_values($St);
        if (!($rS[$UH] > 1)) {
            goto oi;
        }
        $LG = substr_replace($LG, '', 0, strlen($UH));
        $LG = trim($LG, "\56");
        return $this->getnestedattribute($Y6[$UH], $LG);
        oi:
        return $this->getnestedattribute($Y6[$UH], str_replace($UH . "\56", '', $LG));
        PD:
        ax:
    }
    public function get_client_ip()
    {
        $GS = '';
        if (getenv("\110\x54\124\120\137\103\x4c\111\x45\116\124\x5f\111\x50")) {
            goto Oz;
        }
        if (getenv("\x48\x54\x54\120\137\x58\x5f\106\x4f\122\127\101\x52\x44\x45\x44\x5f\106\117\122")) {
            goto fq;
        }
        if (getenv("\x48\x54\x54\120\x5f\130\x5f\x46\x4f\122\x57\101\x52\x44\x45\104")) {
            goto IU;
        }
        if (getenv("\x48\124\124\x50\x5f\106\117\122\127\101\122\104\x45\104\x5f\106\117\x52")) {
            goto CM;
        }
        if (getenv("\110\x54\124\120\x5f\106\x4f\x52\127\101\x52\x44\x45\104")) {
            goto l2;
        }
        if (getenv("\x52\x45\115\x4f\x54\105\x5f\101\104\x44\122")) {
            goto q6;
        }
        $GS = "\125\116\x4b\116\x4f\x57\116";
        goto gp;
        Oz:
        $GS = getenv("\110\124\124\120\137\103\x4c\111\x45\x4e\x54\x5f\x49\x50");
        goto gp;
        fq:
        $GS = getenv("\x48\x54\124\x50\137\130\x5f\106\117\122\x57\101\x52\104\x45\x44\x5f\106\x4f\122");
        goto gp;
        IU:
        $GS = getenv("\110\x54\x54\x50\137\x58\137\x46\x4f\122\x57\101\x52\104\x45\104");
        goto gp;
        CM:
        $GS = getenv("\x48\124\124\x50\x5f\106\117\122\127\x41\x52\104\105\104\x5f\106\x4f\122");
        goto gp;
        l2:
        $GS = getenv("\x48\x54\124\120\137\106\x4f\x52\127\101\122\104\x45\x44");
        goto gp;
        q6:
        $GS = getenv("\122\x45\x4d\117\124\105\x5f\101\104\104\122");
        gp:
        return $GS;
    }
    public function get_current_url()
    {
        return (isset($_SERVER["\x48\124\124\120\123"]) ? "\150\164\164\160\163" : "\150\164\x74\x70") . "\x3a\x2f\x2f{$_SERVER["\110\x54\124\120\137\110\117\x53\124"]}{$_SERVER["\x52\x45\x51\125\x45\123\x54\x5f\x55\x52\x49"]}";
    }
    public function get_all_headers()
    {
        $zd = [];
        foreach ($_SERVER as $Mk => $C0) {
            if (!(substr($Mk, 0, 5) == "\110\x54\124\120\x5f")) {
                goto Gn;
            }
            $zd[str_replace("\x20", "\x2d", ucwords(strtolower(str_replace("\137", "\x20", substr($Mk, 5)))))] = $C0;
            Gn:
            hg:
        }
        XT:
        $zd = array_change_key_case($zd, CASE_UPPER);
        return $zd;
    }
    public function store_info($G7 = '', $C0 = false)
    {
        if (!('' === $G7 || !$C0)) {
            goto Gh;
        }
        return;
        Gh:
        setcookie($G7, $C0);
    }
    public function redirect_user($yN = false, $rV = false)
    {
        if (!(false === $yN)) {
            goto iv;
        }
        return;
        iv:
        if (!$rV) {
            goto mb;
        }
        echo "\x9\11\11\x3c\163\143\162\151\x70\x74\76\xd\12\11\11\x9\11\166\x61\162\40\155\x79\127\151\x6e\x64\157\167\x20\75\40\167\x69\x6e\144\x6f\x77\56\157\x70\145\x6e\x28\42";
        echo $yN;
        echo "\x22\54\x20\x22\x54\145\163\x74\40\x43\x6f\x6e\x66\x69\x67\165\162\x61\164\x69\x6f\x6e\x22\x2c\40\x22\x77\x69\144\164\x68\x3d\x36\60\x30\x2c\x20\150\145\x69\147\150\x74\x3d\66\60\x30\42\x29\x3b\15\xa\11\11\11\11\167\x68\x69\154\x65\50\61\x29\40\x7b\15\xa\11\11\x9\11\11\x69\146\50\155\171\127\x69\156\x64\157\167\x2e\143\154\157\163\145\144\50\51\51\x20\173\xd\xa\11\x9\x9\x9\x9\x9\x24\50\144\157\143\x75\155\x65\156\x74\51\x2e\x74\162\151\x67\x67\x65\162\50\42\143\x6f\x6e\x66\x69\147\137\164\x65\x73\164\145\x64\42\x29\x3b\xd\xa\x9\x9\x9\11\11\11\142\x72\145\x61\x6b\x3b\15\xa\x9\x9\11\x9\11\x7d\40\x65\x6c\163\145\x20\173\143\157\156\164\x69\x6e\x75\x65\x3b\175\xd\12\x9\11\x9\x9\x7d\xd\xa\11\x9\11\74\x2f\163\143\162\151\160\x74\x3e\xd\12\x9\11\x9";
        mb:
        echo "\x9\x9\74\x73\x63\162\151\x70\164\x3e\xd\12\11\x9\x9\x77\x69\156\x64\x6f\167\56\x6c\x6f\x63\141\164\x69\x6f\x6e\56\x72\145\x70\154\x61\x63\x65\50\42";
        echo $yN;
        echo "\x22\x29\73\15\xa\11\11\74\x2f\x73\x63\162\151\x70\x74\76\15\xa\11\11";
        exit;
    }
    public function is_ajax_request()
    {
        return defined("\104\117\x49\x4e\x47\x5f\101\112\x41\130") && DOING_AJAX;
    }
    public function deactivate_plugin()
    {
        $this->mo_oauth_client_delete_option("\150\x6f\x73\x74\x5f\x6e\x61\x6d\x65");
        $this->mo_oauth_client_delete_option("\x6e\x65\167\x5f\x72\x65\147\x69\x73\x74\162\141\x74\x69\x6f\156");
        $this->mo_oauth_client_delete_option("\155\x6f\137\x6f\x61\x75\164\150\137\141\x64\155\151\156\137\160\150\157\x6e\145");
        $this->mo_oauth_client_delete_option("\x76\145\162\x69\x66\x79\x5f\143\165\163\x74\157\155\x65\162");
        $this->mo_oauth_client_delete_option("\155\x6f\137\x6f\141\165\164\x68\x5f\141\x64\x6d\151\156\137\143\x75\163\164\x6f\155\x65\x72\x5f\153\x65\x79");
        $this->mo_oauth_client_delete_option("\x6d\x6f\137\x6f\x61\165\164\x68\137\x61\144\155\151\x6e\x5f\x61\x70\151\137\x6b\145\171");
        $this->mo_oauth_client_delete_option("\x6d\x6f\x5f\x6f\x61\165\x74\x68\x5f\156\145\x77\x5f\x63\x75\163\164\157\155\x65\x72");
        $this->mo_oauth_client_delete_option("\x63\x75\163\164\x6f\155\145\x72\x5f\x74\x6f\153\x65\x6e");
        $this->mo_oauth_client_delete_option(\MoOAuthConstants::PANEL_MESSAGE_OPTION);
        $this->mo_oauth_client_delete_option("\x6d\x6f\x5f\x6f\x61\165\x74\150\x5f\x72\x65\x67\x69\163\x74\x72\x61\164\x69\157\156\137\163\164\141\x74\165\163");
        $this->mo_oauth_client_delete_option("\155\x6f\x5f\157\141\x75\164\150\137\x6e\145\167\x5f\x63\x75\163\164\157\x6d\145\162");
        $this->mo_oauth_client_delete_option("\156\145\167\x5f\162\145\x67\x69\163\x74\x72\141\x74\151\157\156");
        $this->mo_oauth_client_delete_option("\x6d\x6f\137\157\141\165\x74\x68\x5f\154\x6f\147\x69\x6e\137\151\143\x6f\x6e\137\143\165\x73\x74\157\x6d\137\x68\x65\x69\147\x68\x74");
        $this->mo_oauth_client_delete_option("\155\x6f\137\157\141\165\x74\150\137\154\157\147\151\156\137\x69\x63\x6f\156\137\x63\x75\x73\x74\157\x6d\137\163\x69\x7a\145");
        $this->mo_oauth_client_delete_option("\x6d\x6f\x5f\157\x61\165\164\150\137\x6c\x6f\x67\151\156\137\x69\143\x6f\x6e\137\143\x75\163\x74\x6f\x6d\137\143\x6f\154\157\x72");
        $this->mo_oauth_client_delete_option("\x6d\x6f\137\x6f\141\x75\164\150\137\x6c\157\x67\151\156\x5f\151\143\x6f\156\137\x63\165\163\164\x6f\155\x5f\142\x6f\x75\156\x64\141\x72\x79");
    }
    public function base64url_encode($VP)
    {
        return rtrim(strtr(base64_encode($VP), "\x2b\57", "\x2d\137"), "\75");
    }
    public function base64url_decode($VP)
    {
        return base64_decode(str_pad(strtr($VP, "\x2d\x5f", "\x2b\57"), strlen($VP) % 4, "\75", STR_PAD_RIGHT));
    }
    function export_plugin_config($hZ = false)
    {
        $Ig = [];
        $sl = [];
        $LW = [];
        $Ig = $this->get_plugin_config();
        $sl = get_site_option("\155\157\137\157\x61\x75\164\150\137\141\160\x70\x73\137\x6c\x69\163\x74");
        if (empty($Ig)) {
            goto vt;
        }
        $Ig = $Ig->get_current_config();
        vt:
        if (!is_array($sl)) {
            goto NG;
        }
        foreach ($sl as $io => $Cf) {
            if (!is_array($Cf)) {
                goto ob;
            }
            $Cf = new App($Cf);
            ob:
            $sA = $Cf->get_app_config('', false);
            if (!$hZ) {
                goto wx;
            }
            unset($sA["\x63\x6c\x69\x65\156\x74\137\151\x64"]);
            unset($sA["\143\154\151\145\156\164\137\163\x65\143\162\145\164"]);
            wx:
            $LW[$io] = $sA;
            RH:
        }
        mn:
        NG:
        $xr = ["\160\x6c\165\x67\x69\156\x5f\x63\157\156\x66\151\147" => $Ig, "\x61\160\x70\137\143\157\x6e\x66\x69\147\x73" => $LW];
        $xr = apply_filters("\x6d\x6f\137\x74\x72\137\x67\145\x74\137\154\151\x63\x65\x6e\x73\x65\x5f\x63\x6f\156\146\x69\x67", $xr);
        return $xr;
    }
    private function verify_lk()
    {
        $Fr = new \MoOauthClient\Standard\Customer();
        $bw = $this->mo_oauth_client_get_option("\155\157\137\x6f\x61\x75\164\150\137\154\151\x63\145\x6e\163\x65\x5f\153\145\x79");
        if (!empty($bw)) {
            goto sq;
        }
        return 0;
        sq:
        $NB = $Fr->XfskodsfhHJ($bw);
        $NB = json_decode($NB, true);
        return isset($NB["\x73\x74\x61\164\165\x73"]) && "\x53\x55\x43\103\105\123\x53" === $NB["\x73\x74\141\164\165\163"];
    }
    public function is_valid_jwt($p1 = '')
    {
        $TP = explode("\56", $p1);
        if (!(count($TP) === 3)) {
            goto b1;
        }
        return true;
        b1:
        return false;
    }
    public function validate_appslist($KJ)
    {
        if (is_array($KJ)) {
            goto TV;
        }
        return false;
        TV:
        foreach ($KJ as $LG => $Ts) {
            if (!$Ts instanceof \MoOauthClient\App) {
                goto aO;
            }
            goto b_;
            aO:
            return false;
            b_:
        }
        Cg:
        return true;
    }
    public function handle_error($eC)
    {
        do_action("\x6d\x6f\137\164\x72\x5f\x6c\x6f\147\151\156\x5f\145\x72\x72\157\x72\163", $eC);
    }
    public function set_transient($LG, $C0, $ev)
    {
        return is_multisite() && $this->is_multisite ? set_site_transient($LG, $C0, $ev) : set_transient($LG, $C0, $ev);
    }
    public function get_transient($LG)
    {
        return is_multisite() && $this->is_multisite ? get_site_transient($LG) : get_transient($LG);
    }
    public function delete_transient($LG)
    {
        return is_multisite() && $this->is_multisite ? delete_site_transient($LG) : delete_transient($LG);
    }
}
