<?php


namespace MoOauthClient;

interface OauthHandlerInterface
{
    public function get_token($g0, $nK, $jV, $vN);
    public function get_access_token($g0, $nK, $jV, $vN);
    public function get_id_token($g0, $nK, $jV, $vN);
    public function get_resource_owner_from_id_token($Ne);
    public function get_resource_owner($NI, $k_);
    public function get_response($yN);
}
