<?php


namespace MoOauthClient;

use MoOauthClient\OauthHandlerInterface;
class MO_Oauth_Debug
{
    public static function mo_oauth_log($LD)
    {
        global $Uc;
        $tG = plugin_dir_path(__FILE__) . $Uc->mo_oauth_client_get_option("\x6d\x6f\137\x6f\141\165\x74\150\137\x64\145\142\165\x67") . "\x2e\x6c\x6f\147";
        $h1 = time();
        $TX = "\133" . date("\131\x2d\155\55\x64\x20\110\x3a\x69\x3a\x73", $h1) . "\x20\x55\x54\x43\x5d\40\72\x20" . print_r($LD, true) . PHP_EOL;
        if (!$Uc->mo_oauth_client_get_option("\155\x6f\137\144\x65\x62\165\147\137\145\156\x61\142\154\145")) {
            goto UL;
        }
        if ($Uc->mo_oauth_client_get_option("\x6d\157\x5f\144\145\x62\165\x67\x5f\x63\150\x65\x63\x6b")) {
            goto rL;
        }
        error_log($TX, 3, $tG);
        goto qD;
        rL:
        $LD = "\x54\150\x69\163\x20\x69\163\x20\x6d\x69\156\x69\117\x72\141\x6e\147\x65\40\x4f\101\x75\164\x68\x20\x70\x6c\x75\147\x69\x6e\x20\104\145\142\x75\147\x20\x4c\x6f\x67\40\x66\151\x6c\145" . PHP_EOL;
        error_log($LD, 3, $tG);
        qD:
        UL:
    }
}
class OauthHandler implements OauthHandlerInterface
{
    public function get_token($g0, $nK, $jV = true, $vN = false)
    {
        MO_Oauth_Debug::mo_oauth_log("\124\x6f\x6b\x65\x6e\x20\162\x65\x71\x75\x65\x73\164\40\143\x6f\x6e\x74\x65\x6e\x74\40\x3d\76\x20");
        global $Uc;
        $eC = new \WP_Error();
        $xU = isset($nK["\151\163\137\x77\160\137\x6c\x6f\x67\x69\156"]) ? $nK["\x69\163\137\x77\160\137\x6c\157\x67\151\x6e"] : false;
        unset($nK["\151\x73\x5f\167\x70\137\154\x6f\x67\x69\x6e"]);
        foreach ($nK as $LG => $C0) {
            $nK[$LG] = html_entity_decode($C0);
            HQ:
        }
        KA:
        $fd = '';
        if (!isset($nK["\x63\x6c\x69\145\x6e\x74\137\x73\x65\x63\162\145\x74"])) {
            goto v0;
        }
        $fd = $nK["\x63\154\x69\145\x6e\164\137\x73\145\x63\x72\145\164"];
        v0:
        $zd = array("\x41\143\143\145\x70\x74" => "\141\160\x70\154\151\x63\x61\164\151\x6f\x6e\57\152\163\x6f\156", "\x63\x68\x61\x72\x73\x65\164" => "\125\x54\x46\40\55\40\x38", "\x43\x6f\x6e\164\145\156\x74\55\x54\171\x70\145" => "\x61\x70\x70\154\151\x63\141\x74\151\157\156\x2f\170\55\x77\167\x77\x2d\146\x6f\162\x6d\x2d\x75\x72\x6c\145\x6e\x63\157\144\x65\x64", "\x41\165\x74\150\157\x72\151\x7a\x61\x74\151\157\x6e" => "\x42\141\x73\151\143\x20" . base64_encode($nK["\x63\154\x69\145\156\164\x5f\x69\144"] . "\72" . $fd));
        $zd = apply_filters("\x6d\x6f\x5f\157\141\x75\x74\150\x5f\x63\x6f\x75\x73\164\x6f\x6d\137\x65\170\164\145\x6e\144\x5f\164\157\x6b\145\156\145\x6e\x64\160\x6f\151\156\164\x5f\x70\141\x72\141\155\163", $zd);
        if (!(isset($nK["\143\x6f\144\x65\137\166\x65\162\x69\146\x69\145\x72"]) && !isset($nK["\143\154\x69\x65\156\164\137\x73\145\x63\162\145\164"]))) {
            goto t4;
        }
        unset($zd["\101\x75\x74\150\x6f\x72\151\x7a\x61\x74\151\x6f\156"]);
        t4:
        if (1 == $jV && 0 == $vN) {
            goto Yw;
        }
        if (0 == $jV && 1 == $vN) {
            goto PI;
        }
        goto wI;
        Yw:
        unset($nK["\143\154\151\145\x6e\x74\137\x69\x64"]);
        if (!isset($nK["\143\154\x69\145\156\x74\137\x73\145\143\162\x65\164"])) {
            goto hu;
        }
        unset($nK["\x63\x6c\151\145\x6e\164\x5f\x73\x65\143\x72\145\x74"]);
        hu:
        goto wI;
        PI:
        if (!isset($zd["\101\x75\164\x68\157\x72\x69\172\141\164\151\x6f\156"])) {
            goto EH;
        }
        unset($zd["\101\165\x74\x68\157\162\151\x7a\141\164\x69\157\156"]);
        EH:
        wI:
        MO_Oauth_Debug::mo_oauth_log("\124\157\153\x65\x6e\x20\145\156\x64\160\x6f\151\156\x74\40\x55\x52\x4c\x20\75\x3e\40" . $g0);
        $nK = apply_filters("\x6d\x6f\x5f\157\x61\x75\164\150\137\x70\157\154\x61\x72\137\x62\x6f\144\x79\x5f\x61\x72\147\x75\x6d\145\156\164\x73", $nK);
        MO_Oauth_Debug::mo_oauth_log("\x62\x6f\x64\x79\x20\75\x3e");
        MO_Oauth_Debug::mo_oauth_log($nK);
        MO_Oauth_Debug::mo_oauth_log("\x68\x65\x61\144\x65\x72\163\x20\x3d\x3e");
        MO_Oauth_Debug::mo_oauth_log($zd);
        $mj = wp_remote_post($g0, array("\155\145\x74\150\x6f\144" => "\x50\x4f\x53\124", "\164\x69\x6d\145\x6f\x75\164" => 45, "\162\x65\144\x69\x72\145\x63\164\x69\x6f\x6e" => 5, "\x68\164\x74\160\x76\x65\x72\x73\151\157\156" => "\x31\56\60", "\x62\154\x6f\x63\x6b\x69\156\147" => true, "\150\145\141\144\145\162\163" => $zd, "\x62\157\x64\171" => $nK, "\143\x6f\157\153\x69\x65\163" => array(), "\x73\x73\154\166\145\x72\151\146\171" => false));
        if (!is_wp_error($mj)) {
            goto SB;
        }
        $Uc->handle_error($mj->get_error_message());
        MO_Oauth_Debug::mo_oauth_log("\x45\162\x72\157\162\40\146\162\157\x6d\x20\124\x6f\x6b\x65\x6e\40\x45\x6e\144\160\x6f\x69\x6e\x74\72\x20" . $mj->get_error_message());
        wp_die(wp_kses($mj->get_error_message(), \mo_oauth_get_valid_html()));
        exit;
        SB:
        $mj = $mj["\x62\157\x64\171"];
        if (is_array(json_decode($mj, true))) {
            goto Mg;
        }
        $Uc->handle_error("\111\x6e\166\x61\154\x69\144\40\162\145\x73\160\157\x6e\163\145\x20\162\x65\x63\145\x69\x76\x65\144\40\72\x20" . $mj);
        echo "\74\x73\164\x72\157\156\147\x3e\122\145\163\x70\x6f\x6e\x73\x65\40\x3a\40\74\57\x73\164\x72\157\156\147\76\x3c\x62\162\76";
        print_r($mj);
        echo "\x3c\x62\x72\76\74\x62\162\76";
        MO_Oauth_Debug::mo_oauth_log("\105\162\x72\x6f\162\x20\x66\162\157\x6d\40\124\157\x6b\145\156\x20\x45\156\144\x70\157\x69\156\x74\x3d\x3e\40\x49\156\x76\141\x6c\151\x64\x20\122\x65\x73\160\x6f\x6e\163\145\x20\x72\x65\143\145\x69\x76\145\144\56" . $mj);
        exit("\111\156\166\x61\x6c\151\x64\x20\162\145\163\160\x6f\x6e\163\x65\40\162\x65\143\x65\151\166\x65\x64\x2e");
        Mg:
        $ki = json_decode($mj, true);
        if (isset($ki["\145\162\162\157\x72\x5f\144\x65\163\143\162\x69\160\164\x69\x6f\x6e"])) {
            goto BU;
        }
        if (isset($ki["\x65\x72\x72\x6f\x72"])) {
            goto zE;
        }
        goto dP;
        BU:
        do_action("\155\157\137\162\145\x64\x69\x72\145\143\x74\x5f\x74\x6f\137\x63\165\x73\x74\157\155\137\x65\162\162\x6f\x72\x5f\x70\x61\147\145");
        if (!($nK["\147\162\141\x6e\164\137\x74\x79\160\x65"] == "\x70\x61\x73\163\167\157\x72\x64" && $xU)) {
            goto x2;
        }
        $eC->add("\155\x6f\x5f\157\141\x75\x74\150\x5f\151\144\160\x5f\x65\162\162\157\x72", __("\x3c\x73\164\x72\x6f\x6e\147\x3e\x45\x52\122\117\122\74\x2f\x73\x74\162\157\x6e\x67\76\72\x20" . $ki["\145\x72\162\x6f\162\137\x64\145\163\x63\162\151\x70\164\151\x6f\156"]));
        return $eC;
        x2:
        $Uc->handle_error($ki["\145\162\x72\x6f\x72\137\144\145\163\143\162\x69\x70\164\151\x6f\156"]);
        $this->handle_error(json_encode($ki["\x65\x72\162\x6f\162\137\x64\x65\163\x63\x72\151\x70\164\151\157\156"]), $nK);
        return;
        goto dP;
        zE:
        do_action("\155\x6f\x5f\x72\x65\x64\151\162\145\x63\164\137\x74\x6f\137\x63\165\x73\x74\x6f\155\137\145\162\162\x6f\162\137\160\141\x67\x65");
        if (!($nK["\x67\x72\141\156\x74\137\x74\171\x70\145"] == "\160\x61\163\x73\x77\x6f\162\x64" && $xU)) {
            goto Oo;
        }
        $eC->add("\155\x6f\137\157\x61\165\x74\x68\137\x69\x64\160\x5f\x65\x72\x72\157\162", __("\74\163\164\x72\x6f\156\147\76\105\122\x52\x4f\x52\74\57\163\164\162\x6f\x6e\x67\x3e\72\40" . $ki["\x65\x72\162\x6f\x72"]));
        return $eC;
        Oo:
        $Uc->handle_error($ki["\x65\x72\162\157\162"]);
        $this->handle_error(json_encode($ki["\x65\x72\x72\x6f\x72"]), $nK);
        return;
        dP:
        return $mj;
    }
    public function get_atoken($g0, $nK, $bw, $jV = true, $vN = false)
    {
        global $Uc;
        foreach ($nK as $LG => $C0) {
            $nK[$LG] = html_entity_decode($C0);
            Wt:
        }
        eL:
        $fd = '';
        if (!isset($nK["\x63\154\151\x65\156\164\137\x73\145\x63\162\145\x74"])) {
            goto Zt;
        }
        $fd = $nK["\x63\x6c\x69\145\156\164\x5f\163\145\143\162\x65\164"];
        Zt:
        $FO = $nK["\x63\154\151\145\156\x74\x5f\x69\x64"];
        $zd = array("\x41\x63\x63\145\160\x74" => "\x61\x70\x70\154\x69\143\x61\164\151\x6f\x6e\x2f\x6a\163\x6f\x6e", "\143\x68\141\x72\x73\x65\164" => "\x55\124\106\40\x2d\x20\x38", "\103\x6f\x6e\x74\x65\156\x74\55\124\171\x70\145" => "\x61\x70\160\x6c\151\x63\x61\164\151\x6f\156\x2f\170\55\x77\167\167\x2d\x66\x6f\162\x6d\x2d\x75\x72\x6c\x65\x6e\x63\157\x64\145\x64", "\x41\165\x74\150\157\x72\151\172\x61\164\151\157\x6e" => "\102\141\x73\151\143\x20" . base64_encode($FO . "\x3a" . $fd));
        $zd = apply_filters("\x6d\157\137\x6f\141\x75\164\150\x5f\x63\157\x75\x73\164\x6f\155\137\145\170\164\x65\156\144\x5f\x74\157\x6b\x65\156\145\156\x64\x70\157\151\x6e\164\x5f\160\141\x72\141\x6d\x73", $zd);
        if (!isset($nK["\x63\157\x64\145\x5f\x76\145\x72\x69\x66\151\x65\162"])) {
            goto ns;
        }
        unset($zd["\101\165\164\x68\157\162\x69\x7a\x61\x74\x69\x6f\156"]);
        ns:
        if (1 === $jV && 0 === $vN) {
            goto dp;
        }
        if (0 === $jV && 1 === $vN) {
            goto IM;
        }
        goto xF;
        dp:
        unset($nK["\x63\154\x69\x65\156\164\137\151\144"]);
        if (!isset($nK["\143\x6c\x69\145\x6e\164\x5f\x73\145\x63\x72\x65\x74"])) {
            goto IK;
        }
        unset($nK["\x63\154\x69\x65\156\x74\x5f\x73\x65\x63\162\x65\x74"]);
        IK:
        goto xF;
        IM:
        if (!isset($zd["\101\165\x74\x68\x6f\x72\151\x7a\141\164\x69\x6f\x6e"])) {
            goto xf;
        }
        unset($zd["\101\165\x74\x68\157\x72\x69\172\141\x74\x69\x6f\156"]);
        xf:
        xF:
        $pn = curl_init($g0);
        curl_setopt($pn, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($pn, CURLOPT_ENCODING, '');
        curl_setopt($pn, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($pn, CURLOPT_AUTOREFERER, true);
        curl_setopt($pn, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($pn, CURLOPT_MAXREDIRS, 10);
        curl_setopt($pn, CURLOPT_POST, true);
        curl_setopt($pn, CURLOPT_HTTPHEADER, array("\101\165\x74\150\157\162\151\x7a\141\164\x69\x6f\x6e\72\x20\102\x61\x73\151\x63\40" . base64_encode($FO . "\72" . $fd), "\x41\x63\143\145\160\164\x3a\40\x61\160\160\154\151\x63\141\164\x69\157\156\57\152\163\x6f\x6e"));
        curl_setopt($pn, CURLOPT_POSTFIELDS, "\x72\145\x64\x69\x72\x65\x63\164\x5f\x75\x72\x69\75" . $nK["\x72\145\x64\151\x72\145\x63\164\137\x75\x72\x69"] . "\x26\x67\162\x61\x6e\x74\137\x74\171\x70\x65\x3d" . "\x61\165\x74\x68\157\162\151\172\141\x74\151\157\156\137\x63\157\144\x65" . "\x26\x63\x6c\151\x65\x6e\x74\x5f\x69\144\75" . $FO . "\x26\x63\154\x69\145\x6e\x74\x5f\x73\145\143\162\x65\164\75" . $fd . "\46\x63\x6f\x64\x65\x3d" . $bw);
        $ki = curl_exec($pn);
        if (!curl_error($pn)) {
            goto tS;
        }
        echo "\x3c\x62\76\x52\x65\163\160\157\x6e\x73\x65\x20\72\40\x3c\57\x62\76\74\x62\162\x3e";
        print_r($ki);
        echo "\x3c\x62\x72\76\74\142\162\76";
        MO_Oauth_Debug::mo_oauth_log(curl_error($pn));
        exit(curl_error($pn));
        tS:
        if (isset($ki["\x65\x72\x72\157\162\x5f\x64\x65\163\x63\x72\x69\x70\164\151\x6f\156"])) {
            goto GU;
        }
        if (isset($ki["\x65\x72\162\157\x72"])) {
            goto QS;
        }
        if (!isset($ki["\141\143\143\x65\x73\163\x5f\x74\x6f\153\145\x6e"])) {
            goto tu;
        }
        $k_ = $ki["\x61\143\x63\x65\x73\163\137\164\157\153\x65\156"];
        tu:
        goto po;
        QS:
        $y2 = "\x45\162\162\x6f\x72\x20\146\162\x6f\x6d\x20\124\x6f\153\x65\x6e\x20\x45\156\x64\160\157\x69\x6e\x74\x3a\40" . $ki["\x65\x72\x72\157\162"];
        MO_Oauth_Debug::mo_oauth_log($y2);
        do_action("\155\x6f\137\162\145\x64\151\162\x65\x63\x74\x5f\x74\x6f\137\x63\165\x73\x74\x6f\x6d\137\145\162\162\157\162\x5f\x70\141\x67\145");
        exit($ki["\x65\162\x72\157\x72\137\144\145\163\143\162\x69\x70\164\151\157\156"]);
        po:
        goto Cp;
        GU:
        $y2 = "\x45\162\x72\x6f\x72\40\x66\x72\x6f\x6d\40\x54\x6f\x6b\145\x6e\40\105\x6e\x64\x70\157\151\x6e\x74\72\40" . $ki["\x65\162\162\157\162\x5f\144\x65\163\143\162\151\160\x74\x69\x6f\x6e"];
        MO_Oauth_Debug::mo_oauth_log($y2);
        do_action("\155\x6f\137\162\x65\x64\x69\162\145\143\x74\137\x74\x6f\137\x63\x75\163\164\x6f\x6d\x5f\x65\162\x72\x6f\162\x5f\x70\x61\147\145");
        exit($ki["\x65\x72\x72\x6f\162\x5f\x64\x65\x73\143\x72\151\x70\x74\x69\x6f\x6e"]);
        Cp:
        return $ki;
    }
    public function get_access_token($g0, $nK, $jV, $vN)
    {
        global $Uc;
        $mj = $this->get_token($g0, $nK, $jV, $vN);
        if (!is_wp_error($mj)) {
            goto Io;
        }
        return $mj;
        Io:
        $ki = json_decode($mj, true);
        if (!("\160\x61\x73\163\x77\x6f\162\x64" === $nK["\147\x72\x61\156\x74\x5f\x74\171\160\145"])) {
            goto Zu;
        }
        return $ki;
        Zu:
        if (isset($ki["\141\143\143\x65\x73\x73\x5f\164\x6f\153\145\x6e"])) {
            goto v5;
        }
        $eC = "\111\x6e\x76\141\x6c\x69\144\40\x72\x65\163\160\x6f\x6e\x73\145\40\162\x65\x63\145\151\x76\145\x64\x20\x66\x72\x6f\x6d\x20\x4f\101\x75\164\x68\40\x50\162\157\x76\151\x64\145\x72\x2e\x20\x43\157\x6e\164\141\x63\164\40\171\157\x75\x72\x20\141\x64\x6d\x69\156\x69\163\164\x72\x61\164\157\162\x20\146\157\162\40\x6d\157\x72\145\x20\144\x65\164\x61\151\x6c\x73\x2e\x3c\142\x72\76\x3c\142\x72\x3e\74\x73\x74\162\x6f\x6e\x67\x3e\122\x65\163\160\157\x6e\x73\145\x20\72\40\74\57\x73\x74\x72\157\156\147\76\x3c\x62\162\x3e" . $mj;
        $Uc->handle_error($eC);
        MO_Oauth_Debug::mo_oauth_log("\x45\162\x72\157\162\x20\x77\x68\x69\154\145\x20\146\x65\164\143\x68\151\156\147\x20\x74\x6f\x6b\x65\156\x3a\40" . $eC);
        echo $eC;
        exit;
        goto Z6;
        v5:
        return $ki["\141\x63\x63\145\x73\163\137\x74\157\153\x65\x6e"];
        Z6:
    }
    public function get_id_token($g0, $nK, $jV, $vN)
    {
        global $Uc;
        $mj = $this->get_token($g0, $nK, $jV, $vN);
        $ki = json_decode($mj, true);
        if (isset($ki["\x69\x64\x5f\164\157\153\x65\156"])) {
            goto zI;
        }
        $eC = "\111\x6e\x76\141\x6c\x69\x64\x20\162\x65\x73\160\x6f\156\163\x65\x20\x72\145\143\x65\151\166\145\x64\40\x66\162\157\x6d\x20\x4f\160\145\156\x49\144\x20\120\x72\x6f\x76\151\x64\x65\x72\56\40\x43\x6f\156\x74\141\x63\x74\40\x79\x6f\165\x72\x20\x61\x64\x6d\151\156\151\x73\x74\x72\x61\x74\x6f\x72\x20\x66\x6f\162\x20\155\157\162\x65\40\x64\x65\x74\141\151\x6c\163\x2e\x3c\142\162\76\x3c\142\162\x3e\x3c\163\164\162\x6f\x6e\147\x3e\122\145\x73\x70\x6f\156\x73\x65\40\x3a\40\x3c\57\x73\164\x72\x6f\x6e\147\x3e\x3c\x62\x72\76" . $mj;
        $Uc->handle_error($eC);
        MO_Oauth_Debug::mo_oauth_log("\105\x72\162\157\x72\40\167\x68\x69\x6c\x65\40\146\x65\164\143\150\151\156\147\x20\151\144\x5f\164\157\153\145\x6e\72\x20" . $eC);
        echo $eC;
        exit;
        goto o7;
        zI:
        return $ki;
        o7:
    }
    public function get_resource_owner_from_id_token($Ne)
    {
        global $Uc;
        $vV = explode("\56", $Ne);
        if (!isset($vV[1])) {
            goto ap;
        }
        $DF = $Uc->base64url_decode($vV[1]);
        if (!is_array(json_decode($DF, true))) {
            goto CQ;
        }
        return json_decode($DF, true);
        CQ:
        ap:
        $eC = "\x49\x6e\x76\141\x6c\151\144\40\x72\145\x73\x70\x6f\156\163\x65\x20\x72\x65\x63\x65\151\166\145\x64\56\74\x62\162\76\74\x73\164\162\157\x6e\147\76\151\x64\137\x74\157\x6b\x65\x6e\x20\x3a\40\74\x2f\163\164\x72\157\156\147\76" . $Ne;
        $Uc->handle_error($eC);
        MO_Oauth_Debug::mo_oauth_log("\x45\x72\x72\x6f\x72\x20\167\150\x69\154\145\x20\146\x65\164\143\150\x69\156\x67\x20\162\x65\x73\x6f\165\x72\x63\145\x20\x6f\x77\156\x65\162\40\x66\x72\x6f\x6d\40\151\x64\40\164\x6f\153\x65\156\72" . $eC);
        echo $eC;
        exit;
    }
    public function get_resource_owner($NI, $k_)
    {
        global $Uc;
        $zd = array();
        $zd["\101\x75\x74\150\x6f\162\x69\x7a\141\164\151\x6f\156"] = "\x42\x65\x61\x72\145\162\40" . $k_;
        $zd = apply_filters("\x6d\x6f\x5f\x65\x78\164\145\x6e\144\137\165\x73\x65\x72\x69\x6e\146\x6f\137\160\141\x72\141\x6d\x73", $zd, $NI);
        MO_Oauth_Debug::mo_oauth_log("\x52\145\163\157\165\x72\143\145\40\117\x77\x6e\x65\162\40\x45\x6e\x64\160\157\151\x6e\164\x20\75\76\40" . $NI);
        MO_Oauth_Debug::mo_oauth_log("\x52\145\163\157\165\162\x63\145\x20\x4f\167\156\145\162\40\162\x65\x71\x75\145\163\x74\40\143\x6f\x6e\164\x65\156\x74\x20\x3d\76\40");
        MO_Oauth_Debug::mo_oauth_log("\x68\x65\141\x64\x65\162\163\40\75\76");
        MO_Oauth_Debug::mo_oauth_log($zd);
        $NI = apply_filters("\155\x6f\137\157\x61\x75\x74\150\137\x75\x73\x65\x72\x69\x6e\146\x6f\x5f\151\x6e\164\145\x72\156\141\154", $NI);
        $mj = wp_remote_post($NI, array("\155\145\x74\150\157\x64" => "\107\105\124", "\x74\151\x6d\x65\x6f\x75\x74" => 45, "\x72\x65\x64\151\162\145\x63\x74\151\x6f\156" => 5, "\150\164\x74\160\166\x65\162\x73\151\157\x6e" => "\61\x2e\60", "\142\x6c\x6f\x63\153\x69\156\147" => true, "\150\x65\x61\x64\145\x72\x73" => $zd, "\143\x6f\157\153\x69\145\x73" => array(), "\163\163\x6c\x76\145\162\x69\x66\171" => false));
        if (!is_wp_error($mj)) {
            goto iY;
        }
        $Uc->handle_error($mj->get_error_message());
        MO_Oauth_Debug::mo_oauth_log("\x45\x72\162\x6f\162\40\x66\162\x6f\x6d\x20\x52\x65\x73\157\x75\x72\x63\145\40\x45\156\x64\x70\157\x69\156\164\x3a\40" . $mj->get_error_message());
        wp_die(wp_kses($mj->get_error_message(), \mo_oauth_get_valid_html()));
        exit;
        iY:
        $mj = $mj["\x62\157\144\x79"];
        if (is_array(json_decode($mj, true))) {
            goto De;
        }
        $Uc->handle_error("\111\156\x76\141\x6c\151\144\40\162\145\x73\x70\157\156\x73\145\x20\x72\x65\143\x65\x69\166\145\x64\40\72\x20" . $mj);
        echo "\x3c\163\x74\x72\x6f\x6e\147\76\122\145\163\160\157\x6e\x73\x65\x20\72\40\74\x2f\163\x74\x72\x6f\156\147\x3e\x3c\142\162\x3e";
        print_r($mj);
        echo "\74\142\x72\76\x3c\142\x72\76";
        MO_Oauth_Debug::mo_oauth_log("\111\x6e\x76\141\154\151\x64\40\x72\145\x73\160\157\156\163\x65\40\162\145\143\151\145\x76\145\144\40\167\x68\x69\x6c\145\x20\x66\x65\164\143\150\151\x6e\x67\x20\162\145\163\157\165\x72\143\145\x20\x6f\x77\156\x65\162\x20\x64\145\x74\141\x69\x6c\x73");
        exit("\111\156\x76\x61\154\151\x64\x20\x72\145\x73\160\157\156\x73\145\40\162\145\143\x65\151\166\145\144\56");
        De:
        $ki = json_decode($mj, true);
        if (!(strpos($NI, "\141\x70\151\56\x63\x6c\x65\166\x65\162\x2e\143\157\155") != false && isset($ki["\154\151\156\x6b\x73"][1]["\x75\x72\151"]) && strpos($NI, $ki["\154\151\x6e\153\163"][1]["\165\x72\151"]) === false)) {
            goto WG;
        }
        $X6 = $ki["\x6c\151\x6e\x6b\x73"][1]["\x75\162\x69"];
        $xZ = "\150\164\x74\x70\163\x3a\x2f\57\x61\x70\151\56\143\154\x65\166\x65\162\56\143\x6f\155" . $X6;
        $Uc->mo_oauth_client_update_option("\x6d\157\x5f\157\x61\x75\x74\150\137\x63\154\151\x65\x6e\x74\137\143\x6c\145\166\145\162\x5f\165\x73\145\162\x5f\x61\160\151", $xZ);
        $ki = $this->get_resource_owner($xZ, $k_);
        WG:
        if (isset($ki["\x65\162\162\x6f\x72\x5f\x64\145\x73\143\162\x69\x70\164\x69\157\156"])) {
            goto Zw;
        }
        if (isset($ki["\145\x72\162\157\x72"])) {
            goto Cr;
        }
        goto a_;
        Zw:
        $y2 = "\105\162\162\157\162\40\x66\x72\x6f\x6d\40\x52\145\x73\157\165\x72\x63\x65\x20\105\156\144\160\157\x69\156\x74\72\40" . $ki["\x65\x72\x72\157\162\137\x64\145\163\x63\162\151\160\164\151\157\156"];
        $Uc->handle_error($ki["\145\x72\x72\x6f\x72\x5f\144\145\x73\x63\x72\151\x70\x74\151\157\x6e"]);
        MO_Oauth_Debug::mo_oauth_log($y2);
        do_action("\155\157\137\162\145\x64\151\162\x65\x63\x74\137\x74\x6f\x5f\143\165\163\x74\x6f\155\137\145\162\162\157\162\137\160\141\147\x65");
        exit(json_encode($ki["\x65\x72\162\157\x72\137\144\x65\x73\x63\x72\151\x70\164\151\157\x6e"]));
        goto a_;
        Cr:
        $y2 = "\105\x72\x72\x6f\x72\x20\146\162\x6f\155\x20\x52\145\163\157\165\x72\x63\x65\40\x45\156\144\160\157\151\x6e\x74\x3a\x20" . $ki["\x65\162\x72\157\162"];
        $Uc->handle_error($ki["\x65\162\162\157\162"]);
        MO_Oauth_Debug::mo_oauth_log($y2);
        do_action("\x6d\157\x5f\162\145\144\151\162\x65\143\164\137\164\157\x5f\143\165\163\x74\x6f\x6d\137\x65\x72\x72\x6f\162\x5f\x70\x61\147\145");
        exit(json_encode($ki["\145\162\162\x6f\162"]));
        a_:
        return $ki;
    }
    public function get_response($yN)
    {
        $mj = wp_remote_get($yN, array("\x6d\145\x74\150\x6f\144" => "\107\105\x54", "\x74\151\x6d\145\157\x75\164" => 45, "\x72\x65\x64\151\162\145\143\x74\151\x6f\x6e" => 5, "\x68\x74\x74\160\166\145\x72\x73\151\x6f\156" => 1.0, "\142\154\x6f\143\x6b\x69\x6e\x67" => true, "\150\x65\x61\144\x65\162\x73" => array(), "\143\157\x6f\153\151\x65\163" => array(), "\163\x73\154\x76\x65\x72\151\146\x79" => false));
        if (!is_wp_error($mj)) {
            goto hW;
        }
        MO_Oauth_Debug::mo_oauth_log($mj->get_error_message());
        wp_die(wp_kses($mj->get_error_message(), \mo_oauth_get_valid_html()));
        exit;
        hW:
        $mj = $mj["\x62\x6f\144\x79"];
        $ki = json_decode($mj, true);
        if (isset($ki["\x65\x72\162\157\x72\137\144\x65\x73\143\x72\x69\x70\x74\151\157\x6e"])) {
            goto yC;
        }
        if (isset($ki["\x65\x72\x72\x6f\x72"])) {
            goto W0;
        }
        goto SK;
        yC:
        $Uc->handle_error($ki["\x65\x72\x72\157\162\137\144\x65\163\143\x72\x69\160\x74\x69\x6f\x6e"]);
        MO_Oauth_Debug::mo_oauth_log($y2);
        do_action("\155\x6f\137\162\145\x64\151\x72\x65\143\164\x5f\164\157\137\x63\165\x73\x74\x6f\155\137\145\x72\162\157\x72\137\160\141\147\145");
        goto SK;
        W0:
        $Uc->handle_error($ki["\145\162\x72\x6f\x72"]);
        MO_Oauth_Debug::mo_oauth_log($y2);
        do_action("\155\157\x5f\x72\x65\144\x69\162\145\143\164\137\164\x6f\x5f\143\x75\163\x74\157\155\137\x65\162\162\157\x72\x5f\x70\x61\147\x65");
        SK:
        return $ki;
    }
    private function handle_error($eC, $nK)
    {
        global $Uc;
        if (!($nK["\147\x72\141\x6e\x74\137\164\171\160\x65"] === "\x70\141\x73\x73\x77\x6f\x72\144")) {
            goto Ox;
        }
        $Ro = $Uc->get_current_url();
        $Ro = apply_filters("\x6d\157\137\157\x61\165\164\150\x5f\x77\157\x6f\x63\157\155\x6d\145\162\x63\145\x5f\x63\150\145\x63\x6b\157\x75\164\137\143\x6f\155\160\141\164\151\142\x69\154\x69\164\171", $Ro);
        if ($Ro != '') {
            goto Ih;
        }
        return;
        goto ms;
        Ih:
        $Ro = "\x3f\x6f\160\x74\151\157\x6e\x3d\145\x72\x72\x6f\162\155\x61\x6e\141\x67\x65\x72\x26\x65\x72\x72\157\x72\x3d" . \base64_encode($eC);
        MO_Oauth_Debug::mo_oauth_log("\105\162\162\x6f\x72\72\x20" . $eC);
        wp_die($eC);
        exit;
        ms:
        Ox:
        MO_Oauth_Debug::mo_oauth_log("\x45\x72\162\x6f\162\72\40" . $eC);
        exit($eC);
    }
}
