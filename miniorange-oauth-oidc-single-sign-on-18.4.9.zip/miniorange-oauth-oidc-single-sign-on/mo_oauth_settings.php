<?php
/**
 * Plugin Name: OAuth Single Sign On - SSO (OAuth client)
 * Plugin URI: http://miniorange.com
 * Description: This plugin enables login to your WordPress site using OAuth apps like Google, Facebook, EVE Online and other.
 * Version: 18.4.9
 * Author: miniOrange
 * Author URI: https://www.miniorange.com
 * License: miniOrange
 */


require "\x5f\x61\165\x74\157\x6c\157\141\x64\x2e\160\150\160";
require_once "\x6d\x6f\x2d\x6f\x61\x75\x74\x68\x2d\143\154\151\145\x6e\164\x2d\x70\154\x75\147\x69\x6e\x2d\x76\x65\x72\163\151\x6f\x6e\55\x75\x70\144\141\x74\x65\x2e\x70\x68\x70";
use MoOauthClient\Base\BaseStructure;
use MoOauthClient\MOUtils;
use MoOauthClient\GrantTypes\JWTUtils;
use MoOauthClient\Base\InstanceHelper;
use MoOauthClient\MoOauthClientWidget;
use MoOauthClient\Free\MOCVisualTour;
use MoOauthClient\Free\CustomizationSettings;
global $Uc;
$f5 = new InstanceHelper();
$Uc = $f5->get_utils_instance();
$K9 = $Uc->get_plugin_config()->get_current_config();
$SF = $f5->get_settings_instance();
$ea = new BaseStructure();
$nd = $f5->get_login_handler_instance();
$hD = new CustomizationSettings();
$hD = $hD->mo_oauth_custom_icons_intiater();
function register_mo_oauth_widget()
{
    register_widget("\x5c\115\x6f\x4f\141\165\x74\x68\x43\154\151\x65\156\164\x5c\x4d\x6f\x4f\141\165\164\150\x43\x6c\x69\145\x6e\164\x57\x69\144\147\145\x74");
}
function mo_oauth_shortcode_login($R9)
{
    global $Uc;
    $pb = new MoOauthClientWidget();
    if ($Uc->check_versi(4) && $Uc->mo_oauth_client_get_option("\x6d\157\x5f\157\x61\x75\164\150\x5f\x61\143\x74\151\x76\141\x74\145\x5f\x73\151\x6e\x67\x6c\x65\137\154\157\x67\151\156\x5f\146\x6c\157\x77")) {
        goto Hi;
    }
    if (empty($R9["\162\145\x64\x69\x72\145\x63\x74\x5f\165\x72\154"])) {
        goto Eo;
    }
    return $R9 && isset($R9["\141\160\x70\x6e\x61\x6d\145"]) && !empty($R9["\x61\x70\160\x6e\141\155\145"]) ? $pb->mo_oauth_login_form($Fo = true, $O_ = $R9["\141\160\160\156\x61\x6d\x65"], $Ro = $R9["\162\x65\144\x69\x72\x65\x63\164\137\x75\x72\154"]) : $pb->mo_oauth_login_form($Fo = false, $O_ = '', $Ro = $R9["\x72\145\x64\x69\x72\145\143\x74\137\165\162\154"]);
    Eo:
    return $R9 && isset($R9["\x61\160\x70\x6e\x61\155\145"]) && !empty($R9["\141\160\160\x6e\141\155\145"]) ? $pb->mo_oauth_login_form($Fo = true, $O_ = $R9["\x61\x70\160\x6e\141\x6d\145"]) : $pb->mo_oauth_login_form(false);
    goto hh;
    Hi:
    return $pb->mo_activate_single_login_flow_form();
    hh:
}
add_action("\167\x69\144\147\145\164\163\x5f\x69\x6e\x69\164", "\x72\x65\147\151\163\x74\145\162\137\x6d\x6f\x5f\157\x61\165\x74\x68\x5f\167\x69\144\147\145\x74");
add_shortcode("\155\157\137\x6f\x61\x75\164\150\x5f\x6c\x6f\x67\151\x6e", "\155\157\x5f\x6f\x61\165\x74\150\x5f\163\x68\x6f\x72\164\x63\157\x64\x65\137\x6c\x6f\x67\151\x6e");
add_action("\x69\156\151\x74", "\155\157\x5f\147\x65\164\137\x76\x65\x72\x73\x69\x6f\156\137\156\165\155\142\x65\x72");
add_action("\151\x6e\x69\164", "\155\x6f\x5f\157\x61\165\x74\150\x5f\x66\162\x6f\x6e\164\163\x6c\157");
add_action("\151\x6e\151\164", "\x6d\157\137\157\x61\x75\x74\x68\x5f\x62\x61\x63\153\163\154\x6f");
function mo_get_version_number()
{
    if (!(isset($_GET["\x61\x63\x74\151\x6f\x6e"]) && $_GET["\141\143\164\151\157\156"] === "\x6d\157\x5f\x76\x65\162\163\x69\x6f\156\137\156\x75\155\x62\145\162" && isset($_GET["\x61\x70\151\x4b\145\x79"]) && $_GET["\141\160\151\x4b\x65\x79"] === "\x63\62\x30\x61\67\x64\146\x38\x36\142\x33\x64\64\144\61\141\x62\x65\x32\x64\64\67\144\60\145\61\142\x31\x66\70\64\x37")) {
        goto a8;
    }
    echo mo_oauth_client_options_plugin_constants::Version;
    exit;
    a8:
}
function mo_oauth_frontslo()
{
    $Uc = new MOUtils();
    if (!($Uc->check_versi(4) && isset($_SERVER["\x52\105\121\x55\x45\123\124\x5f\x55\x52\111"]) && sanitize_url($_SERVER["\x52\105\121\125\105\x53\x54\x5f\125\x52\x49"]) != NULL && strpos(sanitize_url($_SERVER["\122\105\x51\125\105\123\124\x5f\125\122\x49"]), "\146\x72\157\156\x74\143\x68\141\156\156\x65\x6c\x5f\x6c\157\x67\157\165\x74") != false)) {
        goto Ms;
    }
    $KK = get_current_user_id();
    $Ne = get_user_meta($KK, "\x6d\157\137\x6f\x61\x75\164\x68\x5f\x63\x6c\151\145\156\x74\137\x6c\x61\x73\164\x5f\x69\144\137\164\x6f\x6b\145\156", true);
    $p1 = new JWTUtils($Ne);
    $hF = $p1->get_decoded_payload();
    $yN = sanitize_url($_SERVER["\x52\x45\121\x55\105\x53\124\x5f\x55\122\111"]);
    $H2 = parse_url($yN);
    parse_str($H2["\161\165\145\x72\171"], $w0);
    $e2 = $hF["\x73\151\144"];
    $VT = $w0["\163\151\144"];
    if ($e2 === $VT) {
        goto UU;
    }
    $mj = array("\143\x6f\x64\x65" => 400, "\x64\145\x73\143\x72\x69\160\164\151\x6f\156" => "\x55\163\x65\x72\40\x49\144\x20\x6e\157\x74\x20\x66\x6f\x75\x6e\144");
    wp_send_json($mj, 400);
    goto Fp;
    UU:
    $pC = '';
    if (!isset($hF["\151\x61\164"])) {
        goto I3;
    }
    $pC = $hF["\151\x61\164"];
    I3:
    if (!is_user_logged_in()) {
        goto Wd;
    }
    mo_slo_logout_user($KK);
    Wd:
    Fp:
    Ms:
}
function mo_oauth_backslo()
{
    $Uc = new MOUtils();
    if (!($Uc->check_versi(4) && isset($_SERVER["\x52\x45\121\125\105\x53\x54\137\125\x52\x49"]) && sanitize_url($_SERVER["\122\105\121\125\105\123\124\x5f\125\x52\111"]) != NULL && strpos(sanitize_url($_SERVER["\x52\105\x51\x55\x45\x53\124\137\125\x52\111"]), "\142\141\143\x6b\x63\x68\141\x6e\x6e\x65\154\137\154\x6f\x67\157\165\164") != false)) {
        goto Qy;
    }
    $ae = file_get_contents("\x70\150\x70\x3a\x2f\x2f\x69\156\160\x75\164");
    $bt = explode("\x3d", $ae);
    if (!(json_last_error() !== JSON_ERROR_NONE)) {
        goto mR;
    }
    $ae = array_map("\x65\163\143\137\141\164\164\x72", sanitize_post($_POST));
    mR:
    if ($bt[0] == "\154\157\x67\x6f\x75\164\x5f\164\157\x6b\145\x6e") {
        goto D3;
    }
    $mj = array("\143\x6f\x64\145" => 400, "\144\145\163\x63\x72\151\x70\x74\151\157\x6e" => "\x54\150\x65\40\x4c\x6f\147\x6f\x75\x74\40\164\x6f\x6b\145\156\40\x69\x73\x20\145\151\164\x68\x65\x72\x20\x6e\x6f\164\40\163\145\x6e\x74\x20\157\x72\x20\163\145\x6e\164\x20\x69\156\x63\x6f\x72\x72\145\143\164\154\x79\56");
    wp_send_json($mj, 400);
    goto SI;
    D3:
    $Wa = $bt[1];
    $p1 = new JWTUtils($Wa);
    $og = isset($_REQUEST["\141\x70\160\x6e\141\155\x65"]) && sanitize_text_field($_REQUEST["\141\160\160\x6e\141\x6d\145"]) != NULL ? sanitize_text_field($_REQUEST["\x61\160\160\x6e\x61\x6d\145"]) : '';
    $aT = false;
    $Ts = $Uc->get_app_by_name($og);
    $aT = $Ts->get_app_config("\152\167\153\x73\165\162\154");
    $Kz = $Ts->get_app_config("\x75\x73\145\x72\x6e\141\155\145\137\x61\x74\x74\x72");
    $hF = $p1->get_decoded_payload();
    $kZ = '';
    $e2 = '';
    if (!isset($hF["\163\x75\x62"])) {
        goto TR;
    }
    $kZ = $hF["\x73\165\x62"];
    TR:
    if (!isset($hF["\x73\151\144"])) {
        goto DZ;
    }
    $e2 = $hF["\x73\x69\x64"];
    DZ:
    $pC = '';
    if (!isset($hF["\151\x61\164"])) {
        goto HJ;
    }
    $pC = $hF["\151\x61\164"];
    HJ:
    global $wpdb;
    if (isset($hF[$Kz])) {
        goto gD;
    }
    if ($kZ) {
        goto DJ;
    }
    if ($e2) {
        goto wf;
    }
    $mj = array("\x63\157\x64\x65" => 400, "\144\x65\x73\x63\x72\x69\160\164\x69\157\x6e" => "\x54\x68\145\40\154\x6f\147\157\165\x74\x20\164\157\153\x65\x6e\x20\151\163\x20\x76\x61\154\151\144\x20\x62\165\164\40\165\x73\x65\162\x20\x6e\x6f\164\x20\x69\144\x65\156\164\x69\146\151\x65\144\56");
    wp_send_json($mj, 400);
    goto Y2;
    wf:
    $Iu = "\123\105\114\105\x43\x54\40\x75\163\x65\162\x5f\151\144\40\106\122\x4f\115\x20\x60\167\x70\137\x75\163\145\162\x6d\x65\x74\141\140\x20\x57\110\105\x52\105\40\155\x65\164\x61\137\x76\141\154\x75\x65\75\47{$e2}\47\x20\141\156\144\x20\155\x65\x74\141\137\153\145\171\75\47\x6d\157\137\x62\x61\143\x6b\x63\x68\141\x6e\x6e\x65\154\137\x61\164\164\x72\x5f\x73\x69\144\x27\73";
    $R8 = $wpdb->get_results($Iu);
    $KK = $R8[0]->{"\x75\x73\x65\x72\137\x69\x64"};
    Y2:
    goto tB;
    DJ:
    $Iu = "\123\105\x4c\x45\103\124\40\165\163\x65\x72\x5f\151\x64\x20\x46\x52\117\x4d\x20\x60\x77\x70\137\165\163\x65\162\155\x65\164\141\140\40\127\x48\x45\122\105\40\155\x65\164\141\137\x76\x61\154\x75\x65\x3d\47{$kZ}\x27\x20\141\156\x64\x20\155\145\164\141\x5f\153\145\x79\75\47\x6d\157\x5f\x62\141\x63\x6b\143\150\141\156\x6e\145\x6c\137\x61\164\x74\162\x5f\163\165\x62\x27\x3b";
    $R8 = $wpdb->get_results($Iu);
    $KK = $R8[0]->{"\165\163\145\x72\x5f\x69\144"};
    tB:
    goto YB;
    gD:
    $KK = get_user_by("\154\x6f\147\x69\x6e", $w5)->ID;
    YB:
    if ($KK) {
        goto Um;
    }
    $mj = array("\x63\157\x64\145" => 400, "\144\x65\163\143\162\151\160\x74\x69\157\156" => "\124\x68\145\40\x6c\157\147\157\x75\x74\40\x74\157\x6b\x65\156\40\x69\163\40\x76\x61\x6c\151\144\x20\142\165\x74\x20\x75\163\x65\162\40\156\157\164\40\x69\x64\145\156\x74\x69\x66\151\x65\144\x2e");
    wp_send_json($mj, 400);
    goto sl;
    Um:
    mo_slo_logout_user($KK);
    sl:
    SI:
    Qy:
}
function mo_slo_logout_user($KK)
{
    $Rb = WP_Session_Tokens::get_instance($KK);
    $Rb->destroy_all();
    $mj = array("\143\157\x64\x65" => 200, "\x64\145\163\143\162\x69\x70\164\151\x6f\x6e" => "\124\150\145\x20\125\163\x65\x72\40\150\141\x73\40\x62\145\145\x6e\x20\154\x6f\147\x67\x65\x64\40\x6f\x75\x74\40\x73\x75\x63\x63\x65\163\x73\x66\165\154\171\x2e");
    wp_send_json($mj, 200);
}
function miniorange_oauth_visual_tour()
{
    $dJ = new MOCVisualTour();
}
if (!($Uc->get_versi() === 0)) {
    goto ub;
}
add_action("\141\144\155\151\x6e\137\x69\x6e\x69\164", "\x6d\151\156\x69\x6f\x72\x61\x6e\147\145\137\157\x61\x75\x74\x68\137\x76\x69\163\165\141\x6c\x5f\x74\x6f\165\162");
ub:
function mo_oauth_deactivate()
{
    global $Uc;
    do_action("\155\157\137\143\x6c\145\x61\x72\137\160\x6c\165\x67\x5f\x63\x61\x63\x68\145");
    $Uc->deactivate_plugin();
}
register_deactivation_hook(__FILE__, "\155\x6f\137\x6f\141\x75\x74\150\x5f\x64\145\x61\x63\164\151\x76\141\164\x65");
